@echo off
REM Keep variables local to this launcher.
setlocal
REM Use the folder containing this BAT as the working directory.
cd /d "%~dp0"
REM Prefer the Python launcher; fall back to the python command.
where py >nul 2>nul
if %errorlevel%==0 goto use_py
where python >nul 2>nul
if %errorlevel%==0 goto use_python
echo Python 3 was not found.
pause
exit /b 1
:use_py
REM Open the manual index and keep the local server running.
start "" "http://localhost:8000"
py -3 server.py
goto end
:use_python
start "" "http://localhost:8000"
python server.py
:end
endlocal
