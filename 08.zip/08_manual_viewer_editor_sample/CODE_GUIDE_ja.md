# 初心者向け：コードの読み方と変更のしかた

## 最初に理解すること

このツールは、ブラウザ側とPythonサーバー側に分かれています。

- HTML：ボタン、入力欄、説明など「画面に何を置くか」を決めます。
- CSS：色、余白、配置など「どう見せるか」を決めます。
- JavaScript：ボタンを押したときの処理、表示の切り替え、ファイル出力を行います。
- Python：ページの配信と、プロジェクト内へのファイル保存を行います。

通常の利用は従来どおり `start.bat` から起動します。Node.jsやnpmは開発用の整形にだけ使い、ツールの利用には必要ありません。

## おすすめの読む順番

1. `index.html`：目次、閲覧領域、確認ポップアップの構成を見ます。
2. `assets/viewer.js`：`init` → `renderCatalog` → `loadManual` の順で、入口から本文表示までを追います。
3. `assets/manual-model.js`：マニュアルのデータがどのような形か確認します。
4. `editor.html` と `assets/editor.js`：入力内容をどこで保持し、いつ保存するか確認します。
5. `server.py`：ブラウザから送られた内容がファイルになる流れを確認します。
6. 出力を変える必要がある場合に、Markdown・Excel関連のファイルを読みます。

一度に全部を理解する必要はありません。変更したいボタンのHTMLの `id` を探し、JavaScriptで同じ文字列を検索すると、対応する処理を見つけられます。

## ファイルの役割

| ファイル | 役割 |
| --- | --- |
| `index.html` | マニュアル目次と本文閲覧 |
| `editor.html` | 新規作成の入口と編集フォーム |
| `existing.html` | 既存読み込みの入口と編集フォーム |
| `tutorial.html` / `guide.html` | 操作練習と説明ガイド |
| `assets/viewer.js` | 目次・本文の表示、検索、閲覧側のExcel出力操作 |
| `assets/editor.js` | フォーム、手順、画像項目、確認ポップアップ、保存操作 |
| `assets/manual-model.js` | 空の手順・画面と、保存開始時点のデータ複製 |
| `assets/manual-parser.js` | 編集用MarkdownをJavaScriptのデータへ変換 |
| `assets/manual-writer.js` | 再編集・サイト閲覧に必要なMarkdownへ変換 |
| `assets/manual-export.js` | 配布用の番号付き画像とMarkdownを作成 |
| `assets/xlsx-export.js` | Excelのシート・画像・関連付けをファイルにまとめる |
| `assets/browser-utils.js` | HTML特殊文字の変換、ファイル名の整形、ダウンロード |
| `assets/help.js` | チュートリアルのチェックとガイドの印刷 |
| `assets/manual.css` / `editor.css` / `help.css` | 各画面の見た目 |
| `server.py` | ページ配信と固定フォルダへの保存 |
| `manuals.json` | 登録済みマニュアルの一覧 |
| `manuals/` | マニュアル本文と画像の保存先 |

## 編集データの形

編集画面の `model` は、編集中のマニュアル一つを表すオブジェクトです。

```text
model
├─ id              保存フォルダ名（内部の項目名は既存データに合わせて id）
├─ title           タイトル
├─ intro           概要
└─ steps[]         手順の配列
   ├─ title        手順名
   ├─ body         説明
   └─ screens[]    画面画像の配列
      ├─ imageSrc  表示・取得に使う画像のURL
      ├─ imageFile 選択した画像ファイル
      └─ markers[] 番号・位置・説明の配列
```

`[]` は複数のデータが順番に入る「配列」です。画像位置の `x` と `y` は、画像に対する百分率です。

`editing` はまだ追加・更新を確定していない画像項目を保持します。`model` に確定した項目とは別です。

## 画面とデータの関係

`syncFormToModel()` は入力欄の値をデータへ取り込みます。
`renderEditor()` はデータを入力欄へ表示し直します。

再描画の前に入力を取り込まないと、書きかけの文章が失われます。そのため、手順の追加・移動などでは「取り込む → データを変更する → 再描画する」の順に処理します。

`ManualModel.createSnapshot()` は保存・出力を始めた時点のデータを複製します。処理中の入力変更が、出力途中のデータへ混ざることを防ぎます。画像のFileオブジェクトは参照を共有します。

## 保存の流れ

1. `saveProject()` がフォームを取り込み、入力と未確定項目を確認します。
2. `confirmAction()` が実行してよいか確認します。キャンセルなら後続処理を行いません。
3. データを複製し、本文と画像を `/api/save-manual` へ送ります。
4. `server.py` の `do_POST()` が送信元・サイズを確認します。
5. `prepare_save()` が内容を検証し、画像・本文・一覧の書き込み内容を用意します。
6. `atomic_write()` が各ファイルを保存します。

`atomic_write()` が保証する置き換えは一ファイル単位です。保存全体を一括で元に戻す仕組みではありません。

## 二種類のMarkdownを区別する

- `ManualWriter.serialize()`：編集・サイト閲覧用。属性情報と画像の座標表を保存します。
- `ManualExport.markdown()`：読者への配布用。番号付き画像を参照し、人が読む説明を並べます。

同じ拡張子でも目的が違います。片方の形式を変更するときに、もう片方まで変えないようにしてください。

## 変更箇所を探す例

- ボタンの文言：該当ページのHTML。ただし動作中の文言はJavaScriptにもあります。
- 保存の確認文：`assets/editor.js` の `saveProject()`。
- 新しい手順の初期値：`assets/manual-model.js` の `createStep()`。
- 読者向けExcelの配置：`assets/xlsx-export.js` の `build()`。
- 保存できる名前の条件：ブラウザ側の入力確認と、`server.py` の保存内容検証。

新規作成と既存読み込みは別HTMLですが、編集フォームを共用のJavaScriptで操作します。フォームのHTMLを変更するときは、両方に必要な変更を反映してください。

HTML末尾のスクリプトは読み込み順に意味があります。`manual-model.js` などの共通処理を先に読み込み、利用するページのスクリプトを最後に読み込みます。

CSSは同じ詳細度の指定なら後の指定が優先されます。今回は既存の見た目を保つため、上書きルールの順番を維持しています。

## 整形のルール

JavaScript・HTML・CSSはPrettierで整形できます。開発する人だけ、Node.jsのある環境で次を実行します。

```text
npm ci
npm run format
```

整形設定は `.prettierrc.json` にあります。HTMLの空白の扱いは `strict` とし、見た目に関係する空白を慎重に扱います。マニュアル本文や画像は整形対象にしません。

今回、ローカルサーバー起動・ブラウザでの動作確認・テストは実施していません。画面や保存・出力の確認は利用者側で行う前提です。
