# ローカル閲覧と固定フォルダへの保存を提供するサーバー。Python標準ライブラリだけで動作する。
# GETはHTML・画像などの配信、POST /api/save-manual は本文・画像・登録一覧の保存を担当する。
"""Local manual viewer and fixed-project save endpoint (standard library only)."""
import base64
import json
import os
from pathlib import Path
import re
import tempfile
from http.server import HTTPServer, SimpleHTTPRequestHandler

# 本ファイルのある場所を保存の基準にする。起動時の作業フォルダには依存しない。
ROOT = Path(__file__).resolve().parent
MAX_BODY = 128 * 1024 * 1024
SERVER_ADDRESS = ("127.0.0.1", 8000)
ALLOWED_HOSTS = {"localhost:8000", "127.0.0.1:8000"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".svg"}
RESERVED_FOLDER_NAMES = {
    "CON", "PRN", "AUX", "NUL",
    *[f"COM{number}" for number in range(10)],
    *[f"LPT{number}" for number in range(10)],
}


# リンク先も含めて絶対パスを確認し、プロジェクト外への書き込みを防ぐ。
def project_path(relative):
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError("保存先がプロジェクトの外を指しています。")
    return path


# 同じフォルダの一時ファイルに書いてから置き換える。原子的なのは一ファイル単位で、保存全体の巻き戻しではない。
def atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
            name = stream.name
            stream.write(data)
        os.replace(name, path)
    finally:
        if name and os.path.exists(name):
            os.unlink(name)


# 保存内容の検証とファイル一覧の組み立て。ここではまだディスクへ書き込まない。
# HTTPの処理と分けることで、入力検証や保存形式の変更箇所を追いやすくする。
def prepare_save(payload):
    manual_id = payload["id"]
    title = payload["title"]
    markdown = payload["markdown"]
    if not isinstance(manual_id, str) or not re.fullmatch(r"[a-z0-9_-]{1,100}", manual_id):
        raise ValueError("保存フォルダ名は100文字以内の半角英数字・ハイフン・下線で指定してください。")
    if manual_id.split(".")[0].upper() in RESERVED_FOLDER_NAMES:
        raise ValueError("この保存フォルダ名は使えません。別の保存フォルダ名を入力してください。")
    if not isinstance(title, str) or not title.strip() or not isinstance(markdown, str):
        raise ValueError("タイトルと本文を入力してください。")
    base = "manuals/" + manual_id
    # 画像を検証・復号し、書き込み予定のファイルをメモリ上へ集める。
    files = {}
    for image in payload["images"]:
        name = image["name"]
        if (
            not isinstance(name, str)
            or not name
            or name.endswith((".", " "))
            or re.search(r'[<>:"/\\|?*\x00-\x1f]', name)
            or Path(name).suffix.lower() not in IMAGE_EXTENSIONS
        ):
            raise ValueError("画像ファイル名を確認してください。")
        path = project_path(base + "/images/" + name)
        data = base64.b64decode(image["data"], validate=True)
        if path in files and files[path] != data:
            raise ValueError("同名の異なる画像があります。画像の名前を変更してください。")
        files[path] = data
    # ディスク上の最新一覧を読み、対象以外のマニュアルを残して更新する。
    registry_path = project_path("manuals.json")
    registry = json.loads(registry_path.read_text(encoding="utf-8-sig"))
    if not isinstance(registry, list):
        raise ValueError("マニュアル一覧を読み込めません。")
    item = {"id": manual_id, "title": title, "path": base + "/manual.md", "base": base}
    found = False
    for index, old in enumerate(registry):
        if old["id"] == manual_id:
            registry[index] = item
            found = True
            break
    if not found:
        registry.append(item)
    files[project_path(base + "/manual.md")] = markdown.encode("utf-8")
    files[registry_path] = json.dumps(registry, ensure_ascii=False, indent=2).encode("utf-8")
    return files, registry, base


# 静的ファイル配信に保存APIを追加する。
class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    # 更新した本文やスクリプトを再読み込みできるよう、キャッシュを無効にする。
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    # 画面側が成功・失敗を判別できるJSONとHTTPステータスを返す。
    def reply(self, status, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    # 保存用のURLだけを受け付け、書き込み前に要求と保存内容を検証する。
    def do_POST(self):
        if self.path != "/api/save-manual":
            return self.reply(404, {"error": "保存先が見つかりません。"})
        # 別サイト経由の書き込みを防ぐため、接続先・送信元・専用ヘッダーを確認する。
        host = self.headers.get("Host", "")
        if (
            host not in ALLOWED_HOSTS
            or self.headers.get("Origin") != "http://" + host
            or self.headers.get("X-Manual-Editor") != "1"
        ):
            return self.reply(403, {"error": "このツールの画面から保存してください。"})
        try:
            # 画像を含むリクエストの最大サイズを制限する。
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= MAX_BODY:
                return self.reply(413, {"error": "画像の合計サイズが大きすぎます。画像を小さくしてください。"})
            payload = json.loads(self.rfile.read(size))
            files, registry, base = prepare_save(payload)
            # 画像、本文、一覧の順に書き込む。途中でI/Oエラーが起きた場合は一部が更新済みの場合がある。
            for path, data in files.items():
                atomic_write(path, data)
            self.reply(200, {"manuals": registry, "path": base + "/manual.md"})
        except (ValueError, KeyError, TypeError) as error:
            self.reply(400, {"error": "保存できませんでした: " + str(error)})
        except OSError:
            self.reply(500, {"error": "保存できませんでした。フォルダの書き込み権限と空き容量を確認してください。"})


# このPCからだけ接続できるアドレスで起動する。外部公開用のサーバーではない。
if __name__ == "__main__":
    print("Manual viewer: http://localhost:8000/", flush=True)
    print("Save directory: " + str(ROOT / "manuals"), flush=True)
    HTTPServer(SERVER_ADDRESS, Handler).serve_forever()
