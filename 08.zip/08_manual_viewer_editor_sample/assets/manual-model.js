/**
 * マニュアルのデータ構造を作る処理。画面や保存先には依存しない。
 * manual → steps（手順）→ screens（画像）→ markers（番号付き説明）の順で入れ子になる。
 */
(function (global) {
  "use strict";

  function createStep() {
    return { title: "", body: "", screens: [] };
  }

  function createScreen() {
    return {
      alt: "画面",
      imageName: "",
      imageSrc: "",
      imageFile: null,
      markers: [],
    };
  }

  // 保存・出力開始時点の内容を複製する。
  // Fileは読み取り専用なので参照を共有し、編集中に変わる配列や項目は複製する。
  function createSnapshot(manual) {
    return {
      ...manual,
      steps: manual.steps.map((step) => ({
        ...step,
        screens: step.screens.map((screen) => ({
          ...screen,
          markers: screen.markers.map((marker) => ({ ...marker })),
        })),
      })),
    };
  }

  global.ManualModel = { createStep, createScreen, createSnapshot };
})(window);
