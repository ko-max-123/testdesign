/**
 * チュートリアルのチェック数表示と、説明ガイドの印刷ボタンを扱う。
 * チェックはページ内だけの状態であり、マニュアルの編集・保存処理とは連動しない。
 */
"use strict";
const lessonChecks = [...document.querySelectorAll("[data-lesson]")];
// チェック数を進捗表示に反映し、すべて終わったら完了メッセージを表示する。
function updateLessonProgress() {
  const count = lessonChecks.filter((input) => input.checked).length;
  document.getElementById("lessonProgress").textContent =
    count + " / " + lessonChecks.length + " 完了";
  document.getElementById("lessonMeter").value = count;
  document.getElementById("lessonDone").hidden = count !== lessonChecks.length;
}
lessonChecks.forEach((input) => input.addEventListener("change", updateLessonProgress));
const reset = document.getElementById("resetLessons");
if (reset)
  reset.addEventListener("click", () => {
    if (!confirm("チュートリアルのチェックをすべて外しますか？ マニュアルの内容は変更されません。"))
      return;
    lessonChecks.forEach((input) => (input.checked = false));
    updateLessonProgress();
  });
const printButton = document.getElementById("printGuide");
if (printButton) printButton.addEventListener("click", () => window.print());
