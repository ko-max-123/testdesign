/** 再編集とサイト閲覧のためのMarkdown出力。読者向けの出力は manual-export.js が担当する。 */
(function (global) {
  "use strict";
  function round2(value) {
    return Math.round(Number(value) * 100) / 100;
  }
  function generateMd(m) {
    const q = (s) =>
      String(s ?? "")
        .replace(/\|/g, "\\|")
        .replace(/\r?\n/g, "<br>");
    let out = `---\ntitle: ${m.title}\ncategory: ${m.category}\nversion: ${m.version}\nupdated: ${m.updated}\nowner: ${m.owner}\n---\n\n# ${m.title}\n\n${m.intro.trim()}\n\n`;
    m.steps.forEach((st, si) => {
      out += `## STEP ${si + 1}\n### ${st.title}\n\n${st.body.trim()}\n\n`;
      st.screens.forEach((sc, sci) => {
        const name = sc.imageName || `screen-${si + 1}-${sci + 1}.png`;
        out += `![${sc.alt || st.title}](images/${name})\n\n`;
        if (sc.markers.length) {
          out +=
            "| No | X | Y | 項目 | 種類 | 必須 | 操作 | 説明 | 入力例 |\n|---|---:|---:|---|---|---|---|---|---|\n";
          sc.markers.forEach((x, i) => {
            out += `| ${i + 1} | ${round2(x.x)} | ${round2(x.y)} | ${q(x.item)} | ${q(x.type)} | ${q(x.required)} | ${q(x.action)} | ${q(x.description)} | ${q(x.example)} |\n`;
          });
          out += "\n";
        }
      });
    });
    return out.trim() + "\n";
  }

  global.ManualWriter = { serialize: generateMd };
})(window);
