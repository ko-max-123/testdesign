/**
 * 読者向けの画像・Markdown出力を準備する共有モジュール。
 * 編集用の座標情報は画像上の番号へ変換し、配布ファイルに生の座標表を出さない。
 */
(function (g) {
  "use strict";
  const text = (value) => String(value ?? "");
  // Excelのセルに表示するため、対応するMarkdown装飾を通常の文字列に戻す。
  function plain(value) {
    return text(value)
      .replace(/<br\s*\/?\s*>/gi, "\n")
      .replace(/^#{1,6}\s+/gm, "")
      .replace(/^>\s*\[!(?:NOTE|TIP|WARNING)\]\s*/gm, "")
      .replace(/^>\s?/gm, "")
      .replace(/\*\*([^*]+)\*\*/g, "$1")
      .replace(/`([^`]+)`/g, "$1");
  }
  // 手順番号と画面番号で配布用画像名を決め、元画像の同名衝突を避ける。
  function imagePath(si, sci) {
    return `images/step-${si + 1}-screen-${sci + 1}.png`;
  }
  // 概要・手順・番号に対応する説明を、読むためのMarkdownとして組み立てる。
  function markdown(model) {
    const line = (value) => text(value).replace(/\r?\n/g, " ");
    const out = [`# ${line(model.title)}`, ""];
    const meta = [
      ["分類", model.category],
      ["バージョン", model.version],
      ["更新日", model.updated],
      ["担当", model.owner],
    ].filter(([, v]) => v);
    meta.forEach(([label, value]) => out.push(`- ${label}：${line(value)}`));
    out.push("", text(model.intro).trim(), "");
    model.steps.forEach((step, si) => {
      out.push(
        `## 手順 ${si + 1}：${line(step.title) || "操作手順"}`,
        "",
        text(step.body).trim(),
        "",
      );
      step.screens.forEach((screen, sci) => {
        out.push(
          `### 画面 ${sci + 1}`,
          "",
          `![画面 ${sci + 1}：${line(step.title).replace(/[\[\]]/g, "")}](${imagePath(si, sci)})`,
          "",
        );
        screen.markers.forEach((marker, mi) => {
          out.push(`#### ${mi + 1}. ${line(marker.item)}`, "");
          const info = [
            marker.type,
            /○|必須/.test(marker.required) ? "必須" : "",
            marker.action ? "操作：" + marker.action : "",
          ].filter(Boolean);
          if (info.length) out.push(info.map(line).join(" ／ "), "");
          if (marker.description) out.push(text(marker.description), "");
          if (marker.example) out.push("入力例：" + text(marker.example), "");
        });
      });
    });
    return out.join("\n").trim() + "\n";
  }
  // 元画像をCanvasへ描き、登録位置に番号を重ねたPNGを生成する。元の画像ファイルは変更しない。
  async function annotatedImage(screen) {
    let blob = screen.imageFile;
    if (!blob) {
      if (!screen.imageSrc)
        throw new Error("画面画像を選択してください。不要な画面は削除してから出力してください。");
      const response = await fetch(screen.imageSrc);
      if (!response.ok) throw new Error("画面画像を読み込めません：" + screen.imageName);
      blob = await response.blob();
    }
    const url = URL.createObjectURL(blob);
    try {
      const img = new Image();
      img.src = url;
      await img.decode();
      // Keep long screenshots intact; reduce only exceptionally large images.
      const scale = Math.min(1, 3000 / img.naturalWidth, 12000 / img.naturalHeight);
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("画像を書き出せませんでした。");
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const radius = Math.max(12, canvas.width / 65);
      screen.markers.forEach((marker, index) => {
        const x = Math.min(
          canvas.width - radius,
          Math.max(radius, (Number(marker.x) / 100) * canvas.width),
        );
        const y = Math.min(
          canvas.height - radius,
          Math.max(radius, (Number(marker.y) / 100) * canvas.height),
        );
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fillStyle = "#17202c";
        ctx.fill();
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = Math.max(2, radius / 7);
        ctx.stroke();
        ctx.fillStyle = "#fff";
        ctx.font = `bold ${Math.round(radius * 1.15)}px sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(String(index + 1), x, y, radius * 1.6);
      });
      const output = await new Promise((resolve, reject) =>
        canvas.toBlob(
          (b) => (b ? resolve(b) : reject(new Error("画像の出力に失敗しました。"))),
          "image/png",
        ),
      );
      return {
        data: new Uint8Array(await output.arrayBuffer()),
        width: canvas.width,
        height: canvas.height,
      };
    } finally {
      URL.revokeObjectURL(url);
    }
  }
  // 各画面に出力用画像を付けたデータを返す。画像処理を順番に実行し、同時展開を抑える。
  async function prepare(model) {
    const result = { ...model, steps: [] };
    for (let si = 0; si < model.steps.length; si++) {
      const step = model.steps[si],
        copy = { ...step, screens: [] };
      result.steps.push(copy);
      for (let sci = 0; sci < step.screens.length; sci++)
        copy.screens.push({
          ...step.screens[sci],
          exportImage: await annotatedImage(step.screens[sci]),
          exportPath: imagePath(si, sci),
        });
    }
    return result;
  }
  // Markdown本文と参照する画像を、展開後も相対パスが通るZIP構成にまとめる。
  function markdownArchive(model) {
    const entries = [{ name: "manual.md", data: markdown(model) }];
    model.steps.forEach((step) =>
      step.screens.forEach((screen) =>
        entries.push({ name: screen.exportPath, data: screen.exportImage.data }),
      ),
    );
    return g.ManualXlsx.zip(entries);
  }
  g.ManualExport = { plain, markdown, prepare, markdownArchive };
})(window);
