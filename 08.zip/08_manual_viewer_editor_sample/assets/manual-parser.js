/**
 * 閲覧画面と編集画面で共用する、編集用Markdownの読み込み処理。
 * 配布用Markdownではなく、属性情報・STEP見出し・座標表を含む形式を想定する。
 */
(function (g) {
  "use strict";
  function newScreen() {
    return ManualModel.createScreen();
  }
  // 属性・概要・手順・画面・番号付き項目を、編集とExcel出力で使うデータ構造へ変換する。
  function parseMd(text, base) {
    const frontMatter = parseFront(text),
      lines = frontMatter.body.replace(/\r/g, "").split("\n");
    let title = frontMatter.meta.title || "",
      intro = [],
      steps = [],
      currentStep = null,
      i = 0;
    while (i < lines.length) {
      const l = lines[i];
      if (/^#\s+/.test(l)) {
        if (!title) title = l.replace(/^#\s+/, "").trim();
        i++;
        continue;
      }
      const stepHeading = l.match(/^##\s+STEP\s+\d+/i);
      if (stepHeading) {
        currentStep = { title: "", bodyLines: [], screens: [] };
        steps.push(currentStep);
        i++;
        if (/^###\s+/.test(lines[i] || "")) {
          currentStep.title = lines[i].replace(/^###\s+/, "").trim();
          i++;
        }
        continue;
      }
      if (!currentStep) {
        intro.push(l);
        i++;
        continue;
      }
      const imageMatch = l.match(/^!\[([^\]]*)\]\(([^)]+)\)\s*$/);
      if (imageMatch) {
        const path = imageMatch[2],
          screen = newScreen();
        screen.alt = imageMatch[1];
        screen.imageName = path.split("/").pop();
        screen.imageSrc = base ? resolve(base, path) : "";
        currentStep.screens.push(screen);
        i++;
        while (i < lines.length && !lines[i].trim()) i++;
        if (/^\|\s*No\s*\|\s*X\s*\|\s*Y/i.test(lines[i] || "")) {
          const headers = splitMdRow(lines[i]);
          i += 2;
          while (i < lines.length && /^\s*\|/.test(lines[i])) {
            const r = splitMdRow(lines[i]),
              o = Object.fromEntries(headers.map((h, j) => [h.trim(), r[j] ?? ""]));
            screen.markers.push({
              x: Number(o.X) || 50,
              y: Number(o.Y) || 50,
              item: o["項目"] || "",
              type: o["種類"] || "",
              required: o["必須"] || "-",
              action: o["操作"] || "",
              description: o["説明"] || "",
              example: o["入力例"] || "",
            });
            i++;
          }
        }
        continue;
      }
      currentStep.bodyLines.push(l);
      i++;
    }
    return {
      id: "",
      title,
      category: frontMatter.meta.category || "",
      version: frontMatter.meta.version || "1.0",
      updated: frontMatter.meta.updated || new Date().toISOString().slice(0, 10),
      owner: frontMatter.meta.owner || "",
      intro: intro.join("\n").trim(),
      steps: steps.map((s) => ({
        title: s.title || "手順",
        body: s.bodyLines.join("\n").trim(),
        screens: s.screens,
      })),
    };
  }
  // 先頭の区切り内をキーと値に分け、残りを本文として返す。
  function parseFront(t) {
    const meta = {};
    if (t.startsWith("---")) {
      const e = t.indexOf("\n---", 3);
      if (e >= 0) {
        t.slice(3, e)
          .trim()
          .split(/\r?\n/)
          .forEach((l) => {
            const i = l.indexOf(":");
            if (i > 0) meta[l.slice(0, i).trim()] = l.slice(i + 1).trim();
          });
        return { meta, body: t.slice(e + 4).replace(/^\s+/, "") };
      }
    }
    return { meta, body: t };
  }
  // 表の一行をセルへ分割し、改行表現を入力用の文字列へ戻す。
  function splitMdRow(l) {
    return l
      .trim()
      .replace(/^\||\|$/g, "")
      .split("|")
      .map((x) => x.trim().replace(/<br>/g, "\n").replace(/\\\|/g, "|"));
  }
  // 画像の相対パスにマニュアルの保存フォルダを補う。絶対URLはそのまま使う。
  function resolve(b, p) {
    if (/^(https?:|data:|blob:|\/)/.test(p)) return p;
    return `${b}/${p}`.replace(/\/+/g, "/");
  }

  g.ManualParser = { parse: parseMd };
})(window);
