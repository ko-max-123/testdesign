/** ページに依存しない、HTML文字列とファイルダウンロードの共通処理。 */
(function (global) {
  "use strict";

  function escapeHtml(value = "") {
    const replacements = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    };
    return String(value).replace(/[&<>"']/g, (character) => replacements[character]);
  }

  // ファイル名に使えない文字だけを置き換える。保存フォルダ名の検証とは別の処理。
  function downloadName(value) {
    return (
      value
        .replace(/[<>:"/\\|?*\x00-\x1f]/g, "_")
        .replace(/[. ]+$/g, "")
        .slice(0, 100) || "manual"
    );
  }

  function downloadBlob(name, blob) {
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = name;
    link.click();
    // クリック直後にURLを解放すると取得前に無効になるため、少し待って解放する。
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  }

  global.BrowserUtils = { escapeHtml, downloadName, downloadBlob };
})(window);
