/**
 * 新規作成・既存更新ページで共用する編集処理。HTMLのテンプレートから手順と画面を生成する。
 * model が編集内容、manuals が登録一覧、editing が未確定の画像項目を保持する。
 * プロジェクト保存用Markdownと読者向けファイル出力は別の処理として扱う。
 */

const getElement = (id) => document.getElementById(id);
let manuals = [],
  model = null,
  editing = null;
const today = new Date().toISOString().slice(0, 10);

document.addEventListener("DOMContentLoaded", init);

// ページの操作を登録して一覧を取得する。新規作成／読み込みボタンを押すまでは編集内容を作らない。
async function init() {
  bindEditorActions();
  initActionDialog();
  try {
    const response = await fetch("manuals.json");
    if (!response.ok) throw new Error("一覧の読込失敗");
    manuals = await response.json();
    if (!Array.isArray(manuals)) throw new Error("一覧の形式が不正です");
    updateExistingSelect();
  } catch {
    manuals = [];
    if (getElement("existingSelect")) {
      getElement("existingSelect").innerHTML =
        '<option value="">一覧を取得できませんでした</option>';
      showEditorNotice(
        "マニュアル一覧を読み込めません。start.bat で起動してからページを再読み込みしてください。",
        "error",
      );
    }
  }
}
// 既存読み込みページにだけ存在する選択欄を更新する。新規作成ページでは何もしない。
function updateExistingSelect() {
  const select = getElement("existingSelect");
  if (!select) return;
  select.innerHTML =
    '<option value="">' +
    (manuals.length ? "更新するマニュアルを選択" : "保存済みのマニュアルはありません") +
    "</option>" +
    manuals
      .map((m) => '<option value="' + escapeHtml(m.id) + '">' + escapeHtml(m.title) + "</option>")
      .join("");
  select.disabled = !manuals.length;
  getElement("loadExistingBtn").disabled = true;
}

// 各ボタンに処理を割り当てる。ページ固有の要素は存在を確認してから扱う。
function bindEditorActions() {
  if (getElement("newBtn"))
    getElement("newBtn").onclick = async () => {
      if (model && !(await confirmReplace("新しく作り直しますか？"))) return;
      await runEditorAction("新規マニュアルを準備しています", async () => {
        resetModel();
        return {
          title: "新規マニュアルを作成しました",
          message: "基本情報と手順を入力できます。入力後は「マニュアルを保存」を押してください。",
        };
      });
    };
  if (getElement("loadExistingBtn")) getElement("loadExistingBtn").onclick = loadExisting;
  if (getElement("existingSelect"))
    getElement("existingSelect").onchange = (e) => {
      getElement("loadExistingBtn").disabled = !e.target.value;
    };
  if (getElement("mdImport")) getElement("mdImport").onchange = importMdFile;
  getElement("addStepBtn").onclick = () => {
    syncFormToModel();
    model.steps.push(newStep());
    renderEditor();
    focusStep(model.steps.length - 1);
  };
  getElement("previewMdBtn").onclick = () => {
    syncFormToModel();
    getElement("mdPreview").textContent = ManualExport.markdown(model);
    getElement("mdPreview").parentElement.open = true;
  };
  getElement("downloadMdBtn").onclick = () => exportManual("md");
  getElement("downloadXlsxBtn").onclick = () => exportManual("xlsx");
  getElement("downloadRegistryBtn").onclick = downloadRegistry;
  getElement("saveProjectBtn").onclick = saveProject;
}

// 新規マニュアルの初期データを用意する。ここではディスクに保存しない。
function resetModel() {
  model = {
    id: "new-manual",
    title: "新規マニュアル",
    category: "管理画面",
    version: "1.0",
    updated: today,
    owner: "",
    intro: "",
    steps: [newStep()],
  };
  renderEditor();
  showEditorNotice("新規マニュアルを開始しました。");
}
function newStep() {
  return ManualModel.createStep();
}
function newScreen() {
  return ManualModel.createScreen();
}

// model の内容をフォームに反映する。再描画では未確定の項目編集状態を解除する。
function renderEditor() {
  document.body.classList.add("editor-ready");
  getElement("manualId").value = model.id || "";
  getElement("title").value = model.title || "";
  getElement("category").value = model.category || "";
  getElement("version").value = model.version || "";
  getElement("updated").value = model.updated || today;
  getElement("owner").value = model.owner || "";
  getElement("intro").value = model.intro || "";
  const wrap = getElement("steps");
  wrap.innerHTML = "";
  model.steps.forEach((st, si) => wrap.appendChild(renderStep(st, si)));
  editing = null;
  updateEditorNav();
}

// 手順テンプレートを複製し、入力欄と追加・移動・削除ボタンを結び付ける。si は手順の添字。
function renderStep(st, si) {
  const f = getElement("stepTemplate").content.cloneNode(true),
    el = f.querySelector(".step-editor");
  el.dataset.si = si;
  el.id = "edit-step-" + si;
  el.tabIndex = -1;
  el.querySelector(".step-number").textContent = `STEP ${si + 1}`;
  el.querySelector(".step-title").value = st.title;
  el.querySelector(".step-title").addEventListener("input", updateEditorNav);
  el.querySelector(".step-body").value = st.body;
  el.querySelector(".move-up").disabled = si === 0;
  el.querySelector(".move-down").disabled = si === model.steps.length - 1;
  el.querySelector(".remove-step").onclick = async () => {
    if (
      !(await confirmAction(
        "手順を削除しますか？",
        `手順 ${si + 1}「${el.querySelector(".step-title").value || "手順名未入力"}」と、この手順に含まれる画面・項目を削除します。削除は元に戻せません。`,
        "削除する",
        true,
      ))
    )
      return;
    syncFormToModel();
    model.steps.splice(si, 1);
    if (!model.steps.length) model.steps.push(newStep());
    renderEditor();
  };
  el.querySelector(".move-up").onclick = () => moveStep(si, -1);
  el.querySelector(".move-down").onclick = () => moveStep(si, 1);
  const list = el.querySelector(".screen-list");
  st.screens.forEach((sc, sci) => list.appendChild(renderScreen(sc, si, sci)));
  el.querySelector(".add-screen").onclick = () => {
    syncFormToModel();
    model.steps[si].screens.push(newScreen());
    renderEditor();
    const screens = getElement("edit-step-" + si).querySelectorAll(".screen-editor");
    screens[screens.length - 1].scrollIntoView({ behavior: "smooth", block: "start" });
  };
  return el;
}
// 入力中の本文を取り込んでから、指定方向の手順と入れ替える。
function moveStep(i, d) {
  syncFormToModel();
  const n = i + d;
  if (n < 0 || n >= model.steps.length) return;
  [model.steps[i], model.steps[n]] = [model.steps[n], model.steps[i]];
  renderEditor();
  focusStep(n);
}

// 画面テンプレートを複製する。sci は手順内の画面の添字。選択ファイルは保存までブラウザ内で保持する。
function renderScreen(sc, si, sci) {
  const f = getElement("screenTemplate").content.cloneNode(true),
    el = f.querySelector(".screen-editor");
  el.dataset.sci = sci;
  el.querySelector(".screen-label").textContent = `画面 ${sci + 1}`;
  el.querySelector(".screen-file-name").textContent = sc.imageName ? `(${sc.imageName})` : "";
  el.querySelector(".remove-screen").onclick = async () => {
    if (
      !(await confirmAction(
        "画面を削除しますか？",
        `手順 ${si + 1} の画面 ${sci + 1}${sc.imageName ? "（" + sc.imageName + "）" : ""}と、付けた番号・説明を削除します。削除は元に戻せません。`,
        "削除する",
        true,
      ))
    )
      return;
    syncFormToModel();
    model.steps[si].screens.splice(sci, 1);
    renderEditor();
  };
  const input = el.querySelector(".image-input"),
    canvas = el.querySelector(".editor-canvas");
  input.onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    sc.imageFile = file;
    sc.imageName = file.name;
    sc.imageSrc = URL.createObjectURL(file);
    el.querySelector(".screen-file-name").textContent = file.name;
    drawScreen(el, sc, si, sci);
  };
  drawScreen(el, sc, si, sci);
  return el;
}

// 画像と登録済みの番号を描画し、画像クリックを新しい項目の位置指定につなぐ。
function drawScreen(el, sc, si, sci) {
  const canvas = el.querySelector(".editor-canvas");
  canvas.innerHTML = "";
  const coord = el.querySelector(".coord-value"),
    save = el.querySelector(".save-marker"),
    cancel = el.querySelector(".cancel-marker");
  if (editing?.el) clearPending(editing.el);
  canvas.onclick = null;
  if (!sc.imageSrc) {
    canvas.innerHTML = '<div class="empty-image">画像を選択してください</div>';
  } else {
    const img = document.createElement("img");
    img.src = sc.imageSrc;
    img.alt = sc.alt || "画面";
    canvas.appendChild(img);
    sc.markers.forEach((m, mi) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "edit-marker";
      b.textContent = mi + 1;
      b.style.left = m.x + "%";
      b.style.top = m.y + "%";
      b.title = m.item;
      b.onclick = (e) => {
        e.stopPropagation();
        startEditMarker(el, sc, mi, si, sci);
      };
      canvas.appendChild(b);
    });
    canvas.onclick = (e) => {
      if (e.target.classList.contains("edit-marker")) return;
      const r = img.getBoundingClientRect(),
        x = ((e.clientX - r.left) / r.width) * 100,
        y = ((e.clientY - r.top) / r.height) * 100;
      beginPending(el, si, sci, x, y, null);
    };
  }
  renderMarkerList(el, sc, si, sci);
  clearPending(el);
  save.onclick = () => savePending(el, sc, si, sci);
  cancel.onclick = () => clearPending(el);
}

// クリック位置を画像に対する百分率で保持する。index が null なら追加、それ以外なら既存項目の編集。
function beginPending(el, si, sci, x, y, index) {
  if (editing?.el && editing.el !== el) clearPending(editing.el);
  clearPending(el, false);
  editing = { si, sci, index, x: round2(x), y: round2(y), el };
  el.querySelector(".coord-value").textContent =
    index == null ? "選択済み・説明を入力してください" : `項目 ${index + 1} を編集中`;
  el.querySelector(".save-marker").disabled = false;
  el.querySelector(".cancel-marker").disabled = false;
  const p = document.createElement("div");
  p.className = "pending-marker";
  p.style.left = editing.x + "%";
  p.style.top = editing.y + "%";
  el.querySelector(".editor-canvas").appendChild(p);
}
// 選択済みの項目を入力欄に展開する。更新ボタンを押すまでは確定しない。
function startEditMarker(el, sc, mi, si, sci) {
  const m = sc.markers[mi];
  beginPending(el, si, sci, m.x, m.y, mi);
  el.querySelector(".m-item").value = m.item || "";
  el.querySelector(".m-type").value = m.type || "";
  el.querySelector(".m-required").value = m.required || "-";
  el.querySelector(".m-action").value = m.action || "";
  el.querySelector(".m-desc").value = m.description || "";
  el.querySelector(".m-example").value = m.example || "";
  el.querySelector(".save-marker").textContent = "項目を更新";
  [...el.querySelectorAll(".marker-row")].forEach((x, i) => x.classList.toggle("active", i === mi));
}
// 項目名を確認し、未確定の位置と説明を画面の項目一覧に反映する。
function savePending(el, sc, si, sci) {
  if (editing?.si !== si || editing?.sci !== sci || editing.x == null) return;
  if (!el.querySelector(".m-item").value.trim()) {
    el.querySelector(".m-item").focus();
    return showEditorNotice("番号を付ける項目の名前を入力してください。", "error");
  }
  const m = {
    x: editing.x,
    y: editing.y,
    item: el.querySelector(".m-item").value.trim() || "項目",
    type: el.querySelector(".m-type").value.trim(),
    required: el.querySelector(".m-required").value,
    action: el.querySelector(".m-action").value.trim(),
    description: el.querySelector(".m-desc").value.trim(),
    example: el.querySelector(".m-example").value.trim(),
  };
  if (editing.index == null) sc.markers.push(m);
  else sc.markers[editing.index] = m;
  drawScreen(el, sc, si, sci);
}
// 位置指定と入力欄をリセットする。登録済み項目そのものは削除しない。
function clearPending(el, clearFields = true) {
  el.querySelectorAll(".pending-marker").forEach((x) => x.remove());
  el.querySelector(".coord-value").textContent = "画像をクリックして選択";
  el.querySelector(".save-marker").disabled = true;
  el.querySelector(".cancel-marker").disabled = true;
  el.querySelector(".save-marker").textContent = "この位置に項目を追加";
  if (clearFields) {
    [".m-item", ".m-type", ".m-action", ".m-desc", ".m-example"].forEach(
      (s) => (el.querySelector(s).value = ""),
    );
    el.querySelector(".m-required").value = "-";
  }
  el.querySelectorAll(".marker-row.active").forEach((row) => row.classList.remove("active"));
  editing = null;
}
// 画像に対応する説明一覧を作る。削除は確認ポップアップで承認された後に実行する。
function renderMarkerList(el, sc, si, sci) {
  const list = el.querySelector(".marker-list");
  list.innerHTML = sc.markers.length
    ? ""
    : '<p class="marker-empty">追加した項目がここに並びます。</p>';
  sc.markers.forEach((m, mi) => {
    const row = document.createElement("div");
    row.className = "marker-row";
    row.innerHTML = `<div class="marker-no">${mi + 1}</div><div class="marker-info"><strong>${escapeHtml(m.item)}</strong><small>${escapeHtml(m.action || "操作未入力")}${m.type ? "・" + escapeHtml(m.type) : ""}</small></div><div class="marker-row-actions"><button class="edit">編集</button><button class="del danger">削除</button></div>`;
    row.querySelector(".edit").onclick = () => startEditMarker(el, sc, mi, si, sci);
    row.querySelector(".del").onclick = async () => {
      if (
        !(await confirmAction(
          "項目を削除しますか？",
          `項目 ${mi + 1}「${m.item}」の番号と説明を削除します。削除は元に戻せません。`,
          "削除する",
          true,
        ))
      )
        return;
      sc.markers.splice(mi, 1);
      drawScreen(el, sc, si, sci);
    };
    list.appendChild(row);
  });
}

// 現在のフォーム値を model に取り込む。再描画や保存の前に呼び、入力を保持する。
function syncFormToModel() {
  model.id = getElement("manualId").value.trim();
  model.title = getElement("title").value.trim();
  model.category = getElement("category").value.trim();
  model.version = getElement("version").value.trim();
  model.updated = getElement("updated").value;
  model.owner = getElement("owner").value.trim();
  model.intro = getElement("intro").value;
  [...getElement("steps").querySelectorAll(".step-editor")].forEach((el, si) => {
    if (!model.steps[si]) return;
    model.steps[si].title = el.querySelector(".step-title").value.trim();
    model.steps[si].body = el.querySelector(".step-body").value;
  });
}

// 再編集・サイト閲覧用Markdownを作る。先頭の属性情報と画像の座標表を保持する。配布用は ManualExport を使う。
function generateMd(manual) {
  return ManualWriter.serialize(manual);
}

// 一覧で選んだ本文を取得し、画像の相対パスを解決して編集画面へ反映する。
async function loadExisting() {
  const id = getElement("existingSelect").value;
  if (!id) return;
  if (model && !(await confirmReplace("別のマニュアルを読み込みますか？"))) return;
  await runEditorAction("マニュアルを読み込んでいます", async () => {
    const info = manuals.find((x) => x.id === id);
    if (!info) throw new Error("マニュアルを選び直してください。");
    const response = await fetch(info.path);
    if (!response.ok)
      throw new Error("本文を取得できません。マニュアルの保存先を確認してください。");
    const loaded = parseMd(await response.text(), info.base);
    loaded.id = id;
    model = loaded;
    renderEditor();
    showEditorNotice(info.title + " を読み込みました。", "ok");
    return {
      title: "読み込みが完了しました",
      message:
        "「" + info.title + "」を編集できます。変更後は「マニュアルを保存」を押してください。",
    };
  });
}
// 手元の編集用Markdownを取り込む。隣の画像ファイルは自動取得できないため再選択が必要。
async function importMdFile(e) {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  if (model && !(await confirmReplace("ファイルから読み込みますか？"))) return;
  await runEditorAction("Markdownを読み込んでいます", async () => {
    const raw = await file.text();
    if (!/^##\s+STEP\s+\d+/im.test(raw))
      throw new Error(
        "編集用のMarkdownを選んでください。プロジェクト内の manuals/保存フォルダ名/manual.md を読み込めます。",
      );
    const loaded = parseMd(raw, "");
    loaded.id = safeId(file.name.replace(/\.md$/i, ""));
    model = loaded;
    renderEditor();
    showEditorNotice("Markdownを読み込みました。画面画像は再選択してください。", "ok");
    return {
      title: "ファイルを読み込みました",
      message: "「" + file.name + "」を開きました。画面画像は各手順で再選択してください。",
    };
  });
}
function parseMd(text, base) {
  return ManualParser.parse(text, base);
}

// 現在のマニュアルの登録情報を作り、ほかの登録を残して一覧へ追加する。
function registryData() {
  syncFormToModel();
  const item = {
    id: safeId(model.id),
    title: model.title,
    path: `manuals/${safeId(model.id)}/manual.md`,
    base: `manuals/${safeId(model.id)}`,
  };
  const merged = manuals.filter((x) => x.id !== item.id);
  merged.push(item);
  return merged;
}
async function downloadRegistry() {
  if (
    !(await confirmAction(
      "登録一覧を保存しますか？",
      "現在のマニュアルを含む登録一覧をJSONファイルとしてダウンロードします。",
      "保存する",
    ))
  )
    return;
  downloadText(
    "manuals.updated.json",
    JSON.stringify(registryData(), null, 2),
    "application/json;charset=utf-8",
  );
}
// 確認後の内容を複製し、画像と本文を保存APIへ送る。保存先の決定・ファイル書き込みは server.py が担当。
async function saveProject() {
  syncFormToModel();
  if (editing?.x != null)
    return showEditorNotice(
      "編集中の画像項目を追加・更新するか、キャンセルしてから保存してください。",
      "error",
    );
  if (!model.title || !model.id || !/^[a-z0-9_-]{1,100}$/.test(model.id)) {
    showEditorNotice(
      "タイトルと保存フォルダ名を入力してください。保存フォルダ名は100文字以内の半角小文字の英数字・ハイフン・下線で指定します。",
      "error",
    );
    getElement("basics").scrollIntoView({ behavior: "smooth" });
    return;
  }
  if (
    !(await confirmAction(
      "マニュアルを保存しますか？",
      `「${model.title}」を manuals/${model.id}/ に保存します。同じ保存フォルダ名の本文と同名の画像は上書きされ、マニュアル一覧も更新されます。`,
      "保存する",
    ))
  )
    return;
  const snapshot = ManualModel.createSnapshot(model);
  const button = getElement("saveProjectBtn");
  button.disabled = true;
  button.textContent = "保存中…";
  showEditorNotice("本文と画像をプロジェクト内に保存しています。");
  try {
    const images = [];
    for (const step of snapshot.steps)
      for (const screen of step.screens) {
        if (!screen.imageName || (!screen.imageFile && !screen.imageSrc))
          throw new Error("画像が未選択です。画像を選ぶか、不要な画面を削除してください。");
        let blob = screen.imageFile;
        if (!blob) {
          const response = await fetch(screen.imageSrc);
          if (!response.ok) throw new Error("画像を読み込めません: " + screen.imageName);
          blob = await response.blob();
        }
        images.push({ name: screen.imageName, data: await blobBase64(blob) });
      }
    const response = await fetch("/api/save-manual", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Manual-Editor": "1" },
      body: JSON.stringify({
        id: snapshot.id,
        title: snapshot.title,
        markdown: generateMd(snapshot),
        images,
      }),
    });
    if (!(response.headers.get("content-type") || "").includes("application/json"))
      throw new Error("起動中のサーバーを終了し、start.bat で起動し直してください。");
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "保存できませんでした。");
    manuals = result.manuals;
    updateExistingSelect();
    showEditorNotice(
      "保存しました: " +
        result.path +
        "。「閲覧画面へ」から確認できます。保存中に行った変更はもう一度保存してください。",
      "ok",
    );
  } catch (error) {
    showEditorNotice(
      error instanceof TypeError
        ? "サーバーに接続できません。start.bat で起動してから保存してください。"
        : error.message,
      "error",
    );
  } finally {
    button.disabled = false;
    button.textContent = "マニュアルを保存";
  }
}
// 画像のバイナリをJSONで送信できるBase64文字列へ変換する。
function blobBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1]);
    reader.onerror = () => reject(new Error("画像を読み込めませんでした。"));
    reader.readAsDataURL(blob);
  });
}

function downloadText(name, text, type) {
  downloadBlob(name, new Blob([text], { type }));
}
// 一時URLを使ってブラウザのダウンロードを開始し、使用後にURLを解放する。
function downloadBlob(name, blob) {
  BrowserUtils.downloadBlob(name, blob);
}
// 画面上部と保存欄へ同じ結果を表示する。エラー時は色も変える。
function showEditorNotice(t, kind = "") {
  const n = getElement("saveNotice");
  n.textContent = t;
  n.className = "notice " + kind;
  getElement("editorStatus").textContent = t;
  getElement("editorStatus").className = "editor-status " + kind;
}
function round2(n) {
  return Math.round(Number(n) * 100) / 100;
}
// ファイル出力などで使う名前を英数字・ハイフン・下線へ整える。
function safeId(s) {
  return (
    String(s || "manual")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_-]+/g, "-")
      .replace(/^-+|-+$/g, "") || "manual"
  );
}
// HTMLへ埋め込む文字列の特殊文字をエスケープし、入力内容がタグとして扱われるのを防ぐ。
function escapeHtml(value = "") {
  return BrowserUtils.escapeHtml(value);
}

function focusStep(index) {
  const step = getElement("edit-step-" + index);
  if (step) {
    step.scrollIntoView({ behavior: "smooth", block: "start" });
    step.querySelector(".step-title").focus({ preventScroll: true });
  }
}
let editorNavObserver;
// 入力された手順名をナビへ反映し、画面内に入った編集箇所を監視する。
function updateEditorNav() {
  const steps = [...getElement("steps").querySelectorAll(".step-editor")];
  getElement("editorStepNav").innerHTML = steps
    .map(
      (step, i) =>
        '<a href="#' +
        step.id +
        '">' +
        (i + 1) +
        ". " +
        escapeHtml(step.querySelector(".step-title").value || "手順名を入力") +
        "</a>",
    )
    .join("");
  editorNavObserver?.disconnect();
  editorNavObserver = new IntersectionObserver(
    (entries) => {
      const entry = entries.find((e) => e.isIntersecting);
      if (entry) setEditorNav(entry.target.id);
    },
    { rootMargin: "-60px 0px -65% 0px", threshold: 0 },
  );
  document
    .querySelectorAll(".editor-main>.panel,.step-editor")
    .forEach((el) => editorNavObserver.observe(el));
  document.querySelector(".editor-sidebar nav").onclick = (e) => {
    const a = e.target.closest("a");
    if (!a) return;
    setEditorNav(a.hash.slice(1));
  };
}
function setEditorNav(id) {
  document.querySelectorAll(".editor-sidebar nav a").forEach((a) => {
    const active = a.hash === "#" + id;
    a.classList.toggle("active", active);
    if (active) a.setAttribute("aria-current", "location");
    else a.removeAttribute("aria-current");
  });
}

// 画像へ番号を焼き込み、読むためのExcelまたはMarkdown一式を出力する。プロジェクト保存は行わない。
async function exportManual(format) {
  syncFormToModel();
  if (editing?.x != null)
    return showEditorNotice(
      "編集中の画像項目を追加・更新するか、キャンセルしてから出力してください。",
      "error",
    );
  if (!model.title.trim())
    return showEditorNotice("マニュアルのタイトルを入力してください。", "error");
  if (
    !(await confirmAction(
      "マニュアルをファイルに保存しますか？",
      `「${model.title}」を${format === "xlsx" ? "Excel" : "Markdownと画像をまとめたZIP"}としてダウンロードします。`,
      "保存する",
    ))
  )
    return;
  const snapshot = ManualModel.createSnapshot(model);
  const buttons = [getElement("downloadMdBtn"), getElement("downloadXlsxBtn")];
  buttons.forEach((button) => (button.disabled = true));
  showEditorNotice("番号付きの画面画像と説明をまとめて、マニュアルを作成しています。");
  try {
    const prepared = await ManualExport.prepare(snapshot);
    const bytes =
      format === "xlsx" ? ManualXlsx.build(prepared) : ManualExport.markdownArchive(prepared);
    const name = BrowserUtils.downloadName(snapshot.title || snapshot.id || "manual");
    const extension = format === "xlsx" ? ".xlsx" : "-Markdown.zip";
    const type =
      format === "xlsx"
        ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        : "application/zip";
    downloadBlob(name + extension, new Blob([bytes], { type }));
    showEditorNotice(
      format === "xlsx"
        ? "画面画像と説明を含むExcelマニュアルを出力しました。"
        : "Markdownマニュアルと番号付き画像をZIPにまとめました。展開して manual.md を開いてください。",
      "ok",
    );
  } catch (error) {
    showEditorNotice("マニュアルの出力に失敗しました：" + error.message, "error");
  } finally {
    buttons.forEach((button) => (button.disabled = false));
  }
}

let actionBusy = false,
  actionResolve = null,
  actionFocus = null;
// 確認・処理中・完了に共用するダイアログを初期化する。処理中はEscで閉じない。
function initActionDialog() {
  const dialog = getElement("actionDialog");
  getElement("actionContinue").onclick = () => closeAction(true);
  getElement("actionCancel").onclick = () => closeAction(false);
  dialog.addEventListener("cancel", (e) => {
    e.preventDefault();
    if (!actionBusy) closeAction(false);
  });
}
// 確認結果を待っている処理へ返す。完了表示を閉じた場合は編集欄へフォーカスを移す。
function closeAction(accepted) {
  if (actionBusy) return;
  getElement("actionDialog").close();
  const resolve = actionResolve;
  actionResolve = null;
  if (resolve) resolve(accepted);
  else if (actionFocus) {
    const target = actionFocus;
    actionFocus = null;
    target.focus();
    target.scrollIntoView({ behavior: "smooth", block: "center" });
  }
}
// ダイアログの文言・アイコン・ボタンを状態に応じて切り替える。
function showAction(kind, title, message, buttonLabel) {
  const dialog = getElement("actionDialog");
  dialog.dataset.kind = kind;
  getElement("actionContinue").classList.remove("confirm-danger");
  actionBusy = kind === "busy";
  getElement("actionIcon").textContent =
    kind === "success" ? "✓" : kind === "error" ? "!" : kind === "confirm" ? "?" : "";
  getElement("actionTitle").textContent = title;
  getElement("actionMessage").textContent = message;
  getElement("actionCancel").hidden = kind !== "confirm";
  getElement("actionContinue").hidden = actionBusy;
  getElement("actionContinue").textContent = buttonLabel || "閉じる";
  if (!dialog.open) dialog.showModal();
  if (!actionBusy) getElement(kind === "confirm" ? "actionCancel" : "actionContinue").focus();
}
// 確認ポップアップの選択を Promise で返す。呼び出し側は true のときだけ保存や削除を実行する。
function confirmAction(title, message, label = "実行する", destructive = false) {
  if (getElement("actionDialog").open) return Promise.resolve(false);
  actionFocus = null;
  showAction("confirm", title, message, label);
  getElement("actionContinue").classList.toggle("confirm-danger", destructive);
  return new Promise((resolve) => {
    actionResolve = resolve;
  });
}
function confirmReplace(title) {
  return confirmAction(
    title,
    "現在の編集内容は置き換わります。保存していない変更は失われます。",
    "置き換えて続ける",
    true,
  );
}
// 背景を覆って処理中を表示し、成功・失敗に応じて結果メッセージを切り替える。
async function runEditorAction(title, work) {
  if (actionBusy) return;
  actionFocus = null;
  showAction("busy", title, "そのままお待ちください。");
  try {
    await new Promise((resolve) => requestAnimationFrame(() => setTimeout(resolve, 0)));
    const result = await work();
    actionFocus = getElement("title");
    showAction("success", result.title, result.message, "編集を始める");
  } catch (error) {
    showEditorNotice(error.message || "処理に失敗しました。", "error");
    showAction(
      "error",
      "読み込み・作成を完了できませんでした",
      error.message || "もう一度お試しください。",
      "閉じる",
    );
  }
}
