/**
 * 外部ライブラリなしでExcelファイルを組み立てる処理。
 * XLSXはXMLと画像をZIPに格納した形式。概要・手順シート、画像、関連付けを一組で生成する。
 */

(function (g) {
  "use strict";
  const te = new TextEncoder();
  function esc(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function col(n) {
    let s = "";
    for (n++; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s;
    return s;
  }
  // ZIPのデータ検証値（CRC32）を高速に計算するための表を用意する。
  function crcTable() {
    const t = [];
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  }
  const CT = crcTable();
  // 各ZIPエントリのCRC32を計算する。
  function crc32(b) {
    let c = 0xffffffff;
    for (const x of b) c = CT[(c ^ x) & 255] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }
  function u16(n) {
    return new Uint8Array([n & 255, (n >>> 8) & 255]);
  }
  function u32(n) {
    return new Uint8Array([n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255]);
  }
  // 複数のバイト列を一つの連続したバイト列にまとめる。
  function cat(parts) {
    const len = parts.reduce((a, b) => a + b.length, 0),
      o = new Uint8Array(len);
    let p = 0;
    for (const b of parts) {
      o.set(b, p);
      p += b.length;
    }
    return o;
  }
  // ファイル本体・一覧・終端情報を持つZIPを作る。圧縮は行わず、日本語名はUTF-8で記録する。
  function zip(entries) {
    const locals = [],
      centrals = [];
    let offset = 0;
    const dosDate = 33,
      dosTime = 0;
    for (const e of entries) {
      const name = te.encode(e.name),
        data = typeof e.data === "string" ? te.encode(e.data) : e.data,
        crc = crc32(data),
        flag = 0x0800;
      const local = cat([
        u32(0x04034b50),
        u16(20),
        u16(flag),
        u16(0),
        u16(dosTime),
        u16(dosDate),
        u32(crc),
        u32(data.length),
        u32(data.length),
        u16(name.length),
        u16(0),
        name,
        data,
      ]);
      locals.push(local);
      const central = cat([
        u32(0x02014b50),
        u16(20),
        u16(20),
        u16(flag),
        u16(0),
        u16(dosTime),
        u16(dosDate),
        u32(crc),
        u32(data.length),
        u32(data.length),
        u16(name.length),
        u16(0),
        u16(0),
        u16(0),
        u16(0),
        u32(0),
        u32(offset),
        name,
      ]);
      centrals.push(central);
      offset += local.length;
    }
    const cd = cat(centrals),
      body = cat(locals),
      end = cat([
        u32(0x06054b50),
        u16(0),
        u16(0),
        u16(entries.length),
        u16(entries.length),
        u32(cd.length),
        u32(body.length),
        u16(0),
      ]);
    return cat([body, cd, end]);
  }
  // セルの位置・値・スタイルをXMLにする。文字列は数式ではなく文字列セルとして格納する。
  function cell(v, r, c, style) {
    const ref = col(c) + (r + 1),
      s = style ? ` s="${style}"` : "";
    if (typeof v === "number" && Number.isFinite(v)) return `<c r="${ref}"${s}><v>${v}</v></c>`;
    return `<c r="${ref}" t="inlineStr"${s}><is><t xml:space="preserve">${esc(v)}</t></is></c>`;
  }
  const XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  const REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
  const PKG = "http://schemas.openxmlformats.org/package/2006/relationships";
  // 一枚のシートに必要な行と画像の入れ物を作る。
  function makeSheet(name) {
    return { name, rows: [], images: [] };
  }
  // 結合セルでは高さが自動調整されないため、文章を明示的に折り返して行を確保する。
  function addText(sheet, value, style = 2) {
    const raw = g.ManualExport.plain(value);
    for (const line of raw.split(/\r?\n/)) {
      // Explicitly wrap merged cells: Excel does not auto-fit merged row heights.
      const chunks = [];
      let current = "",
        width = 0;
      for (const ch of line) {
        const n = ch.charCodeAt(0) > 255 ? 2 : 1;
        if (width + n > (style === 3 ? 60 : 100)) {
          chunks.push(current);
          current = "";
          width = 0;
        }
        current += ch;
        width += n;
      }
      chunks.push(current);
      chunks.forEach((chunk) =>
        sheet.rows.push({ text: chunk, style, height: style === 3 ? 32 : style === 1 ? 26 : 22 }),
      );
    }
  }
  // 行・結合範囲・印刷設定・画像への関連付けをワークシートXMLにする。
  function sheetXml(sheet) {
    const rows = sheet.rows
      .map(
        (row, index) =>
          `<row r="${index + 1}" ht="${row.height}" customHeight="1">${cell(row.text, index, 0, row.style)}</row>`,
      )
      .join("");
    const merges = sheet.rows
      .map((row, index) => (row.text ? `<mergeCell ref="A${index + 1}:H${index + 1}"/>` : ""))
      .filter(Boolean);
    return (
      XML +
      `<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="${REL}"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:H${sheet.rows.length}"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="22"/><cols><col min="1" max="8" width="13" customWidth="1"/></cols><sheetData>${rows}</sheetData><mergeCells count="${merges.length}">${merges.join("")}</mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.3" right="0.3" top="0.4" bottom="0.4" header="0.2" footer="0.2"/><pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="0"/>${sheet.images.length ? '<drawing r:id="rId1"/>' : ""}</worksheet>`
    );
  }
  // 画像を指定行に配置する描画XML。ピクセル寸法をExcelの描画単位へ変換する。
  function drawingXml(images) {
    return (
      XML +
      `<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">` +
      images
        .map((image, i) => {
          const cx = Math.round(image.width * 9525),
            cy = Math.round(image.height * 9525);
          return `<xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${image.row}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:ext cx="${cx}" cy="${cy}"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="${i + 1}" name="画面 ${i + 1}" descr="番号付き操作画面"/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr><xdr:blipFill><a:blip xmlns:r="${REL}" r:embed="rId${i + 1}"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>`;
        })
        .join("") +
      "</xdr:wsDr>"
    );
  }
  // 概要と各手順のシートを作り、PNG画像・XML・関連付けをZIPへまとめてXLSXを返す。
  function build(model) {
    const overview = makeSheet("概要");
    addText(overview, model.title, 3);
    const metadata = [
      ["分類", model.category],
      ["バージョン", model.version],
      ["更新日", model.updated],
      ["担当", model.owner],
    ];
    metadata
      .filter(([, v]) => v)
      .forEach(([label, value]) => addText(overview, label + "：" + value));
    if (model.intro) {
      addText(overview, "");
      addText(overview, "概要・事前に確認すること", 1);
      addText(overview, model.intro);
    }
    addText(overview, "");
    addText(overview, "手順一覧", 1);
    model.steps.forEach((step, i) => addText(overview, `${i + 1}. ${step.title || "操作手順"}`));
    const sheets = [overview];
    model.steps.forEach((step, si) => {
      const sheet = makeSheet(`手順 ${si + 1}`);
      sheets.push(sheet);
      addText(sheet, `手順 ${si + 1}：${step.title || "操作手順"}`, 3);
      addText(sheet, step.body);
      addText(sheet, "");
      step.screens.forEach((screen, sci) => {
        addText(sheet, `画面 ${sci + 1}`, 1);
        const picture = screen.exportImage;
        if (!picture) throw new Error("画面画像が準備できていません。");
        const width = Math.min(750, picture.width),
          height = (width * picture.height) / picture.width;
        sheet.images.push({ data: picture.data, row: sheet.rows.length, width, height });
        for (let i = 0; i < Math.ceil((height * 0.75) / 22) + 1; i++)
          sheet.rows.push({ text: "", style: 0, height: 22 });
        screen.markers.forEach((marker, mi) => {
          addText(sheet, `${mi + 1}. ${marker.item}`, 1);
          const info = [
            marker.type,
            /○|必須/.test(marker.required) ? "必須" : "",
            marker.action ? "操作：" + marker.action : "",
          ].filter(Boolean);
          if (info.length) addText(sheet, info.join(" ／ "));
          if (marker.description) addText(sheet, marker.description);
          if (marker.example) addText(sheet, "入力例：" + marker.example);
          addText(sheet, "");
        });
      });
    });
    const types =
      XML +
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
      sheets
        .map(
          (s, i) =>
            `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>` +
            (s.images.length
              ? `<Override PartName="/xl/drawings/drawing${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>`
              : ""),
        )
        .join("") +
      "</Types>";
    const rootRels =
      XML +
      `<Relationships xmlns="${PKG}"><Relationship Id="rId1" Type="${REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const workbook =
      XML +
      `<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="${REL}"><sheets>` +
      sheets
        .map((s, i) => `<sheet name="${esc(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`)
        .join("") +
      "</sheets><definedNames>" +
      sheets
        .map(
          (s, i) =>
            `<definedName name="_xlnm.Print_Area" localSheetId="${i}">'${esc(s.name)}'!$A$1:$H$${s.rows.length}</definedName>`,
        )
        .join("") +
      "</definedNames></workbook>";
    const wbRels =
      XML +
      `<Relationships xmlns="${PKG}">` +
      sheets
        .map(
          (s, i) =>
            `<Relationship Id="rId${i + 1}" Type="${REL}/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`,
        )
        .join("") +
      `<Relationship Id="rId${sheets.length + 1}" Type="${REL}/styles" Target="styles.xml"/></Relationships>`;
    const styles =
      XML +
      '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Yu Gothic"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Yu Gothic"/></font><font><b/><color rgb="FF17202C"/><sz val="18"/><name val="Yu Gothic"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1D5FA7"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top"/></xf><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="center"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    const entries = [
      { name: "[Content_Types].xml", data: types },
      { name: "_rels/.rels", data: rootRels },
      { name: "xl/workbook.xml", data: workbook },
      { name: "xl/_rels/workbook.xml.rels", data: wbRels },
      { name: "xl/styles.xml", data: styles },
    ];
    sheets.forEach((sheet, i) => {
      entries.push({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(sheet) });
      if (!sheet.images.length) return;
      entries.push({
        name: `xl/worksheets/_rels/sheet${i + 1}.xml.rels`,
        data:
          XML +
          `<Relationships xmlns="${PKG}"><Relationship Id="rId1" Type="${REL}/drawing" Target="../drawings/drawing${i + 1}.xml"/></Relationships>`,
      });
      entries.push({ name: `xl/drawings/drawing${i + 1}.xml`, data: drawingXml(sheet.images) });
      entries.push({
        name: `xl/drawings/_rels/drawing${i + 1}.xml.rels`,
        data:
          XML +
          `<Relationships xmlns="${PKG}">` +
          sheet.images
            .map(
              (image, j) =>
                `<Relationship Id="rId${j + 1}" Type="${REL}/image" Target="../media/image-${i + 1}-${j + 1}.png"/>`,
            )
            .join("") +
          "</Relationships>",
      });
      sheet.images.forEach((image, j) =>
        entries.push({ name: `xl/media/image-${i + 1}-${j + 1}.png`, data: image.data }),
      );
    });
    return zip(entries);
  }
  g.ManualXlsx = { build, zip };
})(typeof window !== "undefined" ? window : globalThis);
