/**
 * 目次とマニュアル閲覧画面の制御。URLに manual がなければ一覧、指定があれば本文を表示する。
 * state は表示対象・表示モード・手順位置を保持する。Excel出力は共有パーサーと出力モジュールを使う。
 */

const state = { manuals: [], current: null, meta: {}, steps: [], mode: "step", stepIndex: 0 };
const getElement = (id) => document.getElementById(id);
document.addEventListener("DOMContentLoaded", init);
// 一覧を取得し、URLから目次または本文を選ぶ。最初のマニュアルを自動では開かない。
async function init() {
  bindViewerActions();
  getElement("catalogSearch").oninput = renderCatalog;
  getElement("catalogList").onclick = (e) => {
    const button = e.target.closest(".catalog-excel");
    if (button) {
      const manual = state.manuals.find((m) => m.id === button.dataset.manualId);
      if (manual) confirmExcelDownload(manual);
    }
  };
  try {
    const response = await fetch("manuals.json");
    if (!response.ok) throw new Error("一覧の取得に失敗しました");
    state.manuals = await response.json();
    if (!Array.isArray(state.manuals)) throw new Error("一覧の形式が不正です");
    getElement("manualSelect").innerHTML = state.manuals
      .map((m) => '<option value="' + escapeHtml(m.id) + '">' + escapeHtml(m.title) + "</option>")
      .join("");
    const id = new URLSearchParams(location.search).get("manual");
    const selected = state.manuals.find((m) => m.id === id);
    renderCatalog();
    if (selected) {
      document.body.classList.remove("catalog-mode");
      try {
        await loadManual(selected.id);
      } catch {
        getElement("content").innerHTML =
          '<p>マニュアルを読み込めませんでした。</p><p><a href="index.html">マニュアル目次に戻る</a></p>';
      }
    } else if (id) {
      getElement("catalogMessage").textContent =
        "指定されたマニュアルが見つかりません。目次から選び直してください。";
    }
  } catch {
    getElement("catalogMessage").textContent =
      "目次を読み込めません。start.bat で起動してから再読み込みしてください。";
  }
}
// 名前で一覧を絞り込み、読むリンクとマニュアルごとのExcelボタンを作る。
function renderCatalog() {
  const query = getElement("catalogSearch").value.trim().toLocaleLowerCase();
  const matches = state.manuals.filter((m) =>
    String(m.title || m.id)
      .toLocaleLowerCase()
      .includes(query),
  );
  getElement("catalogCount").textContent = matches.length + " 件";
  getElement("catalogMessage").textContent = !state.manuals.length
    ? "マニュアルはまだ登録されていません。「新規作成」から作成できます。"
    : !matches.length
      ? "該当するマニュアルがありません。検索語を変えてください。"
      : "";
  getElement("catalogList").innerHTML = matches
    .map(
      (m, i) =>
        '<li><a href="?manual=' +
        encodeURIComponent(m.id) +
        '"><span class="catalog-number">' +
        String(i + 1).padStart(2, "0") +
        '</span><span class="catalog-title">' +
        escapeHtml(m.title || m.id) +
        '</span><span class="catalog-open">読む →</span></a><button type="button" class="catalog-excel" data-manual-id="' +
        escapeHtml(m.id) +
        '" aria-label="' +
        escapeHtml(m.title || m.id) +
        'をExcelでダウンロード">Excelダウンロード</button></li>',
    )
    .join("");
}
// 閲覧モード・前後移動・検索・画像拡大などのボタンを処理に結び付ける。
function bindViewerActions() {
  getElement("manualSelect").addEventListener("change", (e) => {
    location.href = "?manual=" + encodeURIComponent(e.target.value);
  });
  getElement("stepModeBtn").onclick = () => setMode("step");
  getElement("allModeBtn").onclick = () => setMode("all");
  getElement("prevBtn").onclick = () => navigateStep(state.stepIndex - 1);
  getElement("nextBtn").onclick = () => navigateStep(state.stepIndex + 1);
  getElement("downloadExcelBtn").onclick = () => confirmExcelDownload();
  getElement("searchInput").oninput = (e) => searchCurrent(e.target.value);
  getElement("dialogClose").onclick = () => getElement("imageDialog").close();
}
// 本文を読み込み、表示用HTMLとExcel出力用データを準備する。
async function loadManual(id) {
  state.current = state.manuals.find((m) => m.id === id);
  if (!state.current) return;
  getElement("manualSelect").value = id;
  history.replaceState(null, "", `?manual=${encodeURIComponent(id)}`);
  const res = await fetch(state.current.path);
  if (!res.ok) throw new Error("マニュアルを取得できません");
  const raw = await res.text();
  const p = parseFM(raw);
  state.exportModel = ManualParser.parse(raw, state.current.base);
  state.exportModel.title = state.exportModel.title || state.current.title;
  state.meta = p.meta;
  getElement("manualMeta").innerHTML = renderMeta(p.meta);
  getElement("content").innerHTML = mdToHtml(p.body, state.current.base);
  enhanceScreenMaps();
  buildSteps();
  buildTOC();
  setMode(state.mode);
  getElement("searchInput").value = "";
  getElement("downloadExcelBtn").disabled = false;
}
// Markdown冒頭の属性情報と本文を分ける。
function parseFM(t) {
  const m = {};
  if (t.startsWith("---")) {
    const e = t.indexOf("\n---", 3);
    if (e !== -1) {
      t.slice(3, e)
        .trim()
        .split(/\r?\n/)
        .forEach((l) => {
          const i = l.indexOf(":");
          if (i > 0) m[l.slice(0, i).trim()] = l.slice(i + 1).trim();
        });
      return { meta: m, body: t.slice(e + 4).replace(/^\s+/, "") };
    }
  }
  return { meta: m, body: t };
}
// タイトル・分類・版・更新日・担当を閲覧用に表示する。
function renderMeta(m) {
  return `<h2>${escapeHtml(m.title || state.current.title)}</h2><div class="meta-row">${m.category ? `<span class="meta-chip">分類: ${escapeHtml(m.category)}</span>` : ""}${m.version ? `<span class="meta-chip">版: ${escapeHtml(m.version)}</span>` : ""}${m.updated ? `<span class="meta-chip">更新: ${escapeHtml(m.updated)}</span>` : ""}${m.owner ? `<span class="meta-chip">担当: ${escapeHtml(m.owner)}</span>` : ""}</div>`;
}
// このツールが扱う見出し・箇条書き・表・注意書きをHTMLへ変換する。汎用Markdownの全記法には対応しない。
function mdToHtml(md, base) {
  const L = md.replace(/\r/g, "").split("\n"),
    o = [];
  let i = 0,
    list = null;
  const close = () => {
    if (list) {
      o.push(`</${list}>`);
      list = null;
    }
  };
  while (i < L.length) {
    let l = L[i];
    const c = l.match(/^>\s*\[!(NOTE|TIP|WARNING)\]/i);
    if (c) {
      close();
      const type = c[1].toLowerCase(),
        b = [];
      i++;
      while (i < L.length && L[i].startsWith(">")) {
        b.push(L[i].replace(/^>\s?/, ""));
        i++;
      }
      o.push(
        `<div class="callout ${type}"><div class="callout-title">${{ note: "補足", tip: "ヒント", warning: "注意" }[type]}</div>${inline(b.join("<br>"), base)}</div>`,
      );
      continue;
    }
    const h = l.match(/^(#{1,6})\s+(.+)$/);
    if (h) {
      close();
      const n = h[1].length,
        t = h[2].trim(),
        id = slug(t);
      if (n === 2 && /^STEP\s*\d+/i.test(t))
        o.push(`<div class="step-start" data-step-title="${escapeHtml(t)}"></div>`);
      o.push(`<h${n} id="${id}">${inline(t, base)}</h${n}>`);
      i++;
      continue;
    }
    if (isTable(L, i)) {
      close();
      const H = splitRow(L[i]);
      i += 2;
      const R = [];
      while (i < L.length && /^\s*\|/.test(L[i])) {
        R.push(splitRow(L[i]));
        i++;
      }
      const N = H.map((x) => x.replace(/\s/g, "").toLowerCase()),
        sm = ["no", "x", "y", "項目", "説明"].every((k) => N.includes(k));
      o.push(
        `<table${sm ? ' data-screenmap-table="true"' : ""}><thead><tr>${H.map((x) => `<th>${inline(x, base)}</th>`).join("")}</tr></thead><tbody>${R.map((r) => `<tr>${r.map((x) => `<td>${inline(x, base)}</td>`).join("")}</tr>`).join("")}</tbody></table>`,
      );
      continue;
    }
    if (/^\s*[-*]\s+/.test(l)) {
      if (list !== "ul") {
        close();
        list = "ul";
        o.push("<ul>");
      }
      o.push(`<li>${inline(l.replace(/^\s*[-*]\s+/, ""), base)}</li>`);
      i++;
      continue;
    }
    if (!l.trim()) {
      close();
      i++;
      continue;
    }
    close();
    const p = [l];
    i++;
    while (i < L.length && L[i].trim() && !/^(#{1,6}\s+|>\s*\[!|\s*[-*]\s+|\s*\|)/.test(L[i])) {
      p.push(L[i]);
      i++;
    }
    o.push(`<p>${inline(p.join(" "), base)}</p>`);
  }
  close();
  return o.join("\n");
}
// 本文中の画像・太字・コード表記を変換する。最初にHTML特殊文字をエスケープする。
function inline(t, b) {
  let s = escapeHtml(t);
  s = s.replace(
    /!\[([^\]]*)\]\(([^)]+)\)/g,
    (_, a, p) => `<img src="${escapeHtml(resolve(b, p))}" alt="${a}">`,
  );
  s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
  return s;
}
function resolve(b, p) {
  if (/^(https?:|data:|blob:|\/)/.test(p)) return p;
  return `${b}/${p}`.replace(/\/+/g, "/");
}
function isTable(L, i) {
  return /^\s*\|/.test(L[i] || "") && /^\s*\|?\s*:?-+/.test(L[i + 1] || "");
}
function splitRow(l) {
  return l
    .trim()
    .replace(/^\||\|$/g, "")
    .split("|")
    .map((x) => x.trim());
}
// 画像の座標表を番号付き画面と説明カードへ置き換え、選択状態を連動させる。
function enhanceScreenMaps() {
  document.querySelectorAll('table[data-screenmap-table="true"]').forEach((table) => {
    const H = [...table.querySelectorAll("th")].map((x) =>
        x.textContent.trim().replace(/\s/g, "").toLowerCase(),
      ),
      idx = Object.fromEntries(H.map((h, i) => [h, i])),
      R = [...table.querySelectorAll("tbody tr")].map((tr) =>
        [...tr.children].map((td) => td.innerHTML),
      );
    let p = table.previousElementSibling;
    while (p && !p.querySelector?.("img")) p = p.previousElementSibling;
    const img = p?.querySelector?.("img");
    if (!img) return;
    const sec = document.createElement("section");
    sec.className = "screenmap";
    const vis = document.createElement("div");
    vis.className = "screenmap-visual";
    vis.innerHTML =
      '<div class="screenmap-titlebar"><span class="screenmap-hint">番号と説明が連動します</span><button class="screenmap-zoom">画像を拡大</button></div><div class="screenmap-canvas"></div>';
    const can = vis.querySelector(".screenmap-canvas"),
      cl = img.cloneNode(true);
    can.appendChild(cl);
    const list = document.createElement("div");
    list.className = "screenmap-list";
    R.forEach((c, n) => {
      const no = c[idx.no] || n + 1,
        x = Number(strip(c[idx.x])) || 50,
        y = Number(strip(c[idx.y])) || 50,
        item = c[idx["項目"]] || "",
        desc = c[idx["説明"]] || "",
        type = idx["種類"] !== undefined ? c[idx["種類"]] : "",
        req = idx["必須"] !== undefined ? c[idx["必須"]] : "",
        act = idx["操作"] !== undefined ? c[idx["操作"]] : "",
        ex = idx["入力例"] !== undefined ? c[idx["入力例"]] : "";
      const m = document.createElement("button");
      m.className = "screenmap-marker";
      m.style.left = x + "%";
      m.style.top = y + "%";
      m.textContent = strip(no);
      can.appendChild(m);
      const card = document.createElement("article");
      card.className = "screenmap-card";
      card.innerHTML = `<div class="screenmap-card-head"><div class="screenmap-no">${no}</div><div><div class="screenmap-card-title">${item}</div><div class="screenmap-card-sub">${type}</div></div></div><div class="screenmap-card-body">${desc}<div class="screenmap-meta">${req ? `<span class="${/○|必須/.test(strip(req)) ? "required" : ""}">${/○|必須/.test(strip(req)) ? "必須" : "任意"}</span>` : ""}${act ? `<span>操作: ${act}</span>` : ""}</div>${ex ? `<div class="screenmap-note">入力例: ${ex}</div>` : ""}</div>`;
      list.appendChild(card);
    });
    sec.append(vis, list);
    table.before(sec);
    table.remove();
    p.remove();
    const M = [...sec.querySelectorAll(".screenmap-marker")],
      C = [...sec.querySelectorAll(".screenmap-card")],
      act = (n) => {
        M.forEach((x, i) => x.classList.toggle("active", i === n));
        C.forEach((x, i) => x.classList.toggle("active", i === n));
      };
    M.forEach((x, i) => {
      x.onclick = () => {
        act(i);
        C[i].scrollIntoView({ behavior: "smooth", block: "center" });
      };
      x.onmouseenter = () => act(i);
    });
    C.forEach((x, i) => {
      x.onclick = () => act(i);
      x.onmouseenter = () => act(i);
    });
    if (M.length) act(0);
    vis.querySelector(".screenmap-zoom").onclick = () => {
      getElement("dialogImage").src = cl.src;
      getElement("imageDialog").showModal();
    };
  });
}
// STEP見出しごとに本文をまとめ、先頭の概要は折りたためる領域に移す。
function buildSteps() {
  const content = getElement("content"),
    starts = [...content.querySelectorAll(".step-start")];
  state.steps = [];
  starts.forEach((marker, i) => {
    const section = document.createElement("section");
    section.className = "step-card";
    section.id = "step-" + (i + 1);
    marker.replaceWith(section);
    let node = section.nextSibling;
    while (node && !(node.nodeType === 1 && node.classList.contains("step-start"))) {
      const next = node.nextSibling;
      section.appendChild(node);
      node = next;
    }
    state.steps.push(section);
  });
  const intro = document.createElement("details");
  intro.className = "manual-intro";
  intro.id = "manual-overview";
  const summary = document.createElement("summary");
  summary.textContent = "概要・事前に確認すること";
  intro.appendChild(summary);
  while (content.firstChild && !content.firstChild.classList?.contains("step-card"))
    intro.appendChild(content.firstChild);
  const title = intro.querySelector("h1");
  if (title?.textContent.trim() === (state.meta.title || state.current.title)) title.remove();
  if (intro.children.length > 1 || intro.textContent.trim() !== summary.textContent) {
    content.prepend(intro);
    intro.open = !state.steps.length;
  }
  state.stepIndex = 0;
}
let tocObserver;
// 手順の見出しからナビを作り、表示位置を監視して現在地を強調する。
function buildTOC() {
  tocObserver?.disconnect();
  const headings = [...getElement("content").querySelectorAll("h1,h2,h3")];
  headings.forEach((h, i) => {
    h.id = "section-" + (i + 1);
    h.tabIndex = -1;
  });
  const targets = [];
  if (getElement("manual-overview"))
    targets.push({ id: "manual-overview", text: "概要・事前確認", level: 2 });
  headings
    .filter((h) => !h.closest(".manual-intro"))
    .forEach((h) => {
      const step = h.closest(".step-card");
      if (step && h.tagName === "H3" && h === step.querySelector("h3")) return;
      const subtitle =
        step && h === step.querySelector("h2") ? step.querySelector("h3")?.textContent : "";
      targets.push({
        id: h.id,
        text: h.textContent + (subtitle ? "　" + subtitle : ""),
        level: Number(h.tagName.slice(1)),
      });
    });
  getElement("toc").innerHTML = targets
    .map((t) => '<a class="lv' + t.level + '" href="#' + t.id + '">' + escapeHtml(t.text) + "</a>")
    .join("");
  getElement("toc").onclick = (e) => {
    const link = e.target.closest("a");
    if (!link) return;
    e.preventDefault();
    navigateTo(link.hash.slice(1));
  };
  tocObserver = new IntersectionObserver(
    (entries) => {
      const entry = entries.find((e) => e.isIntersecting && !e.target.closest(".hidden"));
      if (entry) markToc(entry.target.id);
    },
    { rootMargin: "-60px 0px -65% 0px", threshold: 0 },
  );
  targets.forEach((t) => tocObserver.observe(getElement(t.id)));
}
function markToc(id) {
  getElement("toc")
    .querySelectorAll("a")
    .forEach((a) => {
      const active = a.hash === "#" + id;
      a.classList.toggle("active", active);
      if (active) a.setAttribute("aria-current", "location");
      else a.removeAttribute("aria-current");
    });
}
// ステップ表示では移動先の手順を先に表示し、スクロールとフォーカスを移す。
function navigateTo(id) {
  const target = getElement(id);
  if (!target) return;
  const step = target.closest(".step-card");
  if (step && state.mode === "step") showStep(state.steps.indexOf(step));
  const intro = target.closest(".manual-intro");
  if (intro) intro.open = true;
  target.scrollIntoView({ behavior: "smooth", block: "start" });
  const focus = target.matches("details") ? target.querySelector("summary") : target;
  focus.focus({ preventScroll: true });
  markToc(id);
}
// 一つずつ読むステップ表示と全体表示を切り替える。
function setMode(mode) {
  state.mode = mode;
  ["step", "all"].forEach((m) => {
    const b = getElement(m + "ModeBtn");
    b.classList.toggle("active", mode === m);
    b.setAttribute("aria-pressed", String(mode === m));
  });
  getElement("stepNav").classList.toggle("hidden", mode !== "step" || !state.steps.length);
  if (mode === "all") state.steps.forEach((x) => x.classList.remove("hidden"));
  else showStep(state.stepIndex);
}
// 手順番号を有効範囲に収め、表示対象と前後ボタンの状態を更新する。
function showStep(n) {
  if (!state.steps.length) return;
  state.stepIndex = Math.max(0, Math.min(n, state.steps.length - 1));
  state.steps.forEach((x, i) =>
    x.classList.toggle("hidden", state.mode === "step" && i !== state.stepIndex),
  );
  getElement("stepCounter").textContent =
    "手順 " + (state.stepIndex + 1) + " / " + state.steps.length;
  getElement("prevBtn").disabled = state.stepIndex === 0;
  getElement("nextBtn").disabled = state.stepIndex === state.steps.length - 1;
  const heading = state.steps[state.stepIndex].querySelector("h2,h3");
  if (heading) markToc(heading.id);
}
function navigateStep(n) {
  showStep(n);
  const heading = state.steps[state.stepIndex]?.querySelector("h2,h3");
  if (heading) navigateTo(heading.id);
}
let printIntroOpen = false;
window.addEventListener("beforeprint", () => {
  state.steps.forEach((s) => s.classList.remove("hidden"));
  const intro = getElement("manual-overview");
  if (intro) {
    printIntroOpen = intro.open;
    intro.open = true;
  }
});
window.addEventListener("afterprint", () => {
  setMode(state.mode);
  if (getElement("manual-overview")) getElement("manual-overview").open = printIntroOpen;
});
// 本文内の最初の一致箇所を探す。必要なら概要や非表示の手順を開いてから移動する。
function searchCurrent(q) {
  document.querySelectorAll(".search-hit").forEach((x) => x.classList.remove("search-hit"));
  q = q.trim().toLowerCase();
  if (!q) return;
  const intro = getElement("manual-overview");
  if (intro && intro.textContent.toLowerCase().includes(q)) intro.open = true;
  if (state.mode === "step") {
    const n = state.steps.findIndex((x) => x.textContent.toLowerCase().includes(q));
    if (n >= 0) showStep(n);
  }
  const h = [...getElement("content").querySelectorAll("h1,h2,h3,p,li,.screenmap-card")].find(
    (x) => x.offsetParent !== null && x.textContent.toLowerCase().includes(q),
  );
  if (h) {
    h.classList.add("search-hit");
    h.scrollIntoView({ behavior: "smooth", block: "center" });
  }
}
function strip(h = "") {
  const d = document.createElement("div");
  d.innerHTML = h;
  return d.textContent.trim();
}
function slug(t) {
  return (
    "h-" +
    t
      .toLowerCase()
      .replace(/[^\p{L}\p{N}]+/gu, "-")
      .replace(/^-|-$/g, "")
  );
}
function escapeHtml(value = "") {
  return BrowserUtils.escapeHtml(value);
}

let excelBusy = false;
// 目次・本文から共用する出力確認。目次では対象本文の取得を実行承認後まで待つ。
function confirmExcelDownload(manual = null) {
  if ((!manual && !state.exportModel) || excelBusy) return;
  const dialog = getElement("excelDialog");
  getElement("excelTitle").textContent = "Excelをダウンロードしますか？";
  getElement("excelMessage").textContent =
    "「" +
    (manual ? manual.title : state.exportModel.title) +
    "」の全手順・番号付き画像・説明をExcelにまとめます。";
  getElement("excelCancel").hidden = false;
  getElement("excelConfirm").hidden = false;
  getElement("excelConfirm").textContent = "ダウンロードする";
  getElement("excelCancel").onclick = () => dialog.close();
  dialog.oncancel = (e) => {
    if (excelBusy) e.preventDefault();
  };
  getElement("excelConfirm").onclick = () => downloadViewerExcel(manual);
  dialog.showModal();
  getElement("excelCancel").focus();
}
// 対象の全手順を画像付きExcelへ変換する。表示中の一手順だけを出力する処理ではない。
async function downloadViewerExcel(manual = null) {
  if (excelBusy) return;
  excelBusy = true;
  getElement("downloadExcelBtn").disabled = true;
  getElement("excelCancel").hidden = true;
  getElement("excelConfirm").hidden = true;
  getElement("excelTitle").textContent = "Excelを作成しています";
  getElement("excelMessage").textContent = "画像と説明をまとめています。そのままお待ちください。";
  try {
    await new Promise((resolve) => requestAnimationFrame(() => setTimeout(resolve, 0)));
    let exportModel = state.exportModel;
    if (manual) {
      const response = await fetch(manual.path);
      if (!response.ok)
        throw new Error("マニュアルを読み込めませんでした。保存先を確認してください。");
      exportModel = ManualParser.parse(await response.text(), manual.base);
      exportModel.title = exportModel.title || manual.title;
    }
    const prepared = await ManualExport.prepare(exportModel);
    const bytes = ManualXlsx.build(prepared);
    const name = BrowserUtils.downloadName(prepared.title || "manual");
    const url = URL.createObjectURL(
      new Blob([bytes], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = name + ".xlsx";
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    getElement("excelTitle").textContent = "Excelを出力しました";
    getElement("excelMessage").textContent =
      "ブラウザのダウンロード一覧からファイルを開いてください。";
  } catch (error) {
    getElement("excelTitle").textContent = "出力できませんでした";
    getElement("excelMessage").textContent =
      error.message || "画像やマニュアルのファイルを確認してください。";
  } finally {
    excelBusy = false;
    getElement("downloadExcelBtn").disabled = !state.exportModel;
    getElement("excelConfirm").hidden = false;
    getElement("excelConfirm").textContent = "閉じる";
    getElement("excelConfirm").onclick = () => getElement("excelDialog").close();
    getElement("excelConfirm").focus();
  }
}
