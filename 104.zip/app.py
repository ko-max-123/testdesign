"""Evidence Organizer Simple - just Excel, markers, sorting. Python 3.11+."""
from __future__ import annotations
import os
import queue
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk

from excel_catalog import WorkbookCatalog, canonical_case_name
from evidence_core import HEIF_AVAILABLE, QR_AVAILABLE, component, load_sessions, id_folder_name
from simple_engine import options_from_catalog, make_start, make_end, sort_folder

ROOT = Path.home() / 'EvidenceOrganizer作業'


class SimpleApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Evidence Organizer - シンプル版 v0.3.3')
        width = min(760, max(520, self.winfo_screenwidth()-90))
        height = min(720, max(480, self.winfo_screenheight()-120))
        self.geometry(f'{width}x{height}')
        self.minsize(510,430)
        self.option_add('*Font', ('Yu Gothic UI', 10))
        style=ttk.Style(self)
        if 'vista' in style.theme_names(): style.theme_use('vista')
        style.configure('Big.TButton', padding=(10,10), font=('Yu Gothic UI',10,'bold'))
        style.configure('Title.TLabel', font=('Yu Gothic UI',17,'bold'))
        style.configure('Step.TLabel', font=('Yu Gothic UI',12,'bold'))
        style.configure('Hint.TLabel', foreground='#526678')
        self.book = None
        self.scenarios = []
        self.session = None
        self.mark_win = None
        self.preview_photo = None
        self.events = queue.Queue()
        self.busy = False
        self.book_path = tk.StringVar(value='まだ読み込んでいません')
        self.feature_var = tk.StringVar()
        self.scenario_var = tk.StringVar()
        self.expect_var = tk.StringVar()
        self.make_id_folder_var = tk.BooleanVar(value=False)
        self.photo_folder = tk.StringVar(value='まだ選択していません')
        self.state_text = tk.StringVar(value='最初にExcelのテスト仕様書を選んでください。')
        self.result_text = tk.StringVar(value='')
        self.path_preview = tk.StringVar(value='作成フォルダ：案件名 / 仕様書名 / P1-1 / And・iOS')
        self.root_dir = ROOT
        existing_sessions = load_sessions(self.root_dir)
        self.session = (existing_sessions[-1] if existing_sessions and canonical_case_name(existing_sessions[-1].scenario) else None)
        self._build()
        self.after(90, self._poll)

    def _build(self):
        wrapper = ttk.Frame(self)
        wrapper.pack(fill='both',expand=True)
        canvas = tk.Canvas(wrapper, highlightthickness=0, borderwidth=0)
        sb = ttk.Scrollbar(wrapper,orient='vertical',command=canvas.yview)
        sb.pack(side='right',fill='y'); canvas.pack(side='left',fill='both',expand=True)
        canvas.configure(yscrollcommand=sb.set)
        inner = ttk.Frame(canvas,padding=(18,12,18,18))
        item = canvas.create_window((0,0),window=inner,anchor='nw')
        def resized(_=None):
            canvas.itemconfigure(item,width=max(300,canvas.winfo_width()))
            canvas.configure(scrollregion=canvas.bbox('all'))
        canvas.bind('<Configure>',resized)
        inner.bind('<Configure>', lambda e:canvas.after_idle(resized))
        def wheel(e):
            canvas.yview_scroll(-1 if e.delta>0 else 1,'units')
        for w in (canvas,inner):w.bind('<MouseWheel>',wheel)
        self.bind_all('<MouseWheel>',wheel,add='+')
        self.canvas=canvas
        self.inner=inner
        ttk.Label(inner,text='Evidence Organizer',style='Title.TLabel').pack(anchor='w')
        ttk.Label(inner,text='Excelを選び、しおりを撮影し、写真をまとめて整理するだけ。',style='Hint.TLabel').pack(anchor='w',pady=(3,15))

        part1 = ttk.LabelFrame(inner,text='  1  テスト仕様書を読み込む  ',padding=13)
        part1.pack(fill='x',pady=(0,13))
        ttk.Button(part1,text='Excelファイルを選ぶ',command=self._open_excel,style='Big.TButton').pack(fill='x',pady=(0,7))
        self.book_label=ttk.Label(part1,textvariable=self.book_path,style='Hint.TLabel')
        self.book_label.pack(fill='x',pady=(0,7))
        r=ttk.Frame(part1);r.pack(fill='x',pady=(0,7))
        ttk.Label(r,text='機能（案件名）',width=14).pack(side='left')
        ttk.Entry(r,textvariable=self.feature_var).pack(side='left',fill='x',expand=True)
        ttk.Label(part1,text='ケース名（P1-1形式。Excelにない場合は入力）').pack(anchor='w')
        self.scenario_combo=ttk.Combobox(part1,state='normal',textvariable=self.scenario_var)
        self.scenario_combo.pack(fill='x',pady=(2,7))
        self.scenario_combo.bind('<<ComboboxSelected>>',self._scenario_changed)
        self.scenario_var.trace_add('write',lambda *_:self._scenario_changed())
        ttk.Label(part1,text='期待値ID（任意・しおりに記載）').pack(anchor='w')
        self.expect_combo=ttk.Combobox(part1,state='readonly',textvariable=self.expect_var)
        self.expect_combo.pack(fill='x',pady=(2,5))
        ttk.Checkbutton(part1,text='期待値IDごとにIDフォルダを作る（通常は不要）',variable=self.make_id_folder_var,command=self._refresh).pack(anchor='w',pady=(0,6))
        ttk.Label(part1,textvariable=self.path_preview,style='Hint.TLabel',wraplength=600).pack(anchor='w')
        self.expect_combo.bind('<<ComboboxSelected>>',lambda _e:self._refresh())
        self.feature_var.trace_add('write',lambda *_: self._refresh())

        part2=ttk.LabelFrame(inner,text='  2  しおりを撮影する  ',padding=13)
        part2.pack(fill='x',pady=(0,13))
        ttk.Label(part2,text='撮影開始前に「開始」、撮影後に「終了」を押して、表示されたしおりをiPhoneで撮影してください。',wraplength=620,style='Hint.TLabel').pack(anchor='w',pady=(0,9))
        controls=ttk.Frame(part2);controls.pack(fill='x')
        controls.columnconfigure(0,weight=1); controls.columnconfigure(1,weight=1)
        self.start_button=ttk.Button(controls,text='開始しおりを表示',command=self._start,style='Big.TButton')
        self.start_button.grid(row=0,column=0,sticky='ew',padx=(0,5))
        self.end_button=ttk.Button(controls,text='終了しおりを表示',command=self._end,style='Big.TButton')
        self.end_button.grid(row=0,column=1,sticky='ew',padx=(5,0))
        self.shiori_info=ttk.Label(part2,text='Excelから対象を選ぶと作成できます。',style='Hint.TLabel')
        self.shiori_info.pack(anchor='w',pady=(8,0))

        part3=ttk.LabelFrame(inner,text='  3  撮影画像を自動整理する  ',padding=13)
        part3.pack(fill='x',pady=(0,8))
        ttk.Label(part3,text='画像としおりの入ったフォルダを選びます。整理結果もこのフォルダ内に作ります。',wraplength=620,style='Hint.TLabel').pack(anchor='w',pady=(0,8))
        ttk.Button(part3,text='撮影画像フォルダを選ぶ',command=self._choose_images).pack(fill='x',pady=(0,6))
        self.photo_label=ttk.Label(part3,textvariable=self.photo_folder,style='Hint.TLabel')
        self.photo_label.pack(anchor='w',fill='x',pady=(0,8))
        self.sort_button=ttk.Button(part3,text='And・iOSフォルダへ自動整理',command=self._sort,style='Big.TButton')
        self.sort_button.pack(fill='x',pady=(0,7))
        ttk.Label(part3,text='カメラ撮影EXIFを優先してAnd／iOSを判定。不明な画像は保留します。元画像は変更しません。',style='Hint.TLabel').pack(anchor='w')
        self.result_label=ttk.Label(part3,textvariable=self.result_text,justify='left',wraplength=620)
        self.result_label.pack(anchor='w',fill='x',pady=(8,1))
        self.save_label=ttk.Label(inner,text='保存先：Step 3で選択した画像フォルダ内',style='Hint.TLabel')
        self.save_label.pack(anchor='w',pady=(7,2))
        ttk.Label(inner,textvariable=self.state_text,style='Hint.TLabel',wraplength=630).pack(anchor='w',fill='x',pady=(3,6))
        self._refresh()

    def _open_excel(self):
        path = filedialog.askopenfilename(title='テスト仕様書を選ぶ',filetypes=[('Excel','*.xlsx *.xlsm')])
        if not path:return
        try:
            book=WorkbookCatalog.from_file(Path(path))
            scenarios=options_from_catalog(book)
            self.book=book
            self.scenarios=scenarios
            self.book_path.set(Path(path).name)
            self.feature_var.set(book.feature)
            self.scenario_combo.configure(values=[sc[0] for sc in scenarios])
            self.scenario_var.set(scenarios[0][0] if scenarios else '')
            self.make_id_folder_var.set(False)
            self._scenario_changed()
            if scenarios:
                self.state_text.set('ケース名を選んで、開始しおりを表示してください。')
            else:
                self.state_text.set('Excelに P1-1形式のケース名がありません。ケース名を入力してください（No=1などは使いません）。')
        except Exception as ex:
            messagebox.showerror('Excelを読み込めません',str(ex))
        self._refresh()

    def _scenario_changed(self,_=None):
        option=next((v for v in self.scenarios if v[0]==self.scenario_var.get()),None)
        if option:
            ids=option[3]
        elif self.book and not self.scenarios:
            # Excel may have expected IDs but no Pn-n case, e.g. the second example.
            ids=next((s.all_expected_ids() for s in self.book.sheets if s.expected_col),[])
        else:
            ids=[]
        choices=['（指定しない）']+list(ids)
        self.expect_combo.configure(values=choices)
        self.expect_var.set('（指定しない）')
        self._refresh()

    def _expected(self):
        value=self.expect_var.get()
        return '' if value in ('','（指定しない）') else value

    def _chosen_scenario_name(self):
        option=next((v for v in self.scenarios if v[0]==self.scenario_var.get()),None)
        raw=option[2] if option else self.scenario_var.get().strip()
        return canonical_case_name(raw)

    def _refresh(self):
        valid_case=self._chosen_scenario_name()
        expected=self._expected()
        if self.book and valid_case:
            parts=[self.feature_var.get(),self.book.spec,valid_case]
            if self.make_id_folder_var.get() and expected:
                parts.append(id_folder_name(expected))
            parts.append('And・iOS')
            self.path_preview.set('作成フォルダ：'+' / '.join(parts))
        elif self.book:
            self.path_preview.set('ケース名は P1-1 の形式で指定してください（数字のみは不可）。')
        can_start=bool(self.book and valid_case and self.feature_var.get().strip()
                       and (not self.make_id_folder_var.get() or bool(expected)))
        self.start_button.configure(state='normal' if can_start and not self.busy else 'disabled')
        self.end_button.configure(state='normal' if self.session and not self.busy else 'disabled')
        self.sort_button.configure(state='normal' if self.photo_folder.get()!='まだ選択していません' and not self.busy else 'disabled')

    def _chosen(self):
        case=self._chosen_scenario_name()
        if not case:
            raise ValueError('ケース名を P1-1 の形式で指定してください。')
        option=next((v for v in self.scenarios if v[0]==self.scenario_var.get()),None)
        if option:
            sheet=option[1]
        elif self.book:
            sheet=next((s.name for s in self.book.sheets if s.expected_col),self.book.sheets[0].name)
        else:
            raise ValueError('先にExcelを読み込んでください。')
        return sheet,case

    def _start(self):
        try:
            sheet,case=self._chosen()
            feature=component(self.feature_var.get(),'機能（案件名）')
            session,path=make_start(self.root_dir,feature,self.book.spec,sheet,case,
                                    self._expected(),create_id_folder=self.make_id_folder_var.get())
            self.session=session
            self.shiori_info.configure(text=f'撮影対象：{case} / 期待値ID：{session.expect_start or "指定なし"}')
            self.state_text.set('開始しおりを作成しました。表示された画像をiPhoneのカメラで撮影してください。')
            self._show_marker(path,'開始しおり')
        except Exception as ex: messagebox.showerror('しおり作成エラー',str(ex))
        self._refresh()

    def _end(self):
        if not self.session:
            messagebox.showwarning('開始しおりがありません','先に開始しおりを作成してください。')
            return
        try:
            path=make_end(self.root_dir,self.session)
            self.state_text.set('終了しおりを作成しました。表示された画像をiPhoneのカメラで撮影してください。')
            self._show_marker(path,'終了しおり')
        except Exception as ex: messagebox.showerror('しおり作成エラー',str(ex))

    def _show_marker(self,path,title):
        if self.mark_win is not None and self.mark_win.winfo_exists():
            self.mark_win.destroy()
        win=tk.Toplevel(self)
        self.mark_win=win
        win.title(f'Evidence Organizer - {title}')
        sw,sh=self.winfo_screenwidth(),self.winfo_screenheight()
        max_w,min_h=min(700,sw-100),min(780,sh-140)
        with Image.open(path) as image:
            size=image.size
            scale=min(max_w/size[0],min_h/size[1],1)
            im=image.resize((max(1,int(size[0]*scale)),max(1,int(size[1]*scale))),Image.Resampling.LANCZOS)
        self.preview_photo=ImageTk.PhotoImage(im)
        win.configure(background='white')
        tk.Label(win,image=self.preview_photo,background='white').pack(padx=8,pady=8)
        win.resizable(False,False)
        win.transient(self)
        win.lift()
        win.focus_force()
        win.bind('<Escape>',lambda e:win.destroy())

    def _choose_images(self):
        dir_=filedialog.askdirectory(title='しおりと撮影画像が入ったフォルダを選ぶ',mustexist=True)
        if dir_:
            self.photo_folder.set(dir_)
            self.state_text.set('撮影画像フォルダを選びました。「自動整理」を押してください。')
            self.save_label.configure(text=f'保存先：{dir_} / 案件名 / 仕様書名 / P1-1 / And・iOS（IDフォルダは任意）')
        self._refresh()

    def _sort(self):
        if not QR_AVAILABLE:
            messagebox.showerror('QR機能がありません','install.batを実行してOpenCVをインストールしてください。');return
        if not HEIF_AVAILABLE and any(p.suffix.lower() in ('.heic','.heif') for p in Path(self.photo_folder.get()).rglob('*') if p.is_file()):
            messagebox.showerror('HEIC対応がありません','HEIC画像を読み取るため、install.batをもう一度実行してください。')
            return
        root=self.root_dir
        imported=Path(self.photo_folder.get())
        self.busy=True; self._refresh()
        self.result_text.set('画像を確認・整理しています...')
        self.state_text.set('写真が多い場合は、完了まで画面をそのままにしてください。')
        def worker():
            try:
                result=sort_folder(imported,root,progress=lambda i,n,name: self.events.put(('progress',f'{i:,}/{n:,}枚を確認中...')) if i==1 or i%50==0 else None,output_root=imported)
                self.events.put(('done',result))
            except Exception as e:
                self.events.put(('error',str(e)))
        threading.Thread(target=worker,daemon=True).start()

    def _poll(self):
        try:
            while True:
                kind,data=self.events.get_nowait()
                if kind=='progress':self.state_text.set(data)
                elif kind=='error':
                    self.busy=False
                    self.result_text.set('整理に失敗しました。')
                    self.state_text.set(data)
                    messagebox.showerror('画像整理エラー',data)
                    self._refresh()
                elif kind=='done':
                    self.busy=False
                    r=data
                    self.result_text.set(f'格納完了：{r.copied:,}枚\nしおり：{r.markers:,}枚（格納対象外）\n要確認：{r.hold:,}枚\n記録：{r.report}')
                    self.state_text.set('整理が終わりました。選択した画像フォルダ内の案件名フォルダを確認してください。')
                    self._refresh()
                    summary=f'格納：{r.copied:,}枚\nしおり：{r.markers:,}枚\n要確認：{r.hold:,}枚\n\n出力先：{self.photo_folder.get()}'
                    if r.hold or r.warnings:
                        summary+='\n\n未分類画像や警告は、管理データの分類履歴CSVで確認してください。'
                    messagebox.showinfo('自動整理が完了しました',summary)
        except queue.Empty:
            pass
        self.after(120,self._poll)


if __name__=='__main__':
    SimpleApp().mainloop()
