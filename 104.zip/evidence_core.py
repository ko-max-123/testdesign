"""Evidence Organizer core. Never renames or modifies imported evidence files."""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import shutil
import tempfile
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from PIL import Image, ImageDraw, ImageFont, ImageOps
from excel_catalog import canonical_case_name
import qrcode

try:
    from pillow_heif import register_heif_opener
    register_heif_opener()
    HEIF_AVAILABLE = True
except ImportError:
    HEIF_AVAILABLE = False

try:
    import cv2
    import numpy as np
    QR_AVAILABLE = True
except ImportError:
    QR_AVAILABLE = False

IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.heic', '.heif', '.webp', '.bmp', '.tif', '.tiff'}
QR_PATTERN = re.compile(r'^EO1:([a-f0-9]{12}):(START|END)$')
WINDOWS_RESERVED = {'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}


def component(name: str, label: str, optional: bool = False) -> str:
    name = name.strip()
    if optional and not name:
        return ''
    if not name or name in {'.', '..'} or re.search(r'[<>:"/\\|?*\x00-\x1f]', name) or name.endswith((' ', '.')) or name.split('.')[0].upper() in WINDOWS_RESERVED:
        raise ValueError(f'{label}にフォルダ名として使えない文字または値があります: {name!r}')
    return name


def spec_folder_name(filename: str) -> str:
    # Old marker records can contain .xlsx/.xlsm; do not carry extensions into output paths.
    filename = str(filename).strip()
    cleaned = re.sub(r'\.(xlsx|xlsm|xls)$', '', filename, flags=re.IGNORECASE)
    return component(cleaned, 'テスト仕様書名')


def id_folder_name(expected_id: str) -> str:
    # Expected-value IDs are labels for an entire photo batch, not per-photo IDs.
    value = component(str(expected_id), '期待値ID')
    if re.match(r'^ID', value, flags=re.IGNORECASE):
        return 'ID' + value[2:]
    return 'ID' + value


def workspace_paths(root: Path) -> tuple[Path, Path]:
    root = Path(root)
    return root / '管理データ', root / 'エビデンス'


def load_sessions(root: Path) -> list['Segment']:
    config, _ = workspace_paths(root)
    path = config / 'segments.json'
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding='utf-8'))
    return [Segment(**item) for item in data.get('segments', [])]


def save_sessions(root: Path, sessions: list['Segment']) -> None:
    config, _ = workspace_paths(root)
    config.mkdir(parents=True, exist_ok=True)
    path = config / 'segments.json'
    safe_json_write(path, {'schema': 1, 'segments': [asdict(s) for s in sessions]})


def safe_json_write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.writing')
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(path)
    finally:
        tmp.unlink(missing_ok=True)


@dataclass
class Segment:
    sid: str
    feature: str
    spec: str
    scenario: str
    item_id: str = ''
    expect_start: str = ''
    expect_end: str = ''
    source_sheet: str = ''
    created_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec='seconds'))

    def __post_init__(self) -> None:
        self.feature = component(self.feature, '機能（案件名）')
        self.spec = spec_folder_name(self.spec)
        self.scenario = component(self.scenario, 'シナリオID')
        # Do not invent an ID folder from expected ID. Only explicit item_id enables it.
        # Preserve old bookmarks that already explicitly requested an ID folder.
        self.item_id = id_folder_name(self.item_id) if self.item_id else ''
        if not re.fullmatch(r'[a-f0-9]{12}', self.sid):
            raise ValueError('無効なしおり識別子です')

    @classmethod
    def create(cls, feature: str, spec: str, scenario: str, item_id: str = '',
               expect_start: str = '', expect_end: str = '', source_sheet: str = '') -> 'Segment':
        return cls(uuid.uuid4().hex[:12], feature, spec, scenario, item_id, expect_start, expect_end, source_sheet)

    def folder(self, root: Path, platform: str, output_root: Optional[Path] = None) -> Path:
        if platform not in ('And', 'iOS'):
            raise ValueError('OSが未判定です')
        _, legacy_evidence = workspace_paths(root)
        evidence = Path(output_root) if output_root is not None else legacy_evidence
        pieces = [self.feature, spec_folder_name(self.spec), self.scenario]
        if self.item_id:
            pieces.append(self.item_id)
        return evidence.joinpath(*pieces, platform)

    def label(self) -> str:
        scope = f' / シート {self.source_sheet}' if self.source_sheet else ''
        scope += f' / 期待値ID {self.expect_start}' if self.expect_start else ''
        if self.expect_end and self.expect_end != self.expect_start:
            scope += f' ～ {self.expect_end}'
        return f'{self.feature} / {self.spec} / {self.scenario}' + (f' / {self.item_id}' if self.item_id else '') + scope + f' [{self.sid}]'


def get_font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for loc in ('C:/Windows/Fonts/meiryo.ttc', 'C:/Windows/Fonts/msgothic.ttc',
                '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
                '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'):
        if Path(loc).exists():
            try:
                return ImageFont.truetype(loc, size)
            except OSError:
                pass
    return ImageFont.load_default()


def make_marker(root: Path, segment: Segment, tag: str) -> Path:
    if tag not in ('START', 'END'):
        raise ValueError('STARTまたはENDを指定してください')
    config, _ = workspace_paths(root)
    marker_dir = config / 'しおり' / segment.sid
    marker_dir.mkdir(parents=True, exist_ok=True)
    qr_value = f'EO1:{segment.sid}:{tag}'
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=12, border=5)
    qr.add_data(qr_value)
    qr.make(fit=True)
    square = qr.make_image(fill_color='#101820', back_color='white').convert('RGB')
    square = square.resize((470, 470), Image.Resampling.NEAREST)
    picture = Image.new('RGB', (740, 870), 'white')
    draw = ImageDraw.Draw(picture)
    draw.rounded_rectangle((14, 14, 726, 853), radius=18, outline='#3b4554', width=4)
    title = '撮影開始 / START' if tag == 'START' else '撮影終了 / END'
    draw.text((37, 35), title, fill='#17202b', font=get_font(33))
    picture.paste(square, (135, 110))
    expect_text = segment.expect_start or '(指定なし)'
    if segment.expect_end and segment.expect_end != segment.expect_start:
        expect_text += ' ～ ' + segment.expect_end
    lines = [f'案件：{segment.feature}', f'仕様書：{segment.spec}',
             f'シート：{segment.source_sheet or "(未指定)"}',
             f'シナリオ：{segment.scenario}', f'期待値ID：{expect_text}',
             f'フォルダID：{segment.item_id or "(なし)"}', f'区間：{segment.sid}']
    for i, line in enumerate(lines):
        if len(line) > 40:
            line = line[:37] + '...'
        draw.text((45, 602 + i * 36), line, font=get_font(20), fill='#202c3a')
    output = marker_dir / f'{tag}.png'
    picture.save(output)
    return output


def datetime_from_exif(image: Image.Image) -> Optional[datetime]:
    try:
        exif = image.getexif()
        for key in (36867, 36868, 306):
            raw = exif.get(key)
            if raw:
                date = datetime.strptime(str(raw)[:19], '%Y:%m:%d %H:%M:%S')
                if 2000 <= date.year <= 2100:
                    return date
    except (ValueError, OSError, AttributeError, OverflowError):
        pass
    for key in ('date:create', 'Creation Time', 'DateTimeOriginal', 'date:modify'):
        try:
            raw = image.info.get(key)
            if raw:
                normalized = str(raw).replace('Z', '+00:00')
                date = datetime.fromisoformat(normalized)
                return date.replace(tzinfo=None)
        except (ValueError, TypeError, OverflowError):
            pass
    return None


def filename_datetime(name: str) -> Optional[datetime]:
    # iOS and Android variants for screenshots and camera images
    for pattern in (r'(20\d{2})[-_]?([01]\d)[-_]?([0-3]\d)[ T_-]+([0-2]\d)[.\-_:]?([0-5]\d)[.\-_:]?([0-5]\d)',
                    r'(20\d{2})([01]\d)([0-3]\d)[-_]([0-2]\d)([0-5]\d)([0-5]\d)'):
        hit = re.search(pattern, name)
        if hit:
            try:
                return datetime(*[int(x) for x in hit.groups()])
            except ValueError:
                pass
    return None


def get_time_source(path: Path) -> tuple[float, str]:
    try:
        with Image.open(path) as im:
            captured = datetime_from_exif(im)
            if captured:
                return captured.timestamp(), 'EXIF'
    except Exception:
        pass
    by_name = filename_datetime(path.name)
    if by_name:
        return by_name.timestamp(), 'ファイル名'
    return path.stat().st_mtime, '更新日時（要確認）'


def os_classification(path: Path) -> tuple[str, str, str]:
    """Classify the evidence source using camera-specific metadata first.

    The iPhone camera photographs the Android screen, so EXIF Make=Apple
    denotes the capture device, *not* the platform of the evidence.
    Do not classify ordinary JPEG/HEIC solely by its extension.
    """
    stem = path.stem.lower()
    ext = path.suffix.lower()
    screenshot_name = bool(re.search(
        r'screenshot|screen[ ._-]?shot|スクリーンショット|スクショ', stem, re.I))
    camera_tags = {
        33434: '露出時間',           # ExposureTime
        33437: 'F値',               # FNumber
        34855: 'ISO感度',            # PhotographicSensitivity
        37386: '焦点距離',            # FocalLength
        42036: 'レンズ名',            # LensModel
        37385: 'フラッシュ情報',       # Flash
        37383: '測光方式',           # MeteringMode
    }
    try:
        with Image.open(path) as im:
            exif = im.getexif()
            # Some HEIC/JPEG readers expose camera fields in the Exif sub-IFD.
            fields = dict(exif.items())
            try:
                fields.update(exif.get_ifd(34665))
            except (AttributeError, OSError, ValueError, TypeError):
                pass
            found = [label for code, label in camera_tags.items() if fields.get(code) is not None]
            if found:
                return 'And', '高', '撮影EXIF（' + '・'.join(found[:3]) + '）'

            # Make/Model alone is not enough: screenshots can be tagged as Apple.
            camera_model = str(fields.get(272, '')).strip()
            camera_make = str(fields.get(271, '')).strip()
            date_taken = fields.get(36867) or fields.get(36868)
            if camera_make and camera_model and date_taken:
                return 'And', '中', '撮影EXIF（カメラ機種＋撮影日時）'

            # Some image exporters store an explicit screenshot type as metadata.
            texts = [str(fields.get(305, ''))]  # Software
            for key in ('Software', 'Description', 'description', 'Comment', 'comment', 'Title', 'title'):
                if key in im.info:
                    texts.append(str(im.info[key])[:300])
            if any(re.search(r'screenshot|screen[ ._-]?shot|スクリーンショット|スクショ', x, re.I) for x in texts):
                return 'iOS', '高', 'メタデータにスクリーンショットの記録'
    except (OSError, ValueError, TypeError, SyntaxError):
        return '', '低', '画像メタデータを読み取れないため保留'

    if screenshot_name:
        return 'iOS', '中', 'ファイル名からスクリーンショットと推定（撮影EXIFなし）'
    if ext == '.png':
        return 'iOS', '中', '撮影EXIFのないPNG画像をiPhoneスクリーンショットと推定'
    # JPEG, HEIC, and all other formats with no decisive metadata must be held.
    # Never put a metadata-stripped screenshot into And on filename extension alone.
    return '', '低', 'カメラ撮影を示すメタデータがないためOS判別保留'


def read_qr(path: Path) -> tuple[Optional[str], Optional[str]]:
    if not QR_AVAILABLE:
        return None, 'OpenCVが未インストールです'
    try:
        with Image.open(path) as original:
            image = ImageOps.exif_transpose(original)
            image.thumbnail((1650, 1650), Image.Resampling.LANCZOS)
            matrix = np.array(image.convert('RGB'))
        detector = cv2.QRCodeDetector()
        raw, _, _ = detector.detectAndDecode(cv2.cvtColor(matrix, cv2.COLOR_RGB2GRAY))
        if raw:
            match = QR_PATTERN.fullmatch(raw.strip())
            if match:
                return (match.group(1), match.group(2)), None
        return None, None
    except Exception as ex:
        return None, str(ex)[:120]


@dataclass
class ImageItem:
    path: Path
    timestamp: float
    time_source: str
    kind: str = 'image' # image, marker
    segment_id: str = ''
    platform: str = ''
    confidence: str = ''
    detail: str = ''
    marker_tag: str = ''
    manually_set_segment: bool = False
    manually_set_platform: bool = False
    skipped: bool = False

    def serialize(self) -> dict:
        d = asdict(self)
        d['path'] = str(self.path)
        return d


def list_images(import_dir: Path, root: Path, excluded_roots: Optional[list[Path]] = None) -> list[Path]:
    import_dir = Path(import_dir).resolve()
    root = Path(root).resolve()
    if not import_dir.is_dir():
        raise ValueError('画像取り込みフォルダがありません')
    folders = [p.resolve() for p in workspace_paths(root)]
    folders.extend(p.resolve() for p in (excluded_roots or []))
    result = []
    for file in import_dir.rglob('*'):
        if not file.is_file() or file.suffix.lower() not in IMAGE_EXTENSIONS:
            continue
        rp = file.resolve()
        if any(f == rp or f in rp.parents for f in folders):
            continue
        result.append(file)
    return result


def scan_images(import_dir: Path, root: Path, progress: Optional[Callable[[int,int,str], None]] = None, excluded_roots: Optional[list[Path]] = None) -> list[ImageItem]:
    files = list_images(import_dir, root, excluded_roots=excluded_roots)
    rows = []
    for num, path in enumerate(files, 1):
        if progress:
            progress(num, len(files), path.name)
        timestamp, origin = get_time_source(path)
        plat, certainty, explanation = os_classification(path)
        row = ImageItem(path, timestamp, origin, platform=plat, confidence=certainty, detail=explanation)
        marker, err = read_qr(path)
        if marker:
            row.kind = 'marker'
            row.segment_id, row.marker_tag = marker
            row.platform = ''
            row.confidence = '高'
            row.detail = f'しおり {row.marker_tag}'
        elif err:
            row.detail += f' / QR解析: {err}'
        rows.append(row)
    rows.sort(key=lambda item: (item.timestamp, str(item.path)))
    return rows


def assign_segments(rows: list[ImageItem], known: dict[str, Segment]) -> list[str]:
    warnings = []
    active = ''
    for row in rows:
        if row.kind == 'marker':
            if row.segment_id not in known:
                warnings.append(f'登録されていない区間のしおり: {row.path.name} ({row.segment_id})')
                if row.marker_tag == 'START':
                    active = ''
                continue
            if row.marker_tag == 'START':
                if active:
                    warnings.append(f'区間 {active} の終了しおりなしで次の開始を検出')
                active = row.segment_id
            elif row.marker_tag == 'END':
                if active != row.segment_id:
                    warnings.append(f'開始と対応しない終了しおり: {row.path.name}')
                active = ''
            continue
        if not row.manually_set_segment:
            row.segment_id = active
    if active:
        warnings.append(f'区間 {active} の終了しおりが見つかりません')
    return warnings


def plan_rows(rows: list[ImageItem], known: dict[str, Segment], root: Path, output_root: Optional[Path] = None) -> list[tuple[ImageItem, str, Optional[Path]]]:
    plan = []
    target_counts = {}
    for row in rows:
        if row.kind == 'marker':
            plan.append((row, 'しおり（格納対象外）', None)); continue
        if row.skipped:
            plan.append((row, '除外指定', None)); continue
        if row.segment_id not in known:
            plan.append((row, '要確認：撮影区間未割当', None)); continue
        if row.platform not in ('And', 'iOS'):
            plan.append((row, '要確認：OS未判定', None)); continue
        if not canonical_case_name(known[row.segment_id].scenario):
            # Old v0.3.1 QR bookmarks can contain No=1 rather than P1-1.
            # Never create an incorrectly named folder for such bookmarks.
            plan.append((row, '要確認：ケース名が不正（正しいケースでしおりを作成し直してください）', None)); continue
        destination = known[row.segment_id].folder(root, row.platform, output_root=output_root) / row.path.name
        plan.append((row, '分類可能', destination))
        target_counts[destination] = target_counts.get(destination, 0) + 1
    result = []
    for row, status, dest in plan:
        if dest is not None:
            if target_counts[dest] > 1:
                status = '要確認：同じ格納先に同名画像が複数'
            elif dest.exists():
                status = '要確認：同名ファイルが格納済み'
        result.append((row, status, dest))
    return result


def exclusive_copy(source: Path, destination: Path) -> None:
    """Create destination with O_EXCL, preventing overwrite even during races.

    Exact filename preserved. File content copied byte-for-byte, original intact.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(destination, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o666)
    try:
        with os.fdopen(descriptor, 'wb') as sink, source.open('rb') as origin:
            shutil.copyfileobj(origin, sink, length=1024 * 1024)
        shutil.copystat(source, destination)
    except BaseException:
        destination.unlink(missing_ok=True)
        raise


def copy_approved(plan: list[tuple[ImageItem, str, Optional[Path]]], progress: Optional[Callable[[int,int,str], None]]=None) -> tuple[list[dict], int]:
    records = []
    candidates = [(r, s, d) for r, s, d in plan if s == '分類可能' and d is not None]
    for i, (row, _, dest) in enumerate(candidates, 1):
        if progress:
            progress(i, len(candidates), row.path.name)
        try:
            exclusive_copy(row.path, dest)
            records.append({'source': str(row.path), 'destination': str(dest), 'status': 'コピー完了', 'error': ''})
        except FileExistsError:
            records.append({'source': str(row.path), 'destination': str(dest), 'status': '保留', 'error': '格納先に同名ファイルあり'})
        except Exception as ex:
            records.append({'source': str(row.path), 'destination': str(dest), 'status': 'エラー', 'error': str(ex)})
    return records, sum(r['status'] == 'コピー完了' for r in records)


def save_report(root: Path, plan: list[tuple[ImageItem, str, Optional[Path]]], copied: list[dict]) -> Path:
    config, _ = workspace_paths(root)
    folder = config / 'レポート'
    folder.mkdir(parents=True, exist_ok=True)
    report = folder / f'分類履歴_{datetime.now().strftime("%Y%m%d_%H%M%S_%f")}.csv'
    result = {rec['source']: rec for rec in copied}
    known = {seg.sid: seg for seg in load_sessions(root)}
    with report.open('w', newline='', encoding='utf-8-sig') as output:
        writer = csv.writer(output)
        writer.writerow(['元ファイル', '案件名', 'テスト仕様書名', 'シート', 'シナリオID', '期待値ID（開始）', '期待値ID（終了）',
                         'フォルダID', '撮影区間ID', 'OS', '格納先', '分類判定', 'コピー結果', 'エラー', '日時の根拠', '日時', '手動修正', 'OS判定根拠'])
        for row, status, destination in plan:
            rec = result.get(str(row.path), {})
            seg = known.get(row.segment_id)
            writer.writerow([str(row.path), seg.feature if seg else '', seg.spec if seg else '',
                             seg.source_sheet if seg else '', seg.scenario if seg else '',
                             seg.expect_start if seg else '', seg.expect_end if seg else '',
                             seg.item_id if seg else '', row.segment_id, row.platform, str(destination or ''), status,
                             rec.get('status', '対象外'), rec.get('error', ''), row.time_source,
                             datetime.fromtimestamp(row.timestamp).isoformat(timespec='seconds'),
                             'あり' if row.manually_set_platform or row.manually_set_segment else 'なし', row.detail])
    return report
