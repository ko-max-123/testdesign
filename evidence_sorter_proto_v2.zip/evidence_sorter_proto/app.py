from __future__ import annotations

import os
import re
import shutil
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from PIL import Image, ImageOps, ImageTk
except ImportError:
    Image = None
    ImageOps = None
    ImageTk = None

try:
    import cv2
    import numpy as np
except ImportError:
    cv2 = None
    np = None


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".heic", ".heif", ".webp", ".bmp", ".tif", ".tiff"}
TEMPLATE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}
PHOTO_EXTS = {".jpg", ".jpeg", ".heic", ".heif"}
APP_DIR = Path(__file__).resolve().parent
REFERENCE_DIR = APP_DIR / "reference" / "bookmark_ui"


@dataclass
class EvidenceItem:
    path: Path
    category: str = "未判定"
    reason: str = ""
    bookmark_score: float = 0.0
    matched_reference: str = ""
    width: int = 0
    height: int = 0
    exif_camera: bool = False


@dataclass
class BookmarkTemplate:
    path: Path
    gray: object


class EvidenceSorterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Evidence Sorter Prototype v2 - Reference UI Matching")
        self.geometry("1240x790")
        self.minsize(1050, 680)

        REFERENCE_DIR.mkdir(parents=True, exist_ok=True)

        self.folder: Optional[Path] = None
        self.items: List[EvidenceItem] = []
        self.preview_img = None
        self.bookmark_templates: List[BookmarkTemplate] = []

        self.sort_mode = tk.StringVar(value="name")
        self.match_threshold = tk.IntVar(value=82)
        self.prefix_seq = tk.BooleanVar(value=True)
        self.copy_bookmark = tk.BooleanVar(value=True)

        self._build_ui()
        self.reload_reference_images(show_message=False)

    def _build_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        ttk.Button(top, text="1. フォルダ選択", command=self.choose_folder).pack(side="left")
        self.folder_label = ttk.Label(top, text="未選択", width=56)
        self.folder_label.pack(side="left", padx=10)
        ttk.Button(top, text="2. 解析", command=self.analyze).pack(side="left", padx=(0, 8))
        ttk.Button(top, text="3. 分別実行", command=self.execute_sort).pack(side="left")

        ref_frame = ttk.LabelFrame(self, text="栞判定用・参照UI画像", padding=8)
        ref_frame.pack(fill="x", padx=10, pady=(0, 8))

        ttk.Button(ref_frame, text="参照UI画像を追加", command=self.add_reference_images).pack(side="left")
        ttk.Button(ref_frame, text="参照UIフォルダを開く", command=self.open_reference_folder).pack(side="left", padx=(6, 0))
        ttk.Button(ref_frame, text="再読込", command=lambda: self.reload_reference_images(show_message=True)).pack(side="left", padx=(6, 0))
        self.reference_label = ttk.Label(ref_frame, text="参照UI: 0枚", width=18)
        self.reference_label.pack(side="left", padx=(12, 8))
        ttk.Label(ref_frame, text="一致率しきい値:").pack(side="left")
        ttk.Spinbox(ref_frame, from_=50, to=99, width=5, textvariable=self.match_threshold).pack(side="left", padx=(4, 8))
        ttk.Label(ref_frame, text="% 以上で栞").pack(side="left")

        opts = ttk.LabelFrame(self, text="分別設定", padding=8)
        opts.pack(fill="x", padx=10, pady=(0, 8))

        ttk.Label(opts, text="並び順:").pack(side="left")
        ttk.Radiobutton(opts, text="ファイル名順（推奨）", variable=self.sort_mode, value="name").pack(side="left", padx=(4, 10))
        ttk.Radiobutton(opts, text="更新日時順", variable=self.sort_mode, value="mtime").pack(side="left", padx=(0, 12))
        ttk.Checkbutton(opts, text="連番を付ける", variable=self.prefix_seq).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(opts, text="栞も保存", variable=self.copy_bookmark).pack(side="left")

        main = ttk.Panedwindow(self, orient="horizontal")
        main.pack(fill="both", expand=True, padx=10, pady=(0, 8))

        left = ttk.Frame(main)
        right = ttk.Frame(main, padding=(10, 0, 0, 0))
        main.add(left, weight=3)
        main.add(right, weight=2)

        columns = ("no", "name", "type", "score", "reference", "reason")
        self.tree = ttk.Treeview(left, columns=columns, show="headings", selectmode="extended")
        self.tree.heading("no", text="#")
        self.tree.heading("name", text="ファイル")
        self.tree.heading("type", text="判定")
        self.tree.heading("score", text="UI一致率")
        self.tree.heading("reference", text="一致した参照UI")
        self.tree.heading("reason", text="理由")
        self.tree.column("no", width=44, anchor="center")
        self.tree.column("name", width=220)
        self.tree.column("type", width=85, anchor="center")
        self.tree.column("score", width=75, anchor="center")
        self.tree.column("reference", width=160)
        self.tree.column("reason", width=300)
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        scroll = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)

        self.preview = ttk.Label(right, text="画像プレビュー", anchor="center", relief="solid")
        self.preview.pack(fill="both", expand=True)

        manual = ttk.LabelFrame(right, text="手動補正（選択行）", padding=8)
        manual.pack(fill="x", pady=(8, 0))
        ttk.Button(manual, text="栞", command=lambda: self.set_category("栞")).pack(side="left", padx=3)
        ttk.Button(manual, text="iOS", command=lambda: self.set_category("iOS")).pack(side="left", padx=3)
        ttk.Button(manual, text="Android", command=lambda: self.set_category("Android")).pack(side="left", padx=3)
        ttk.Button(manual, text="不明", command=lambda: self.set_category("不明")).pack(side="left", padx=3)

        help_text = (
            "栞判定: reference/bookmark_ui 内のUI切り抜き画像を、iOSスクリーンショット全体から検索します。\n"
            "参照UIは、メモアプリの固定アイコン・固定ボタンなど『毎回変わらない部分』を切り抜いて登録してください。\n"
            "Android = iPhoneカメラ写真（HEIC/JPEG/カメラEXIF）。元画像は移動せず _sorted へコピーします。"
        )
        ttk.Label(right, text=help_text, wraplength=440, justify="left").pack(fill="x", pady=(8, 0))

        self.status = ttk.Label(self, text="準備完了", anchor="w", padding=(10, 5))
        self.status.pack(fill="x")

    def choose_folder(self):
        selected = filedialog.askdirectory(title="エビデンス画像フォルダを選択")
        if not selected:
            return
        self.folder = Path(selected)
        self.folder_label.config(text=str(self.folder))
        self.status.config(text="フォルダを選択しました。『解析』を押してください。")

    def add_reference_images(self):
        files = filedialog.askopenfilenames(
            title="栞判定に使うUI切り抜き画像を選択",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff"), ("All files", "*.*")],
        )
        if not files:
            return

        copied = 0
        for source_text in files:
            source = Path(source_text)
            if source.suffix.lower() not in TEMPLATE_EXTS:
                continue
            dest = REFERENCE_DIR / source.name
            if dest.resolve() == source.resolve():
                copied += 1
                continue
            n = 1
            while dest.exists():
                dest = REFERENCE_DIR / f"{source.stem}_{n}{source.suffix}"
                n += 1
            shutil.copy2(source, dest)
            copied += 1

        self.reload_reference_images(show_message=False)
        self.status.config(text=f"参照UI画像を{copied}枚追加しました。")

    def open_reference_folder(self):
        REFERENCE_DIR.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(str(REFERENCE_DIR))  # type: ignore[attr-defined]
            else:
                messagebox.showinfo("参照UIフォルダ", str(REFERENCE_DIR))
        except Exception as e:
            messagebox.showerror("エラー", f"参照UIフォルダを開けませんでした。\n{e}\n\n{REFERENCE_DIR}")

    def reload_reference_images(self, show_message: bool = False):
        REFERENCE_DIR.mkdir(parents=True, exist_ok=True)
        templates: List[BookmarkTemplate] = []

        if cv2 is not None and np is not None:
            for path in sorted(REFERENCE_DIR.iterdir(), key=self.natural_key):
                if not path.is_file() or path.suffix.lower() not in TEMPLATE_EXTS:
                    continue
                gray = self._cv_read_gray(path)
                if gray is None or gray.size == 0:
                    continue
                templates.append(BookmarkTemplate(path=path, gray=gray))

        self.bookmark_templates = templates
        self.reference_label.config(text=f"参照UI: {len(templates)}枚")

        if show_message:
            if cv2 is None or np is None:
                messagebox.showwarning("確認", "OpenCVが未導入です。setup.bat を実行してください。")
            else:
                messagebox.showinfo("参照UI", f"参照UI画像を {len(templates)} 枚読み込みました。")

    @staticmethod
    def natural_key(path: Path):
        parts = re.split(r"(\d+)", path.name.lower())
        return [int(p) if p.isdigit() else p for p in parts]

    def analyze(self):
        if not self.folder:
            messagebox.showwarning("確認", "先にフォルダを選択してください。")
            return
        if cv2 is None or np is None:
            messagebox.showwarning("確認", "OpenCVが未導入です。setup.bat を実行してください。")
            return

        self.reload_reference_images(show_message=False)
        if not self.bookmark_templates:
            if not messagebox.askyesno(
                "参照UI未登録",
                "栞判定用の参照UI画像が登録されていません。\n"
                "このまま解析すると栞は自動判定されません。\n\n続行しますか？",
            ):
                return

        sort_mode = self.sort_mode.get()
        threshold = self.match_threshold.get()
        self.status.config(text="解析中...")
        threading.Thread(target=self._analyze_worker, args=(sort_mode, threshold), daemon=True).start()

    def _analyze_worker(self, sort_mode: str, threshold: int):
        files = [
            p for p in self.folder.rglob("*")
            if p.is_file() and p.suffix.lower() in IMAGE_EXTS and "_sorted" not in p.parts
        ]
        if sort_mode == "mtime":
            files.sort(key=lambda p: (p.stat().st_mtime, self.natural_key(p)))
        else:
            files.sort(key=self.natural_key)

        items = []
        for path in files:
            items.append(self.classify(path, threshold))

        self.items = items
        self.after(0, self._refresh_tree)

    def classify(self, path: Path, threshold: int) -> EvidenceItem:
        ext = path.suffix.lower()
        item = EvidenceItem(path=path)

        # In this workflow HEIC/HEIF is an iPhone camera photo of the Android device.
        if ext in {".heic", ".heif"}:
            item.category = "Android"
            item.reason = "HEIC/HEIF = iPhoneカメラ撮影候補"
            return item

        if Image is None:
            item.category = "不明"
            item.reason = "Pillow未導入"
            return item

        try:
            with Image.open(path) as im:
                item.width, item.height = im.size
                item.exif_camera = self._has_camera_exif(im)

                if item.exif_camera:
                    item.category = "Android"
                    item.reason = "カメラEXIFあり"
                    return item

                if ext in {".jpg", ".jpeg"}:
                    item.category = "Android"
                    item.reason = "JPEG写真候補（EXIFなし）"
                    return item

                if ext == ".png":
                    score, ref_name = self._match_bookmark_ui(path)
                    item.bookmark_score = score
                    item.matched_reference = ref_name
                    if score >= threshold:
                        item.category = "栞"
                        item.reason = f"参照UI一致 {score:.1f}%"
                    else:
                        item.category = "iOS"
                        if self.bookmark_templates:
                            item.reason = f"参照UI最大一致 {score:.1f}% < {threshold}%"
                        else:
                            item.reason = "参照UI未登録のためPNGをiOS候補"
                    return item

                item.category = "不明"
                item.reason = f"拡張子 {ext}"
                return item
        except Exception as e:
            item.category = "不明"
            item.reason = f"画像解析不可: {type(e).__name__}"
            return item

    @staticmethod
    def _has_camera_exif(im) -> bool:
        try:
            exif = im.getexif()
            if not exif:
                return False
            camera_tags = {271, 272, 36867, 37386, 33434, 34855}
            return any(tag in exif and exif.get(tag) not in (None, "") for tag in camera_tags)
        except Exception:
            return False

    @staticmethod
    def _cv_read_gray(path: Path):
        if cv2 is None or np is None:
            return None
        try:
            # np.fromfile + imdecode also handles Japanese Windows paths reliably.
            data = np.fromfile(str(path), dtype=np.uint8)
            image = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
            return image
        except Exception:
            return None

    def _match_bookmark_ui(self, screenshot_path: Path) -> Tuple[float, str]:
        if cv2 is None or np is None or not self.bookmark_templates:
            return 0.0, ""

        screenshot = self._cv_read_gray(screenshot_path)
        if screenshot is None or screenshot.size == 0:
            return 0.0, ""

        sh, sw = screenshot.shape[:2]
        best_score = 0.0
        best_name = ""

        for template in self.bookmark_templates:
            ref = template.gray
            rh, rw = ref.shape[:2]
            if rh < 8 or rw < 8 or rh > sh or rw > sw:
                continue

            try:
                # The registered crop is searched over the whole screenshot.
                result = cv2.matchTemplate(screenshot, ref, cv2.TM_CCOEFF_NORMED)
                _, max_val, _, _ = cv2.minMaxLoc(result)
                score = max(0.0, min(100.0, float(max_val) * 100.0))
                if score > best_score:
                    best_score = score
                    best_name = template.path.name
            except cv2.error:
                continue

        return best_score, best_name

    def _refresh_tree(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for i, item in enumerate(self.items, 1):
            score_text = f"{item.bookmark_score:.1f}%" if item.bookmark_score > 0 else "-"
            self.tree.insert(
                "", "end", iid=str(i - 1),
                values=(i, item.path.name, item.category, score_text, item.matched_reference, item.reason),
            )
        bookmarks = sum(1 for x in self.items if x.category == "栞")
        self.status.config(
            text=f"解析完了: {len(self.items)}枚 / 栞候補 {bookmarks}枚。確認後、『分別実行』してください。"
        )

    def on_select(self, _event=None):
        sel = self.tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        item = self.items[idx]
        if Image is None or ImageTk is None:
            self.preview.config(text=f"{item.path.name}\nPillow未導入のためプレビュー不可", image="")
            return
        try:
            with Image.open(item.path) as im:
                im = ImageOps.exif_transpose(im).convert("RGB")
                im.thumbnail((440, 525))
                self.preview_img = ImageTk.PhotoImage(im)
                self.preview.config(image=self.preview_img, text="")
        except Exception:
            self.preview.config(text=f"プレビューできません\n{item.path.name}", image="")

    def set_category(self, category: str):
        sel = self.tree.selection()
        if not sel:
            return
        for iid in sel:
            idx = int(iid)
            self.items[idx].category = category
            self.items[idx].reason = "手動補正"
            vals = list(self.tree.item(iid, "values"))
            vals[2] = category
            vals[5] = "手動補正"
            self.tree.item(iid, values=vals)
        self.status.config(text=f"{len(sel)}件を「{category}」に変更しました。")

    def execute_sort(self):
        if not self.folder or not self.items:
            messagebox.showwarning("確認", "先にフォルダを選択して解析してください。")
            return
        if not messagebox.askyesno("分別実行", "元画像は残したまま、_sorted フォルダへコピーします。実行しますか？"):
            return
        try:
            out = self.folder / "_sorted"
            out.mkdir(exist_ok=True)
            current_group = 0
            seq = {"iOS": 0, "Android": 0, "不明": 0, "栞": 0}
            seen_bookmark = False

            for item in self.items:
                if item.category == "栞":
                    current_group += 1
                    seen_bookmark = True
                    seq = {"iOS": 0, "Android": 0, "不明": 0, "栞": 0}
                    if self.copy_bookmark.get():
                        dest_dir = out / f"Group_{current_group:03d}" / "bookmark"
                        self._copy_with_seq(item.path, dest_dir, seq, "栞")
                    continue

                group_name = f"Group_{current_group:03d}" if seen_bookmark else "Before_First_Bookmark"
                dest_dir = out / group_name / (item.category if item.category in {"iOS", "Android"} else "Unknown")
                key = item.category if item.category in seq else "不明"
                self._copy_with_seq(item.path, dest_dir, seq, key)

            messagebox.showinfo("完了", f"分別が完了しました。\n\n出力先:\n{out}")
            self.status.config(text=f"分別完了: {out}")
        except Exception as e:
            messagebox.showerror("エラー", f"分別中にエラーが発生しました。\n{e}")

    def _copy_with_seq(self, src: Path, dest_dir: Path, seq: dict, key: str):
        dest_dir.mkdir(parents=True, exist_ok=True)
        seq[key] += 1
        if self.prefix_seq.get():
            name = f"{seq[key]:03d}_{src.name}"
        else:
            name = src.name
        dest = dest_dir / name
        n = 1
        while dest.exists():
            dest = dest_dir / f"{dest.stem}_{n}{dest.suffix}"
            n += 1
        shutil.copy2(src, dest)


if __name__ == "__main__":
    app = EvidenceSorterApp()
    app.mainloop()
