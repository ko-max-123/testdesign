Place cropped reference UI images for bookmark detection in this folder.
You can also add them from the app with the "Add reference UI image" button.
Use only fixed UI parts. Avoid time, battery percentage, note text, or handwriting.
Multiple reference images are supported.
