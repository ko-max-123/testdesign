import sys
import tkinter

print('Python:', sys.version)
print('Tkinter: OK')

try:
    import PIL
    print('Pillow:', PIL.__version__)
except Exception:
    print('Pillow: NOT INSTALLED')

try:
    import cv2
    print('OpenCV:', cv2.__version__)
except Exception:
    print('OpenCV: NOT INSTALLED')

try:
    import numpy
    print('NumPy:', numpy.__version__)
except Exception:
    print('NumPy: NOT INSTALLED')
