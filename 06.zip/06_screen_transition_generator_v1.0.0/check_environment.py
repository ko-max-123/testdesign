#!/usr/bin/env python3
"""生成前に、Python・入力台帳・テンプレート類がそろっているか表示する。"""
from pathlib import Path
import sys
import zipfile

root = Path(__file__).resolve().parent
excel = root / "input" / "画面遷移管理.xlsx"
template = root / "template" / "viewer_template.html"
print("Python:", sys.version.split()[0])
print("Python 3.9以上:", "OK" if sys.version_info >= (3, 9) else "NG")
print("Excel:", "OK" if excel.is_file() and zipfile.is_zipfile(excel) else "NG", excel)
print("Template:", "OK" if template.is_file() else "NG", template)
diagram = root / "template" / "diagram.js"
print("Diagram:", "OK" if diagram.is_file() else "NG", diagram)
editor = root / "template" / "image_editor.js"
print("Image editor:", "OK" if editor.is_file() else "NG", editor)
record_editor = root / "template" / "record_editor.js"
print("Record editor:", "OK" if record_editor.is_file() else "NG", record_editor)
for name in ("excel_export.js", "excel_diagram_base.xlsx"):
    resource = root / "template" / name
    print("Excel export:", "OK" if resource.is_file() else "NG", resource)
print("Screenshots:", len(list((root / "input" / "screenshots").glob("*.*"))), "files")
