#!/usr/bin/env python3
"""Excel台帳と画像から、画面遷移ビューアHTMLを生成する。外部ライブラリ不要。"""

from __future__ import annotations

import argparse
import base64
import json
import hashlib
import mimetypes
import posixpath
import re
import shutil
import sys
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET

# 入力台帳・テンプレート・出力先は、このスクリプトを置いたフォルダから探す。
ROOT = Path(__file__).resolve().parent
DEFAULT_EXCEL = ROOT / "input" / "画面遷移管理.xlsx"
TEMPLATE = ROOT / "template" / "viewer_template.html"
DIAGRAM_SCRIPT = ROOT / "template" / "diagram.js"
IMAGE_EDITOR_SCRIPT = ROOT / "template" / "image_editor.js"
RECORD_EDITOR_SCRIPT = ROOT / "template" / "record_editor.js"
EXCEL_EXPORT_SCRIPT = ROOT / "template" / "excel_export.js"
EXCEL_DIAGRAM_BASE = ROOT / "template" / "excel_diagram_base.xlsx"
OUTPUT_DIR = ROOT / "output"
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "p": "http://schemas.openxmlformats.org/package/2006/relationships"}


def col_index(cell_ref: str) -> int:
    """Excelのセル番地（例: C12）から、0始まりの列番号を返す。"""
    letters = re.match(r"[A-Z]+", cell_ref or "A").group(0)
    value = 0
    for ch in letters:
        value = value * 26 + ord(ch) - 64
    return value - 1


def excel_date(value: str) -> str:
    """Excelの日付シリアル値を表示用の日付に変える。文字列はそのまま返す。"""
    try:
        serial = float(value)
        if serial < 1000:
            return value
        return (datetime(1899, 12, 30) + timedelta(days=serial)).strftime("%Y-%m-%d")
    except (TypeError, ValueError, OverflowError):
        return value


class XlsxReader:
    """標準ライブラリだけでxlsx内のシートとセル値を読む。元の台帳は変更しない。"""
    def __init__(self, path: Path):
        self.path = path
        self.zip = zipfile.ZipFile(path)
        self.shared = self._shared_strings()
        self.sheets = self._sheet_paths()

    def _shared_strings(self):
        try:
            root = ET.fromstring(self.zip.read("xl/sharedStrings.xml"))
        except KeyError:
            return []
        return ["".join(t.text or "" for t in si.findall(".//m:t", NS))
                for si in root.findall("m:si", NS)]

    def _sheet_paths(self):
        # workbook.xmlのシート名を、実際のシートXMLファイルへ対応付ける。
        workbook = ET.fromstring(self.zip.read("xl/workbook.xml"))
        rels = ET.fromstring(self.zip.read("xl/_rels/workbook.xml.rels"))
        rel_map = {r.attrib["Id"]: r.attrib["Target"] for r in rels.findall("p:Relationship", NS)}
        result = {}
        for sheet in workbook.findall("m:sheets/m:sheet", NS):
            target = rel_map[sheet.attrib[f"{{{NS['r']}}}id"]]
            clean = target.lstrip("/")
            result[sheet.attrib["name"]] = posixpath.normpath(clean if clean.startswith("xl/") else posixpath.join("xl", clean))
        return result

    def rows(self, sheet_name: str):
        """指定シートを行単位で返す。空白セルも列位置がずれないよう補う。"""
        if sheet_name not in self.sheets:
            raise ValueError(f"必須シートがありません: {sheet_name}")
        root = ET.fromstring(self.zip.read(self.sheets[sheet_name]))
        rows = []
        for row in root.findall(".//m:sheetData/m:row", NS):
            values = []
            for cell in row.findall("m:c", NS):
                idx = col_index(cell.attrib.get("r", "A1"))
                while len(values) <= idx:
                    values.append("")
                cell_type = cell.attrib.get("t", "n")
                if cell_type == "inlineStr":
                    value = "".join(t.text or "" for t in cell.findall(".//m:t", NS))
                else:
                    node = cell.find("m:v", NS)
                    value = node.text if node is not None and node.text is not None else ""
                    if cell_type == "s" and value != "":
                        value = self.shared[int(value)]
                    elif cell_type == "b":
                        value = "TRUE" if value == "1" else "FALSE"
                values[idx] = value
            rows.append(values)
        return rows

    def records(self, sheet_name: str, header_key: str):
        """見出し行を探し、以降の行を「列名: 値」の辞書に変換する。"""
        rows = self.rows(sheet_name)
        header_at = next((i for i, row in enumerate(rows) if header_key in row), None)
        if header_at is None:
            raise ValueError(f"{sheet_name} に見出し '{header_key}' がありません")
        headers = [str(x).strip() for x in rows[header_at]]
        records = []
        for row in rows[header_at + 1:]:
            padded = row + [""] * (len(headers) - len(row))
            item = {headers[i]: str(padded[i]).strip() for i in range(len(headers)) if headers[i]}
            if item.get(header_key, ""):
                records.append(item)
        return records

    def close(self):
        self.zip.close()


def image_uri(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "image/png"
    return f"data:{mime};base64,{base64.b64encode(path.read_bytes()).decode('ascii')}"


def placeholder_uri(screen_id: str, name: str) -> str:
    """画像未登録の画面に表示する代替画像を、HTML内蔵のSVGで作る。"""
    safe_id = screen_id.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="360" height="720" viewBox="0 0 360 720">
    <rect width="360" height="720" rx="28" fill="#e9efec"/><rect x="24" y="24" width="312" height="672" rx="20" fill="#fff"/>
    <circle cx="180" cy="286" r="48" fill="#d9e6e0"/><path d="M155 286h50M180 261v50" stroke="#6b8178" stroke-width="8" stroke-linecap="round"/>
    <text x="180" y="380" text-anchor="middle" font-family="sans-serif" font-size="24" fill="#19272e">{safe_id}</text>
    <text x="180" y="420" text-anchor="middle" font-family="sans-serif" font-size="15" fill="#68777f">画像未登録</text></svg>'''
    return "data:image/svg+xml;base64," + base64.b64encode(svg.encode("utf-8")).decode("ascii")


def sort_number(value: str):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 999999


def build(excel_path: Path, output_override: Path | None = None):
    """台帳の検証、画面画像の準備、HTMLへの埋め込みをまとめて行う。"""
    # 必須ファイルを先に確かめる。途中まで生成してから不足に気づかないため。
    if not excel_path.exists():
        raise FileNotFoundError(f"Excelがありません: {excel_path}")
    if not TEMPLATE.exists():
        raise FileNotFoundError(f"テンプレートがありません: {TEMPLATE}")
    if not DIAGRAM_SCRIPT.exists():
        raise FileNotFoundError(f"画面遷移図スクリプトがありません: {DIAGRAM_SCRIPT}")
    if not IMAGE_EDITOR_SCRIPT.exists():
        raise FileNotFoundError(f"画像登録スクリプトがありません: {IMAGE_EDITOR_SCRIPT}")
    if not RECORD_EDITOR_SCRIPT.exists():
        raise FileNotFoundError(f"画面・遷移編集スクリプトがありません: {RECORD_EDITOR_SCRIPT}")
    for resource in (EXCEL_EXPORT_SCRIPT, EXCEL_DIAGRAM_BASE):
        if not resource.is_file():
            raise FileNotFoundError(f"Excel出力用ファイルがありません: {resource}")

    # 台帳の4シートを読み込み、ブラウザで扱いやすいデータへ変換する。
    reader = XlsxReader(excel_path)
    try:
        setting_rows = reader.records("設定", "設定キー")
        raw_screens = reader.records("画面マスタ", "画面ID")
        raw_transitions = reader.records("遷移マスタ", "遷移ID")
        raw_changes = reader.records("リリース変更", "リリース")
    finally:
        reader.close()

    settings = {r["設定キー"]: r.get("値", "") for r in setting_rows}
    settings.setdefault("system_name", "画面遷移")
    settings.setdefault("viewer_title", "画面遷移ビューア")
    settings.setdefault("current_release", "")
    settings.setdefault("screenshots_folder", "screenshots")
    settings.setdefault("output_file", "画面遷移ビューア.html")
    settings.setdefault("image_mode", "embed")
    settings["last_updated"] = excel_date(settings.get("last_updated", ""))
    if settings["image_mode"] not in {"embed", "relative"}:
        raise ValueError("設定 image_mode は embed または relative にしてください")

    # 同じIDや存在しない遷移先は、図を作る前にエラーとして知らせる。
    ids = [r["画面ID"] for r in raw_screens]
    duplicates = sorted({x for x in ids if ids.count(x) > 1})
    if duplicates:
        raise ValueError("画面IDが重複しています: " + ", ".join(duplicates))
    screen_ids = set(ids)
    transition_ids = [r["遷移ID"] for r in raw_transitions]
    duplicate_tr = sorted({x for x in transition_ids if transition_ids.count(x) > 1})
    if duplicate_tr:
        raise ValueError("遷移IDが重複しています: " + ", ".join(duplicate_tr))

    errors = []
    for r in raw_transitions:
        if r.get("遷移元画面ID") not in screen_ids:
            errors.append(f"{r['遷移ID']}: 遷移元 {r.get('遷移元画面ID')} が画面マスタにありません")
        if r.get("遷移先画面ID") not in screen_ids:
            errors.append(f"{r['遷移ID']}: 遷移先 {r.get('遷移先画面ID')} が画面マスタにありません")
    if errors:
        raise ValueError("\n".join(errors))

    excel_input_dir = excel_path.parent
    screenshot_dir = excel_input_dir / settings["screenshots_folder"]
    output_path = output_override or (ROOT / "output" / settings["output_file"])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    relative_asset_dir = output_path.parent / settings["screenshots_folder"]
    if settings["image_mode"] == "relative":
        relative_asset_dir.mkdir(parents=True, exist_ok=True)

    change_by_screen = {}
    for r in raw_changes:
        if r.get("画面ID") and r.get("リリース") == settings["current_release"]:
            change_by_screen[r["画面ID"]] = r.get("種別", "変更")

    # image_mode=embedは画像をHTMLに内蔵し、relativeは出力先へ画像をコピーする。
    # 画像がない画面も図から消さず、代替画像と警告で表示する。
    warnings = []
    screens = []
    for r in raw_screens:
        filename = r.get("画像ファイル", "")
        image_path = screenshot_dir / filename if filename else None
        if image_path and image_path.is_file():
            if settings["image_mode"] == "embed":
                image = image_uri(image_path)
            else:
                shutil.copy2(image_path, relative_asset_dir / image_path.name)
                image = f"{settings['screenshots_folder']}/{image_path.name}"
        else:
            image = placeholder_uri(r["画面ID"], r.get("画面名", ""))
            warnings.append(f"画像なし: {r['画面ID']} {filename or '(未指定)'}")
        screens.append({
            "id": r["画面ID"], "name": r.get("画面名", ""), "category": r.get("機能分類", "その他"),
            "loginState": r.get("ログイン状態", ""), "os": r.get("OS", "共通"), "status": r.get("状態", "現行"),
            "image": image, "imageFile": filename, "imageMissing": not (image_path and image_path.is_file()),
            "order": sort_number(r.get("表示順", "")), "addedRelease": r.get("追加リリース", ""),
            "retiredRelease": r.get("廃止リリース", ""), "updatedRelease": r.get("最終更新リリース", ""),
            "description": r.get("説明", ""), "note": r.get("備考", ""), "change": change_by_screen.get(r["画面ID"], "")
        })
    screens.sort(key=lambda x: (x["order"], x["id"]))

    # Excelの日本語列名を、画面側のJavaScriptで使う項目名にそろえる。
    transitions = [{
        "id": r["遷移ID"], "from": r.get("遷移元画面ID", ""), "action": r.get("操作", ""),
        "condition": r.get("条件", ""), "to": r.get("遷移先画面ID", ""), "type": r.get("遷移種別", ""),
        "os": r.get("対象OS", ""), "addedRelease": r.get("追加リリース", ""),
        "retiredRelease": r.get("廃止リリース", ""), "note": r.get("備考", "")
    } for r in raw_transitions]
    changes = [{
        "release": r.get("リリース", ""), "type": r.get("種別", ""), "targetType": r.get("対象種別", ""),
        "screenId": r.get("画面ID", ""), "transitionId": r.get("遷移ID", ""), "description": r.get("変更内容", ""),
        "impactCheck": r.get("影響確認", ""), "owner": r.get("担当", ""), "updatedAt": excel_date(r.get("更新日", ""))
    } for r in raw_changes]

    # 画像登録機能が保存先を照合できるよう、元台帳のハッシュと相対パスを渡す。
    try:
        editor = {
            "projectName": ROOT.name,
            "excel": excel_path.resolve().relative_to(ROOT).as_posix(),
            "html": output_path.resolve().relative_to(ROOT).as_posix(),
            "screenshots": screenshot_dir.resolve().relative_to(ROOT).as_posix(),
            "workbookHash": hashlib.sha256(excel_path.read_bytes()).hexdigest(),
        }
    except ValueError:
        editor = None
    data = {"settings": settings, "screens": screens, "transitions": transitions, "changes": changes, "warnings": warnings, "editor": editor}
    # JSON内の「</script>」でHTMLのscriptタグが途中終了しないようにする。
    # 各JavaScriptとExcelの土台ファイルを埋め込み、配布可能な単独HTMLにする。
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    html = TEMPLATE.read_text(encoding="utf-8").replace(
        "__DIAGRAM_SCRIPT__", DIAGRAM_SCRIPT.read_text(encoding="utf-8")
    ).replace(
        "__IMAGE_EDITOR_SCRIPT__", IMAGE_EDITOR_SCRIPT.read_text(encoding="utf-8")
    ).replace(
        "__RECORD_EDITOR_SCRIPT__", RECORD_EDITOR_SCRIPT.read_text(encoding="utf-8")
    ).replace(
        "__EXCEL_EXPORT_SCRIPT__", EXCEL_EXPORT_SCRIPT.read_text(encoding="utf-8").replace(
            "__EXCEL_DIAGRAM_BASE__", base64.b64encode(EXCEL_DIAGRAM_BASE.read_bytes()).decode("ascii")
        )
    ).replace("__APP_DATA__", payload)
    output_path.write_text(html, encoding="utf-8")

    size_mb = output_path.stat().st_size / (1024 * 1024)
    print(f"生成完了: {output_path}")
    print(f"画面 {len(screens)}件 / 遷移 {len(transitions)}件 / 変更 {len(changes)}件 / {size_mb:.2f} MB")
    for warning in warnings:
        print("警告:", warning)
    if settings["image_mode"] == "embed" and size_mb > 50:
        print("警告: HTMLが50MBを超えました。画像圧縮または image_mode=relative を検討してください。")
    return {"data": data, "output_path": output_path}


def main():
    parser = argparse.ArgumentParser(description="Excelから画面遷移ビューアHTMLを生成します")
    parser.add_argument("--excel", type=Path, default=DEFAULT_EXCEL, help="入力Excelのパス")
    parser.add_argument("--output", type=Path, default=None, help="出力HTMLのパス")
    args = parser.parse_args()
    try:
        build(args.excel.resolve(), args.output.resolve() if args.output else None)
    except Exception as exc:
        print("生成に失敗しました:", exc, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
