import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {Workbook,SpreadsheetFile,FileBlob} from '@oai/artifact-tool';

const dir=path.join(os.tmpdir(),'screen-transition-excel-test');
for(const name of ['全体図','起動・権限','会員登録','ログイン']){
  const file=path.join(dir,`画面遷移図_${name}.xlsx`);
  const workbook=await SpreadsheetFile.importXlsx(await FileBlob.load(file));
  console.log(name,(await workbook.inspect({kind:'sheet',include:'id,name',maxChars:500})).ndjson);
  console.log((await workbook.inspect({kind:'drawing',sheetId:'画面遷移図',maxChars:1800})).ndjson);
  const range=name==='ログイン'?'A1:CC65':name==='会員登録'?'A1:EU70':'A1:CH35';
  const preview=await workbook.render({sheetName:'画面遷移図',range,scale:1,format:'png'});
  await fs.writeFile(path.join(dir,`preview-${name}.png`),new Uint8Array(await preview.arrayBuffer()));
}
