import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import sharp from 'sharp';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';

const root=path.resolve(import.meta.dirname,'..');
const dest=path.join(root,'outputs','01a0c3c6-901d-70b0-9832-541889814f0f');
const html=await fs.readFile(path.join(root,'output','画面遷移ビューア.html'),'utf8');
const data=JSON.parse(html.match(/<script type="application\/json" id="appData">([\s\S]*?)<\/script>/)[1]);
// Use the same graph layout, sized to a 20px Excel grid. Drawing data are retained.
let source=await fs.readFile(path.join(root,'template','diagram.js'),'utf8');
source=source.replace('CARD_W = 156, CARD_H = 264, COLUMN_GAP = 254','CARD_W = 160, CARD_H = 280, COLUMN_GAP = 240').replace('x:50+col*','x:40+col*');
const context=vm.createContext({});vm.runInContext(source+'\nglobalThis.makeLayout=layoutDiagram;',context);
const workbook=Workbook.create();
const grid=20,green='#23795F',brown='#97613A',ink='#20342D';
const categories=[...new Set(data.screens.map(s=>s.category))];
const imageCache=new Map();
await fs.mkdir(dest,{recursive:true});

function anchor(x,y,w,h){return {from:{row:Math.floor(y/grid),col:Math.floor(x/grid),rowOffsetPx:y%grid,colOffsetPx:x%grid},extent:{widthPx:w,heightPx:h}}}
function cellRange(sheet,x,y,w,h){return sheet.getRangeByIndexes(Math.round(y/grid),Math.round(x/grid),Math.max(1,Math.round(h/grid)),Math.max(1,Math.round(w/grid)))}
function label(sheet,x,y,w,h,text,color=ink,size=11,fill='#FFFFFF',bold=false){
  const range=cellRange(sheet,x,y,w,h);range.merge();range.values=[[String(text).startsWith('=')?"'"+text:text]];
  range.format={fill,font:{name:'Arial',size,color,bold},wrapText:true,horizontalAlignment:'center',verticalAlignment:'center'};
}
function visibleSegments(p,q,boxes){
  const horizontal=p[1]===q[1];if(!horizontal&&p[0]!==q[0])throw new Error('Expected orthogonal route');
  const axis=horizontal?0:1,other=1-axis,lo=Math.min(p[axis],q[axis]),hi=Math.max(p[axis],q[axis]);
  let intervals=[[lo,hi]];
  for(const b of boxes){
    const minOther=horizontal?b.y:b.x,maxOther=minOther+(horizontal?b.h:b.w);
    if(p[other]<minOther||p[other]>maxOther)continue;
    const start=horizontal?b.x:b.y,end=start+(horizontal?b.w:b.h);
    intervals=intervals.flatMap(([a,z])=>end<=a||start>=z?[[a,z]]:[[a,Math.max(a,start)],[Math.min(z,end),z]].filter(([l,r])=>r-l>.1));
  }
  return intervals.filter(([a,z])=>z-a>.1).map(([a,z])=>horizontal?[[a,p[1]],[z,p[1]]]:[[p[0],a],[p[0],z]]);
}
async function imageFor(screen){
  if(imageCache.has(screen.id))return imageCache.get(screen.id);
  let bytes;
  if(screen.image.startsWith('data:'))bytes=Buffer.from(screen.image.split(',')[1],'base64');
  else bytes=await fs.readFile(path.join(root,'output',decodeURIComponent(screen.image)));
  const png=await sharp(bytes).png().toBuffer(),meta=await sharp(png).metadata();
  const result={dataUrl:'data:image/png;base64,'+png.toString('base64'),width:meta.width,height:meta.height};imageCache.set(screen.id,result);return result;
}

const summaries=[];
for(const category of [null,...categories]){
  const local=new Set(data.screens.filter(s=>category===null||s.category===category).map(s=>s.id));
  const edges=data.transitions.filter(t=>local.has(t.from)||local.has(t.to)),ids=new Set(local);
  edges.forEach(t=>{ids.add(t.from);ids.add(t.to)});
  const nodes=data.screens.filter(s=>ids.has(s.id));
  const model=context.makeLayout(nodes,edges),sheetName=category||'全体図',sheet=workbook.worksheets.add(sheetName);
  sheet.showGridLines=false;sheet.tabColor=category?'#7DA18F':'#203F33';
  const cols=Math.ceil(model.width/grid)+2,rows=Math.ceil(model.height/grid)+4;
  sheet.getRangeByIndexes(0,0,rows,cols).format={columnWidthPx:grid,rowHeightPx:grid,font:{name:'Arial',size:11,color:ink},verticalAlignment:'center'};
  sheet.getRange('B2').values=[[`${data.settings.system_name} 画面遷移図 / ${sheetName}`]];
  sheet.getRange('B2').format.font={name:'Arial',size:16,bold:true,color:ink};
  sheet.getRange('B4').values=[[`リリース ${data.settings.current_release}　${nodes.length}画面・${edges.length}遷移　緑：進む　茶色の破線：戻る・循環　灰色：廃止記録あり`]];
  sheet.getRange('B5').values=[[category?'破線の画面枠：別機能との接続先。図の情報は生成時点の台帳に基づきます。':'画像・矢印は個別のオブジェクト、画面名・操作・条件はセルです。台帳の変更後は再生成してください。']];
  sheet.getRange('B4:CF5').format.font={name:'Arial',size:10,color:'#66786F'};
  const boxes=model.routes.map(r=>({x:Math.round((r.lx-100)/grid)*grid,y:Math.round(r.ly/grid)*grid,w:200,h:80}));
  // Native Excel line shapes, with native arrowhead shapes at the destination.
  model.routes.forEach((r,i)=>{
    const color=r.t.retiredRelease?'#9EAAA3':r.back?brown:green;
    r.points.slice(1).forEach((q,j)=>{
      const p=r.points[j];
      if(p[0]===q[0]&&p[1]===q[1])return;
      for(const [a,b] of visibleSegments(p,q,boxes)){
        const shape=sheet.shapes.add({geometry:'line',anchor:anchor(a[0],a[1],Math.max(.1,b[0]-a[0]),Math.max(.1,b[1]-a[1])),line:{fill:color,style:r.back?'dashed':'solid',width:1.5}});
        shape.name=`${r.t.id} ${r.t.from} → ${r.t.to}`;
      }
    });
    const end=r.points.at(-1);
    const arrow=sheet.shapes.add({geometry:'rightArrow',anchor:anchor(end[0]-12,end[1]-5,12,10),fill:color,line:{fill:color,width:.3}});arrow.name=`${r.t.id} 遷移先`;
  });
  for(const screen of nodes){
    const pos=model.positions.get(screen.id),x=pos.x,y=pos.y;
    const card=cellRange(sheet,x,y,160,280);card.format.fill='#F3F7F4';card.format.borders={preset:'outside',style:category&&!local.has(screen.id)?'dashed':'thin',color:'#83A995'};
    label(sheet,x,y,160,20,`${screen.id}　${screen.category}`,green,10,'#E9F1EC',true);
    label(sheet,x,y+220,160,60,screen.name,ink,11,'#F3F7F4',true);
    const image=await imageFor(screen),ratio=Math.min(140/image.width,190/image.height),w=image.width*ratio,h=image.height*ratio;
    sheet.images.add({dataUrl:image.dataUrl,anchor:anchor(x+(160-w)/2,y+25+(190-h)/2,w,h)});
  }
  model.routes.forEach((r,i)=>{
    const b=boxes[i],text=[r.t.action||'操作未記入',r.t.condition||'条件未記入',r.t.os&&r.t.os!=='共通'?r.t.os:'',r.t.retiredRelease?`廃止：${r.t.retiredRelease}`:''].filter(Boolean).join('\n');
    label(sheet,b.x,b.y,b.w,b.h,text,r.back?brown:ink,10,r.back?'#FFF9F1':'#FFFFFF');
    cellRange(sheet,b.x,b.y,b.w,b.h).format.borders={preset:'outside',style:'thin',color:r.back?'#D7BEA4':'#C5D8CE'};
  });
  summaries.push({name:sheetName,nodes:nodes.length,edges:edges.length,width:model.width,height:model.height});
}
workbook.recalculate();
console.log((await workbook.inspect({kind:'sheet',include:'id,name',maxChars:1800})).ndjson);
const file=await SpreadsheetFile.exportXlsx(workbook);await file.save(path.join(dest,'画面遷移図.xlsx'));
// Verify each diagram at a readable size. The global view is checked in two regions.
const regions=[['全体図','A1:CH24'],['全体図','EH1:LR65'],['起動・権限','A1:FK25'],['会員登録','A1:FE63'],['ログイン','A1:BP45']];
for(const [name,range] of regions){
  const preview=await workbook.render({sheetName:name,range,scale:1,format:'png'});
  await fs.writeFile(path.join(import.meta.dirname,`${name}-${range.replaceAll(':','-')}.png`),new Uint8Array(await preview.arrayBuffer()));
}
await fs.writeFile(path.join(import.meta.dirname,'summary.json'),JSON.stringify(summaries,null,2));
console.log(JSON.stringify({output:path.join(dest,'画面遷移図.xlsx'),sheets:summaries}));
