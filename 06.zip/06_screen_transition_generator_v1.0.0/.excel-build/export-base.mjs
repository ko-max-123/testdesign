import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';

// Small portable workbook scaffold; the browser fills the drawing at export time.
const root=path.resolve(import.meta.dirname,'..');
const workbook=Workbook.create();
const sheet=workbook.worksheets.add('画面遷移図');
sheet.showGridLines=false;
sheet.tabColor='#23795F';
sheet.getRange('A1:Z8').format={font:{name:'Arial',size:11,color:'#20342D'},columnWidthPx:20,rowHeightPx:20};
sheet.getRange('B2').values=[['画面遷移図']];
sheet.getRange('B2').format.font={name:'Arial',size:16,bold:true,color:'#20342D'};
sheet.getRange('B4').values=[['生成時点の画面と遷移']];
workbook.recalculate();
await(await SpreadsheetFile.exportXlsx(workbook)).save(path.join(root,'template','excel_diagram_base.xlsx'));
console.log((await workbook.inspect({kind:'sheet',include:'id,name',maxChars:500})).ndjson);
