@echo off
rem Rebuild the HTML, then keep the local viewer server in this window.
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 generate.py
) else (
  python generate.py
)
if errorlevel 1 (
  echo.
  echo HTML generation failed. See the error above.
  pause
  exit /b 1
)

echo.
echo HTML generation completed. Starting the viewer...
call run_viewer.bat
