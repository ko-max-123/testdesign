"""Check the actual exported DrawingML for condition boxes covering screen cards."""
from pathlib import Path
from tempfile import gettempdir
from zipfile import ZipFile
from xml.etree import ElementTree as ET

ROOT = Path(gettempdir()) / "screen-transition-excel-test"
NS = {
    "xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
}


def rectangle(shape):
    transform = shape.find("xdr:spPr/a:xfrm", NS)
    off = transform.find("a:off", NS)
    ext = transform.find("a:ext", NS)
    x, y = int(off.get("x")), int(off.get("y"))
    return (x, y, x + int(ext.get("cx")), y + int(ext.get("cy")))


def overlaps(a, b):
    return a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]


for name in ("全体図", "起動・権限", "会員登録", "ログイン"):
    file = ROOT / f"画面遷移図_{name}.xlsx"
    with ZipFile(file) as package:
        assert package.testzip() is None, file
        drawing = ET.fromstring(package.read("xl/drawings/drawing1.xml"))
    shapes = []
    for shape in drawing.findall(".//xdr:sp", NS):
        title = shape.find("xdr:nvSpPr/xdr:cNvPr", NS).get("name")
        shapes.append((title, rectangle(shape)))
    cards = [(title, rect) for title, rect in shapes if title.startswith("画面 ")]
    labels = [(title, rect) for title, rect in shapes if title.startswith("条件 ")]
    assert cards and labels, file
    collisions = [(label, card) for label, lbox in labels for card, cbox in cards if overlaps(lbox, cbox)]
    assert not collisions, f"{name}: {collisions}"
    for i, (title, box) in enumerate(labels):
        assert all(not overlaps(box, other) for _, other in labels[:i]), f"{name}: {title} overlaps another condition"
    print(f"PASS {name}: {len(cards)} screens, {len(labels)} labels, no overlaps")
