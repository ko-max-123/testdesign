// Use a disposable project copy. The user's workbook is never written by this test.
const {chromium}=require(process.env.PLAYWRIGHT_MODULE_PATH||'playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const net=require('node:net');
const http=require('node:http');
const {spawn,execFileSync}=require('node:child_process');

const project=path.resolve(__dirname,'..');
const fixture=fs.mkdtempSync(path.join(os.tmpdir(),'screen-flow-local-server-'));
for(const name of ['generate.py','local_server.py'])fs.copyFileSync(path.join(project,name),path.join(fixture,name));
for(const name of ['input','template'])fs.cpSync(path.join(project,name),path.join(fixture,name),{recursive:true});
fs.mkdirSync(path.join(fixture,'output'));
const original=fs.readFileSync(path.join(project,'input/画面遷移管理.xlsx'));
const python=process.env.PYTHON_EXE||'python';
const screenId='QA-'+Date.now(),edgeId='TR-QA-'+Date.now();

function freePort(){return new Promise(resolve=>{const server=net.createServer();server.listen(0,'127.0.0.1',()=>{const port=server.address().port;server.close(()=>resolve(port))})})}
function health(port){return new Promise(resolve=>{
  http.get(`http://127.0.0.1:${port}/api/health`,response=>{
    let body='';response.on('data',x=>body+=x);response.on('end',()=>{try{resolve(JSON.parse(body))}catch{resolve(null)}});
  }).on('error',()=>resolve(null));
})}
async function ready(port,child){
  for(let attempt=0;attempt<50;attempt++){
    if(child.exitCode!==null)throw new Error(`server exited: ${child.exitCode}`);
    const result=await health(port);if(result?.project===fixture)return;
    await new Promise(resolve=>setTimeout(resolve,150));
  }
  throw new Error('server did not start');
}

(async()=>{
  const port=await freePort(),server=spawn(python,['local_server.py','--port',String(port)],{
    cwd:fixture,env:{...process.env,PYTHONIOENCODING:'utf-8',PYTHONDONTWRITEBYTECODE:'1'},stdio:['ignore','pipe','pipe']
  });
  let serverOutput='';server.stdout.on('data',x=>serverOutput+=x);server.stderr.on('data',x=>serverOutput+=x);
  let browser;
  try{
    await ready(port,server);
    browser=await chromium.launch({channel:'msedge',headless:true});
    const page=await browser.newPage({viewport:{width:1400,height:1000}}),errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.goto(`http://127.0.0.1:${port}/`);
    assert.equal(await page.evaluate(()=>localSaveAvailable()),true);
    const initialHash=await page.evaluate(()=>app.editor.workbookHash);
    assert.equal(await page.evaluate(async()=>{const response=await fetch('/api/save-workbook',{method:'POST',body:new Uint8Array([1])});return response.status}),403);
    await page.evaluate(()=>{window.showDirectoryPicker=()=>{throw new Error('folder picker must not be called')}});
    await page.locator('#editDiagram').click();
    assert.equal(await page.locator('#recordConnectFolder').isVisible(),false);
    assert.equal(await page.locator('#recordSave').isDisabled(),false);

    await page.locator('#recordField_id').fill(screenId);
    await page.locator('#recordField_name').fill('サーバー保存テスト画面');
    await page.locator('#recordField_category').fill('検証');
    await page.locator('#recordSave').click();
    await page.waitForFunction(()=>!recordEditor.busy);
    assert.match(await page.locator('#recordStatus').innerText(),/ExcelとHTMLに保存しました/);

    await page.locator('#recordKind').selectOption('transition');
    await page.locator('#recordField_id').fill(edgeId);
    await page.locator('#recordField_from').selectOption(screenId);
    await page.locator('#recordField_to').selectOption('0.1');
    await page.locator('#recordField_action').fill('テスト操作');
    await page.locator('#recordField_condition').fill('テスト条件');
    await page.locator('#recordSave').click();
    await page.waitForFunction(()=>!recordEditor.busy);
    assert.match(await page.locator('#recordStatus').innerText(),/ExcelとHTMLに保存しました/);
    await page.locator('#closeRecordEditor').click();

    await page.evaluate(id=>openDetail(id),screenId);
    await page.locator('#chooseScreenImage').click();
    await page.waitForFunction(()=>!document.getElementById('imageFileChoice').disabled);
    assert.equal(await page.locator('#connectImageFolder').isVisible(),false);
    const imageName=await page.locator('#imageFileChoice option').nth(1).innerText();
    await page.locator('#imageFileChoice').selectOption({label:imageName});
    await page.waitForFunction(()=>!document.getElementById('saveScreenImage').disabled);
    await page.locator('#saveScreenImage').click();
    await page.waitForFunction(()=>!imageEditor.busy);
    assert.match(await page.locator('#imageEditorStatus').innerText(),/ExcelとHTMLに保存しました/);
    assert.equal(await page.evaluate(id=>byId(id).imageFile,screenId),imageName);
    assert.equal(await page.evaluate(id=>transitions.some(x=>x.id===id),edgeId),true);
    const staleStatus=await page.evaluate(async oldHash=>{
      const bytes=await localWorkbookBytes();
      const response=await fetch('/api/save-workbook',{method:'POST',headers:{'Content-Type':'application/octet-stream',
        'X-Viewer-Token':localSaveToken(),'X-Expected-Workbook-Hash':oldHash,
        'X-Expected-Html-Hash':document.querySelector('meta[name="local-html-hash"]').content},body:bytes});
      return response.status;
    },initialHash);
    assert.equal(staleStatus,409);
    assert.deepEqual(errors,[]);

    const saved=fs.readFileSync(path.join(fixture,'input/画面遷移管理.xlsx'));
    assert.notDeepEqual(saved,original);
    assert.deepEqual(fs.readFileSync(path.join(project,'input/画面遷移管理.xlsx')),original);
    assert.equal(fs.readdirSync(path.join(fixture,'backups')).length,6);
    const check=`import zipfile;from pathlib import Path;from generate import XlsxReader;p=Path('input/画面遷移管理.xlsx');z=zipfile.ZipFile(p);assert z.testzip() is None;x=XlsxReader(p);a=x.records('画面マスタ','画面ID');b=x.records('遷移マスタ','遷移ID');assert any(r['画面ID']=='${screenId}' and r['画像ファイル']=='${imageName}' for r in a);assert any(r['遷移ID']=='${edgeId}' and r['条件']=='テスト条件' for r in b);x.close()`;
    execFileSync(python,['-c',check],{cwd:fixture,env:{...process.env,PYTHONIOENCODING:'utf-8'}});
    console.log('PASS: click Save writes screen, transition and image to fixed Excel/HTML; no folder picker or user-workbook writes.');
  }finally{
    if(browser)await browser.close();server.kill();
    if(server.exitCode!==null&&server.exitCode!==0)console.error(serverOutput.slice(-1000));
  }
})().catch(error=>{console.error(error);process.exitCode=1});
