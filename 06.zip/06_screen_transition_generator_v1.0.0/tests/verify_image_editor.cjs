// Isolated browser filesystem test. The user's workbook is read but never overwritten.
const {chromium}=require(process.env.PLAYWRIGHT_MODULE_PATH||'playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');

(async()=>{
  const project=path.resolve(__dirname,'..');
  const html=fs.readFileSync(path.join(project,'output/画面遷移ビューア.html'),'utf8');
  const data=JSON.parse(html.match(/<script type="application\/json" id="appData">([\s\S]*?)<\/script>/)[1]);
  const original=fs.readFileSync(path.join(project,data.editor.excel));
  const sourceName=fs.readdirSync(path.join(project,data.editor.screenshots)).find(n=>/\.jpg$/i.test(n));
  const image=fs.readFileSync(path.join(project,data.editor.screenshots,sourceName));
  const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html)});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const browser=await chromium.launch({headless:true,channel:'msedge'});
  try{
    const page=await browser.newPage({viewport:{width:1300,height:1000}}),errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.goto(`http://127.0.0.1:${server.address().port}/`);
    // OPFS does not enforce the local filesystem's leading-tilde name restriction.
    // Model it explicitly so accidentally probing Excel lock files fails this test.
    await page.evaluate(()=>{
      const original=FileSystemDirectoryHandle.prototype.getFileHandle;
      window.rejectedNameProbes=[];
      FileSystemDirectoryHandle.prototype.getFileHandle=function(name,...args){
        if(String(name).startsWith('~')){rejectedNameProbes.push(name);throw new TypeError("Failed to execute 'getFileHandle' on 'FileSystemDirectoryHandle': Name is not allowed.")}
        return original.call(this,name,...args);
      };
    });
    // A native FileSystemDirectoryHandle in browser-private storage substitutes only the picker.
    const fixture=await page.evaluate(async({original,image,sourceName,html})=>{
      const root=await navigator.storage.getDirectory();
      const screen=app.screens[0];
      const patch=await patchWorkbookImage(new Uint8Array(original),screen.id,'',screen.imageFile);
      const bytes=new Uint8Array(await patch.blob.arrayBuffer());
      screen.imageFile='';screen.imageMissing=true;app.editor.workbookHash=await sha256(bytes);
      app.warnings=app.screens.filter(s=>s.imageMissing).map(s=>`画像なし: ${s.id} ${s.imageFile||'(未指定)'}`);
      const fixtureHtml=serializedViewer(html,app);
      await writeFile(await fileAt(root,app.editor.excel,true),bytes);
      await writeFile(await fileAt(root,app.editor.html,true),fixtureHtml);
      const directory=await directoryAt(root,app.editor.screenshots,true);
      await writeFile(await directory.getFileHandle(sourceName,{create:true}),new Uint8Array(image));
      window.showDirectoryPicker=async()=>root;window.testRoot=root;window.testOriginal=bytes;window.testHtml=fixtureHtml;
      openDetail(screen.id);return {id:screen.id};
    },{original:[...original],image:[...image],sourceName,html});
    await page.locator('#chooseScreenImage').click();
    assert.match(await page.locator('#imageEditorTitle').innerText(),new RegExp(fixture.id.replaceAll('.','\\.')));
    // Reproduce the reported NotFoundError when selecting screenshots or input directly.
    for(const folder of [data.editor.screenshots,'input']){
      await page.evaluate(folder=>{showDirectoryPicker=()=>directoryAt(testRoot,folder)},folder);
      await page.locator('#connectImageFolder').click();
      await page.waitForFunction(()=>document.getElementById('imageEditorStatus').textContent.includes('親フォルダを選んで'));
      assert.equal(await page.locator('#saveScreenImage').isDisabled(),true);
      assert.equal(await page.evaluate(()=>imageEditor.root),null);
    }
    await page.evaluate(()=>{showDirectoryPicker=async()=>testRoot});
    await page.locator('#connectImageFolder').click();
    await page.waitForFunction(()=>!document.getElementById('imageFileChoice').disabled);
    // Selecting a new incomplete folder clears a previously valid connection and reports the missing HTML.
    await page.evaluate(async()=>{const parts=pathSegments(app.editor.html),name=parts.pop();const dir=await directoryAt(testRoot,parts.join('/'));await dir.removeEntry(name)});
    await page.locator('#connectImageFolder').click();
    await page.waitForFunction(()=>document.getElementById('imageEditorStatus').textContent.includes('親フォルダを選んで'));
    assert.match(await page.locator('#imageEditorStatus').innerText(),/画面遷移ビューア.html/);
    assert.equal(await page.locator('#imageFileChoice').isDisabled(),true);
    await page.evaluate(async()=>{await writeFile(await fileAt(testRoot,app.editor.html,true),testHtml)});
    await page.locator('#connectImageFolder').click();await page.waitForFunction(()=>!document.getElementById('imageFileChoice').disabled);
    // A file removed after listing produces an actionable refresh message.
    await page.evaluate(async()=>{const file=imageEditor.files[0];window.removedImageName=file.name;window.removedImage=await fileBytes(file.handle);const dir=await directoryAt(testRoot,app.editor.screenshots);await dir.removeEntry(file.name)});
    await page.locator('#imageFileChoice').selectOption({label:sourceName});
    await page.waitForFunction(()=>document.getElementById('imageEditorStatus').textContent.includes('一覧を更新'));
    assert.equal(await page.locator('#saveScreenImage').isDisabled(),true);
    await page.evaluate(async()=>{const dir=await directoryAt(testRoot,app.editor.screenshots);await writeFile(await dir.getFileHandle(removedImageName,{create:true}),removedImage)});
    await page.locator('#refreshImageChoices').click();await page.waitForFunction(()=>document.getElementById('imageFileChoice').value==='');
    await page.locator('#imageFileChoice').selectOption({label:sourceName});
    await page.waitForFunction(()=>!document.getElementById('saveScreenImage').disabled);
    assert.equal(await page.locator('#imageChoicePreview').isVisible(),true);
    await page.screenshot({path:path.join(require('node:os').tmpdir(),'image-registration-preview.png')});
    await page.locator('#saveScreenImage').click();
    await page.waitForFunction(()=>!imageEditor.busy);
    assert.match(await page.locator('#imageEditorStatus').innerText(),/^保存しました/);
    const result=await page.evaluate(async()=>{
      const bytes=await fileBytes(await fileAt(testRoot,app.editor.excel));
      const before=new WorkbookZip(testOriginal),after=new WorkbookZip(bytes),changed=[];
      for(const e of before.entries){const a=await before.read(e.name),b=await after.read(e.name);if(await sha256(a)!==await sha256(b))changed.push(e.name)}
      const savedHtml=await (await(await fileAt(testRoot,app.editor.html)).getFile()).text();
      const savedData=JSON.parse(new DOMParser().parseFromString(savedHtml,'text/html').getElementById('appData').textContent);
      const backup=await testRoot.getDirectoryHandle('backups');let backups=0;for await(const _ of backup.entries())backups++;
      const doc=parseXml(utf8Decoder.decode(await after.read(changed[0]))),oldDoc=parseXml(utf8Decoder.decode(await before.read(changed[0])));
      const row=xmlElements(doc,'row').find(r=>xmlElements(r,'c').some(c=>cellValue(c,[]).trim()===app.screens[0].id));
      // Verify all XML except the one image cell remains byte-identical by reversing that cell.
      const reversed=await patchWorkbookImage(bytes,app.screens[0].id,'',app.screens[0].imageFile);
      const reverseZip=new WorkbookZip(new Uint8Array(await reversed.blob.arrayBuffer()));
      const worksheetPreserved=await sha256(await reverseZip.read(changed[0]))===await sha256(await before.read(changed[0]));
      window.savedTestHtml=savedHtml;
      return {changed,backups,imageMissing:savedData.screens[0].imageMissing,imageFile:savedData.screens[0].imageFile,embedded:savedData.screens[0].image.startsWith('data:image/'),hash:savedData.editor.workbookHash===await sha256(bytes),worksheetPreserved};
    });
    assert.equal(result.changed.length,1);assert.match(result.changed[0],/^xl\/worksheets\//);assert.equal(result.backups,2);
    assert.equal(result.imageMissing,false);assert.equal(result.imageFile,sourceName);assert.equal(result.embedded,true);assert.equal(result.hash,true);assert.equal(result.worksheetPreserved,true);
    assert.deepEqual(await page.evaluate(()=>rejectedNameProbes),[]);
    const savedWorkbook=await page.evaluate(async()=>[...await fileBytes(await fileAt(testRoot,app.editor.excel))]);
    fs.writeFileSync(path.join(require('node:os').tmpdir(),'image-editor-roundtrip.xlsx'),Buffer.from(savedWorkbook));
    // Denied output writes must leave the workbook unchanged. A failed HTML commit is recoverable.
    await page.evaluate(async()=>{
      const dir=await directoryAt(testRoot,app.editor.screenshots),source=imageEditor.files[0];
      await writeFile(await dir.getFileHandle('replacement.jpg',{create:true}),await source.handle.getFile());
      await loadImageChoices();window.realPrepareImageSave=prepareImageSave;
    });
    await page.locator('#imageFileChoice').selectOption({label:'replacement.jpg'});
    await page.waitForFunction(()=>!document.getElementById('saveScreenImage').disabled);
    await page.evaluate(()=>{
      prepareImageSave=async()=>{const saved=await realPrepareImageSave();saved.htmlHandle={createWritable:async()=>{throw new DOMException('TEST: output locked','NotAllowedError')},getFile:()=>fileAt(testRoot,app.editor.html).then(h=>h.getFile())};return saved};
    });
    await page.locator('#saveScreenImage').click();await page.waitForFunction(()=>!imageEditor.busy);
    assert.match(await page.locator('#imageEditorStatus').innerText(),/保存できませんでした/);
    assert.equal(await page.evaluate(async()=>sha256(await fileBytes(await fileAt(testRoot,app.editor.excel)))),await page.evaluate(()=>app.editor.workbookHash));
    await page.evaluate(()=>{
      prepareImageSave=async()=>{
        const saved=await realPrepareImageSave(),handle=saved.htmlHandle;let fail=true;
        saved.htmlHandle={getFile:()=>handle.getFile(),createWritable:async()=>{const stream=await handle.createWritable();return {write:data=>stream.write(data),abort:()=>stream.abort(),close:async()=>{if(fail){fail=false;throw new Error('TEST: HTML commit failed')}return stream.close()}}}};
        return saved;
      };
    });
    await page.locator('#saveScreenImage').click();await page.waitForFunction(()=>!imageEditor.busy);
    assert.match(await page.locator('#imageEditorStatus').innerText(),/Excelは保存済み/);
    assert.equal(await page.locator('#retryHtmlSave').isVisible(),true);
    assert.equal(await page.locator('#saveScreenImage').isDisabled(),true);
    await page.locator('#retryHtmlSave').click();await page.waitForFunction(()=>!imageEditor.busy);
    assert.match(await page.locator('#imageEditorStatus').innerText(),/保存が完了/);
    assert.equal(await page.evaluate(()=>app.screens[0].imageFile),'replacement.jpg');
    await page.evaluate(async()=>{savedTestHtml=await(await(await fileAt(testRoot,app.editor.html)).getFile()).text()});
    const savedHtml=await page.evaluate(()=>savedTestHtml);
    await page.route('**/saved',route=>route.fulfill({contentType:'text/html',body:savedHtml}));
    await page.goto(`http://127.0.0.1:${server.address().port}/saved`);
    assert.equal(await page.evaluate(()=>app.screens[0].imageMissing),false);
    // Stale workbook check prevents any writes when the workbook has changed outside this viewer.
    const stale=await page.evaluate(async()=>{const root=await navigator.storage.getDirectory();const handle=await fileAt(root,app.editor.excel);const bytes=await fileBytes(handle);bytes[bytes.length-1]^=1;await writeFile(handle,bytes);try{await assertWorkbookCurrent(root);return false}catch(e){return e.message.includes('ExcelがこのHTMLの生成後に変更')}});
    assert.equal(stale,true);assert.deepEqual(errors,[]);
    console.log('PASS: wrong screenshots/input selection, missing HTML and deleted image guidance, registration, Excel single-cell change, backups, reopen, locked output, partial-save retry and stale workbook rejection; no user workbook modified.');
  }finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
})().catch(e=>{console.error(e);process.exitCode=1});
