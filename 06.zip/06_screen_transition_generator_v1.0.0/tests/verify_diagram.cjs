// Run after generate.py. Requires Playwright and Microsoft Edge for browser checks.
const {chromium}=require(process.env.PLAYWRIGHT_MODULE_PATH||'playwright');
const assert=require('node:assert/strict');
const path=require('node:path');
const {pathToFileURL}=require('node:url');

(async()=>{
  const browser=await chromium.launch({headless:true,channel:'msedge'});
  try {
    const page=await browser.newPage({viewport:{width:1600,height:1000}});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.goto(pathToFileURL(path.resolve(__dirname,'../output/画面遷移ビューア.html')).href);
    assert.equal(await page.locator('#mapView').isVisible(),true);
    assert.equal(await page.locator('#screensView').isVisible(),false);
    const data=await page.evaluate(()=>({nodes:screens.length,edges:transitions.length}));
    assert.equal(await page.locator('.diagram-node').count(),data.nodes);
    assert.equal(await page.locator('.diagram-edge').count(),data.edges);
    assert.equal(await page.locator('.edge-label').count(),data.edges);
    assert.equal(await page.evaluate(()=>new Set([...document.querySelectorAll('.diagram-node')].map(n=>n.dataset.id)).size),data.nodes);
    await page.locator('.chip[data-cat="会員登録"]').click();
    assert.equal(await page.locator('.diagram-node[data-id="1.1"]').count(),1);
    assert.equal(await page.locator('.diagram-node[data-id="3.1"]').count(),1);
    assert.equal(await page.locator('.diagram-node[data-id="3.1"]').getAttribute('class').then(c=>c.includes('external-node')),true);
    assert.ok(await page.evaluate(()=>diagramModel.routes.filter(r=>r.t.from==='1.1').length)>=2);
    assert.equal(await page.evaluate(()=>diagramModel.routes.some(r=>r.t.type==='戻る'&&r.back)),true);
    // Fit into the expanded canvas, inspect conditions and navigate to an endpoint.
    await page.locator('#expandDiagram').click();await page.locator('#zoomFit').click();
    const route=await page.evaluate(()=>diagramModel.routes.findIndex(r=>r.t.from==='1.1'&&r.t.to==='2.3'));
    await page.locator(`[data-route="${route}"]`).click();
    assert.match(await page.locator('#drawerBody').innerText(),/会員未登録/);
    await page.locator('#drawerBody [data-id="2.3"]').click();
    assert.match(await page.locator('#drawerBody').innerText(),/新規会員登録/);
    await page.locator('#close').click();
    const scale=await page.evaluate(()=>diagramScale);await page.locator('#zoomIn').click();assert.ok(await page.evaluate(()=>diagramScale)>scale);
    await page.locator('#zoomReset').click();assert.equal(await page.evaluate(()=>diagramScale),1);
    const rect=await page.locator('#flow').boundingBox();
    await page.mouse.move(rect.x+450,rect.y+30);await page.mouse.down();await page.mouse.move(rect.x+150,rect.y+30,{steps:8});await page.mouse.up();
    assert.ok(await page.locator('#flow').evaluate(el=>el.scrollLeft)>0);
    await page.locator('#miniMap').click({position:{x:170,y:45}});
    assert.ok(await page.locator('#flow').evaluate(el=>el.scrollLeft)>300);
    // Synthetic branch, merge, parallel edge, cycle, self-loop and disconnected node.
    const layout=await page.evaluate(()=>{
      const ns=['A','B','C','D','E'].map(id=>({id}));
      const pairs=[['A','B'],['A','C'],['B','D'],['C','D'],['A','B'],['D','A'],['C','C']];
      const es=pairs.map(([from,to],i)=>({id:String(i),from,to,type:'通常'}));
      const m=layoutDiagram(ns,es);
      const overlap=[...m.positions.values()].some((a,i,all)=>all.slice(i+1).some(b=>a.x<b.x+CARD_W&&a.x+CARD_W>b.x&&a.y<b.y+CARD_H&&a.y+CARD_H>b.y));
      return {nodes:m.positions.size,routes:m.routes.length,backs:m.routes.filter(r=>r.back).length,overlap,finite:m.routes.every(r=>r.points.every(p=>p.every(Number.isFinite))),minY:Math.min(...m.routes.flatMap(r=>r.points.map(p=>p[1])))};
    });
    assert.equal(layout.nodes,5);assert.equal(layout.routes,7);assert.ok(layout.backs>=2);assert.equal(layout.overlap,false);assert.ok(layout.finite);assert.ok(layout.minY>=0);
    await page.keyboard.press('Escape');assert.equal(await page.locator('#mapPanel.expanded').count(),0);
    await page.locator('[data-view="screens"]').click();assert.equal(await page.locator('#screensView').isVisible(),true);
    await page.locator('[data-view="map"]').click();assert.equal(await page.locator('#mapView').isVisible(),true);
    assert.deepEqual(errors,[]);
    console.log('PASS: one node per screen; all transitions; branches, merges, returns, loops, parallel edges; detail navigation; pan, zoom, fit, minimap and view switching; no browser errors.');
  } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1});
