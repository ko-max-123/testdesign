const {chromium}=require(process.env.PLAYWRIGHT_MODULE_PATH||'playwright');
const fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
(async()=>{
  const root=path.resolve(__dirname,'..'),output=process.env.EXCEL_EXPORT_TEST_OUTPUT||path.join(require('node:os').tmpdir(),'screen-transition-excel-test');
  await fs.mkdir(output,{recursive:true});
  const browser=await chromium.launch({channel:'msedge',headless:true});
  try{
    const page=await browser.newPage({acceptDownloads:true,viewport:{width:1600,height:1000}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.goto(pathToFileURL(path.join(root,'output/画面遷移ビューア.html')).href);
    const categories=await page.evaluate(()=>[null,...categories]);
    for(const category of categories){
      if(category===null)await page.locator('[data-all="true"]').click();else await page.locator(`.chip[data-cat="${category}"]`).click();
      const expect=await page.evaluate(()=>({nodes:diagramModel.nodes.length,edges:diagramModel.edges.length}));
      const downloaded=page.waitForEvent('download');await page.locator('#exportDiagramExcel').click();const file=await downloaded;
      assert.equal(await file.failure(),null);await file.saveAs(path.join(output,file.suggestedFilename()));
      await page.waitForFunction(()=>!document.getElementById('exportDiagramExcel').disabled);
      assert.match(await page.locator('#excelExportStatus').innerText(),/Excelを出力しました/);
      console.log(JSON.stringify({file:file.suggestedFilename(),...expect}));
    }
    // Long labels, XML metacharacters, and missing-image SVGs also need exportable native objects.
    const synthetic=await page.evaluate(async()=>{
      const m=structuredClone(diagramModel);m.nodes[0].name='テスト < & > '+('長い画面名'.repeat(8));
      m.nodes[0].image='data:image/svg+xml;base64,'+btoa('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="200"><rect width="100" height="200" fill="gray"/></svg>');
      m.routes[0].t.condition='条件 < & >\n'+('複数の長い条件を確認します。'.repeat(20));
      const blob=await buildExcelDiagram(m,diagramCategory),zip=new WorkbookZip(new Uint8Array(await blob.arrayBuffer()));
      const drawing=parseXml(utf8Decoder.decode(await zip.read('xl/drawings/drawing1.xml')));
      const labels=[...drawing.getElementsByTagNameNS(drawingNS,'sp')];
      return {size:blob.size,labels:labels.length,text:drawing.documentElement.textContent.includes('複数の長い条件を確認します。'),images:zip.entries.filter(e=>e.name.startsWith('xl/media/')).length};
    });
    assert.ok(synthetic.size>0);assert.ok(synthetic.labels>0);assert.ok(synthetic.text);assert.ok(synthetic.images>0);assert.deepEqual(errors,[]);
    console.log('PASS: all/category downloads, picture counts, native shapes, long labels, XML escaping and SVG placeholders.');
  }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
