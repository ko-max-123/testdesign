@echo off
rem Stop the local viewer server for this project.
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 stop_viewer.py
) else (
  python stop_viewer.py
)

echo.
pause
