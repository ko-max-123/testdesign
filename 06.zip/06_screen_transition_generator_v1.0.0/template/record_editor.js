// 画面・遷移の登録内容を、ブラウザから元のExcel台帳とHTMLへ保存する。
// 起動用バッチが開くローカルサーバーへ送信し、決まったExcelとHTMLを更新する。
const recordEditor={busy:false};
const recordDefinitions={
  screen:{sheet:'画面マスタ',columns:[
    ['id','画面ID',true],['name','画面名',true],['category','機能分類',true],
    ['loginState','ログイン状態'],['os','OS'],['status','状態'],['imageFile','画像ファイル'],
    ['order','表示順'],['addedRelease','追加リリース'],['retiredRelease','廃止リリース'],
    ['updatedRelease','最終更新リリース'],['description','説明'],['note','備考']
  ]},
  transition:{sheet:'遷移マスタ',columns:[
    ['id','遷移ID',true],['from','遷移元画面ID',true],['action','操作',true],
    ['condition','条件',true],['to','遷移先画面ID',true],['type','遷移種別'],
    ['os','対象OS'],['addedRelease','追加リリース'],['retiredRelease','廃止リリース'],['note','備考']
  ]}
};
const recordLongFields=new Set(['condition','description','note']);
const recordHiddenFields=new Set(['imageFile']); // 画像は既存の画像登録画面で選ぶ。

// 起動用バッチから開いたページには、ローカルサーバーが保存用トークンを付ける。
function localSaveToken(){return document.querySelector('meta[name="local-save-token"]')?.content||''}
function localSaveAvailable(){return location.hostname==='127.0.0.1'&&!!localSaveToken()}
async function localWorkbookBytes(){
  let response;
  try{response=await fetch('/api/workbook',{headers:{'X-Viewer-Token':localSaveToken()},cache:'no-store'})}
  catch{throw new Error('保存用サーバーに接続できません。run_viewer.bat から開き直してください。')}
  if(!response.ok)throw new Error((await response.json()).error||'Excelを読み込めません。');
  const bytes=new Uint8Array(await response.arrayBuffer());
  if(await sha256(bytes)!==app.editor.workbookHash)throw new Error('Excelがこのページを開いた後に変更されました。ページを開き直してください。');
  return bytes;
}
async function localCommitWorkbook(bytes){
  const htmlHash=document.querySelector('meta[name="local-html-hash"]')?.content||'';
  let response;
  try{response=await fetch('/api/save-workbook',{
      method:'POST',headers:{'Content-Type':'application/octet-stream','X-Viewer-Token':localSaveToken(),
        'X-Expected-Workbook-Hash':app.editor.workbookHash,'X-Expected-Html-Hash':htmlHash},body:bytes
    })}
  catch{throw new Error('保存用サーバーに接続できません。run_viewer.bat から開き直してください。')}
  const result=await response.json();
  if(!response.ok)throw new Error(result.error||'保存できませんでした。');
  document.querySelector('meta[name="local-html-hash"]').content=result.htmlHash;
  return result.data;
}

function recordMessage(message,error=false){
  $('recordStatus').textContent=message;$('recordStatus').classList.toggle('error',error);
}
function recordItems(kind){return kind==='screen'?screens:transitions}
function nextTransitionId(){
  const numbers=transitions.map(t=>/^TR(\d+)$/i.exec(t.id)?.[1]).filter(Boolean).map(Number);
  return 'TR'+String(Math.max(0,...numbers)+1).padStart(4,'0');
}
function recordDefaults(kind){
  return kind==='screen'
    ?{id:'',name:'',category:diagramCategory||categories[0]||'その他',loginState:'',os:'共通',status:'現行',imageFile:'',order:'',addedRelease:s.current_release,retiredRelease:'',updatedRelease:s.current_release,description:'',note:''}
    :{id:nextTransitionId(),from:'',action:'',condition:'',to:'',type:'通常',os:'共通',addedRelease:s.current_release,retiredRelease:'',note:''};
}
function recordValues(kind,id){
  const item=recordItems(kind).find(x=>x.id===id);
  if(!item)return recordDefaults(kind);
  const result={...item};
  if(kind==='screen'&&result.order===999999)result.order='';
  return result;
}
function renderRecordTargets(selected=''){
  const kind=$('recordKind').value,select=$('recordTarget');select.replaceChildren(new Option('新規登録',''));
  for(const item of recordItems(kind))select.add(new Option(`${item.id} ${kind==='screen'?item.name:`${item.from} → ${item.to} / ${item.action}`}`,item.id));
  select.value=selected;
  renderRecordFields();
}
function renderRecordFields(){
  const kind=$('recordKind').value,id=$('recordTarget').value,values=recordValues(kind,id),container=$('recordFields');
  container.replaceChildren();
  for(const [key,label,required] of recordDefinitions[kind].columns){
    if(recordHiddenFields.has(key))continue;
    const wrapper=document.createElement('label');wrapper.className='record-editor-field'+(recordLongFields.has(key)?' wide':'');
    wrapper.append(document.createTextNode(label));
    let field;
    if(key==='from'||key==='to'){
      field=document.createElement('select');field.add(new Option('画面を選択',''));
      for(const screen of screens)field.add(new Option(`${screen.id} ${screen.name}`,screen.id));
    }else field=document.createElement(recordLongFields.has(key)?'textarea':'input');
    field.id='recordField_'+key;field.name=key;field.value=values[key]??'';field.required=!!required;
    if(key==='id'&&id)field.readOnly=true; // 既存IDの変更は参照先の一括更新が必要なので防ぐ。
    if(key==='order'){field.type='number';field.step='any'}
    if(field.tagName==='INPUT'||field.tagName==='TEXTAREA')field.maxLength=32767;
    wrapper.append(field);container.append(wrapper);
  }
  recordMessage(id?`${id} を編集中です。`:'新規登録です。IDを決めて保存してください。');
}
function collectRecord(){
  const kind=$('recordKind').value,existingId=$('recordTarget').value,record={};
  for(const [key,,required] of recordDefinitions[kind].columns){
    if(recordHiddenFields.has(key))continue;
    const field=$('recordField_'+key);if(!field.reportValidity())throw new Error('必須項目を入力してください。');
    const value=field.value.trim();if(required&&!value)throw new Error(`${field.closest('label').firstChild.textContent}を入力してください。`);
    if(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value))throw new Error('制御文字は入力できません。');
    record[key]=value;
  }
  if(existingId&&record.id!==existingId)throw new Error('既存のIDは変更できません。');
  if(!existingId&&recordItems(kind).some(x=>x.id===record.id))throw new Error('同じIDがすでに登録されています。');
  if(kind==='transition'&&(!screens.some(x=>x.id===record.from)||!screens.some(x=>x.id===record.to)))throw new Error('遷移元と遷移先の画面を選択してください。');
  if(kind==='screen'){
    record.imageFile=existingId?byId(existingId).imageFile:'';
    if(record.order&&!Number.isFinite(Number(record.order)))throw new Error('表示順は数値で入力してください。');
  }
  return {kind,existingId,record};
}
// Excel内部の相対パスを、ZIP内の実際のパスへ直す。
function recordPartPath(base,target){
  if(target.startsWith('/'))return target.slice(1);
  const parts=(base.slice(0,base.lastIndexOf('/')+1)+target).split('/'),out=[];
  for(const part of parts){if(part==='..')out.pop();else if(part&&part!=='.')out.push(part)}
  return out.join('/');
}
function recordColumn(ref){return /^[A-Z]+/.exec(ref)?.[0]||''}
function recordCell(row,column){return xmlElements(row,'c').find(c=>recordColumn(c.getAttribute('r')||'')===column)}
function recordNewRow(doc,sheetData,rows,number){
  const previous=rows.at(-1),row=previous?previous.cloneNode(true):doc.createElementNS(xmlNS,'row');
  row.setAttribute('r',String(number));
  for(const cell of xmlElements(row,'c')){
    cell.setAttribute('r',recordColumn(cell.getAttribute('r'))+number);cell.removeAttribute('t');cell.replaceChildren();
  }
  sheetData.append(row);return row;
}
function recordSetCell(doc,row,column,number,value){
  let cell=recordCell(row,column);
  if(!cell){cell=doc.createElementNS(xmlNS,'c');cell.setAttribute('r',column+number);
    const next=xmlElements(row,'c').find(c=>cellColumn(c.getAttribute('r'))>cellColumn(column+number));
    row.insertBefore(cell,next||null);
  }
  if(xmlElements(cell,'f').length)throw new Error(`${column}${number} は数式のため更新できません。`);
  cell.setAttribute('t','inlineStr');cell.replaceChildren();
  const inline=doc.createElementNS(xmlNS,'is'),text=doc.createElementNS(xmlNS,'t');
  text.setAttribute('xml:space','preserve');text.textContent=value;inline.append(text);cell.append(inline);
}

// IDで対象行を探し、変更した列だけ書き換える。新規登録ならExcelテーブルも1行広げる。
async function patchWorkbookRecord(bytes,kind,existingId,record){
  const config=recordDefinitions[kind],zip=new WorkbookZip(bytes);
  const workbook=parseXml(utf8Decoder.decode(await zip.read('xl/workbook.xml')));
  const sheet=xmlElements(workbook,'sheet').find(x=>x.getAttribute('name')===config.sheet);
  if(!sheet)throw new Error(`${config.sheet}が見つかりません。`);
  const sheetRel=sheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
  const workbookRels=parseXml(utf8Decoder.decode(await zip.read('xl/_rels/workbook.xml.rels')));
  const sheetLink=[...workbookRels.getElementsByTagNameNS('*','Relationship')].find(x=>x.getAttribute('Id')===sheetRel);
  if(!sheetLink||sheetLink.getAttribute('TargetMode')==='External')throw new Error('シートの参照が不正です。');
  const sheetPath=recordPartPath('xl/workbook.xml',sheetLink.getAttribute('Target'));
  const doc=parseXml(utf8Decoder.decode(await zip.read(sheetPath)));
  if(xmlElements(doc,'sheetProtection').length)throw new Error(`${config.sheet}は保護されています。`);
  let shared=[];
  if(zip.entries.some(e=>e.name==='xl/sharedStrings.xml'))shared=xmlElements(parseXml(utf8Decoder.decode(await zip.read('xl/sharedStrings.xml'))),'si').map(si=>xmlElements(si,'t').map(t=>t.textContent).join(''));
  const sheetData=xmlElements(doc,'sheetData')[0],rows=xmlElements(sheetData,'row');
  const header=rows.find(row=>xmlElements(row,'c').some(c=>cellValue(c,shared).trim()===config.columns[0][1]));
  if(!header)throw new Error(`${config.sheet}の見出しが見つかりません。`);
  const columns=new Map(xmlElements(header,'c').map(c=>[cellValue(c,shared).trim(),recordColumn(c.getAttribute('r'))]));
  for(const [,label] of config.columns)if(!columns.has(label))throw new Error(`${config.sheet}に「${label}」列がありません。`);
  const idColumn=columns.get(config.columns[0][1]),body=rows.filter(r=>Number(r.getAttribute('r'))>Number(header.getAttribute('r')));
  const matches=body.filter(r=>cellValue(recordCell(r,idColumn),shared).trim()===(existingId||record.id));
  if(existingId&&matches.length!==1)throw new Error('編集対象のIDが見つからないか、重複しています。');
  if(!existingId&&matches.length)throw new Error('同じIDがExcelにすでに登録されています。');
  let row,number;
  if(existingId){row=matches[0];number=Number(row.getAttribute('r'))}
  else{
    const used=body.filter(r=>cellValue(recordCell(r,idColumn),shared).trim());
    number=Math.max(Number(header.getAttribute('r')),...used.map(r=>Number(r.getAttribute('r'))))+1;
    row=rows.find(r=>Number(r.getAttribute('r'))===number)||recordNewRow(doc,sheetData,rows,number);
    if(cellValue(recordCell(row,idColumn),shared).trim())throw new Error('追加先の行が使用されています。');
  }
  for(const [key,label] of config.columns){
    const value=String(record[key]??''),column=columns.get(label),old=recordCell(row,column);
    if(cellValue(old,shared)===value)continue;
    recordSetCell(doc,row,column,number,value);
  }
  const replacements=new Map([[sheetPath,utf8Encoder.encode(new XMLSerializer().serializeToString(doc))]]);
  if(!existingId){
    const dimension=xmlElements(doc,'dimension')[0];
    if(dimension){const oldEnd=Number(/\d+$/.exec(dimension.getAttribute('ref'))?.[0]||0);if(number>oldEnd)dimension.setAttribute('ref',dimension.getAttribute('ref').replace(/\d+$/,String(number)))}
    const tablePart=xmlElements(doc,'tablePart')[0];
    if(tablePart){
      const id=tablePart.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
      const relsPath=sheetPath.replace(/([^/]+)$/,'_rels/$1.rels');
      const rels=parseXml(utf8Decoder.decode(await zip.read(relsPath)));
      const link=[...rels.getElementsByTagNameNS('*','Relationship')].find(x=>x.getAttribute('Id')===id);
      if(!link||link.getAttribute('TargetMode')==='External')throw new Error('Excelテーブルの参照が不正です。');
      const tablePath=recordPartPath(sheetPath,link.getAttribute('Target'));
      const table=parseXml(utf8Decoder.decode(await zip.read(tablePath)));
      const ref=table.documentElement.getAttribute('ref'),last=Number(/\d+$/.exec(ref)?.[0]||0);
      if(number>last){const updated=ref.replace(/\d+$/,String(number));table.documentElement.setAttribute('ref',updated);const filter=xmlElements(table,'autoFilter')[0];if(filter)filter.setAttribute('ref',updated);replacements.set(tablePath,utf8Encoder.encode(new XMLSerializer().serializeToString(table)))}
    }
    replacements.set(sheetPath,utf8Encoder.encode(new XMLSerializer().serializeToString(doc)));
  }
  const blob=zip.replaceMany(replacements);
  return {blob,sheetPath,row:number,changed:[...replacements.keys()]};
}

function applyRecordSave(saved){
  screens.splice(0,screens.length,...saved.data.screens);
  transitions.splice(0,transitions.length,...saved.data.transitions);
  app.warnings=saved.data.warnings;app.editor=saved.data.editor;
  categories.splice(0,categories.length,...new Set(screens.map(x=>x.category).filter(Boolean)));
  const selectedCategory=$('category').value;
  $('category').innerHTML='<option value="all">すべての機能</option>'+categories.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
  $('category').value=categories.includes(selectedCategory)?selectedCategory:'all';
  $('navScreens').textContent=screens.length;$('navCategories').textContent=categories.length;$('transitionCount').textContent=transitions.length;
  $('warningCount').textContent=app.warnings.length;$('totalHint').textContent=`全${screens.length}画面`;
  $('warnings').hidden=!app.warnings.length;$('warnings').textContent=app.warnings.join(' / ');
  const category=diagramCategory,scale=diagramScale,left=$('flow').scrollLeft,top=$('flow').scrollTop;
  renderScreens();renderChips();
  if(category&&categories.includes(category))renderFlow(category);
  setDiagramScale(scale,false);$('flow').scrollTo(left,top);
  closeDrawer();renderRecordTargets(saved.record.id);
}
function setRecordBusy(busy){
  recordEditor.busy=busy;
  for(const id of ['recordKind','recordTarget','recordSave','closeRecordEditor'])$(id).disabled=busy;
  for(const field of $('recordFields').querySelectorAll('input,select,textarea'))field.disabled=busy;
}
async function saveRecord(){
  if(!localSaveAvailable()){
    recordMessage('直接保存するには、run_generate.bat または run_viewer.bat からビューアを開いてください。',true);
    return;
  }
  if(imageEditor.busy||imageEditor.pending){recordMessage('画像登録の保存が完了してから操作してください。',true);return}
  if(recordEditor.busy)return;
  setRecordBusy(true);recordMessage('ExcelとHTMLを保存しています…');
  try{
    const {kind,existingId,record}=collectRecord(),original=await localWorkbookBytes();
    const patched=await patchWorkbookRecord(original,kind,existingId,record);
    const data=await localCommitWorkbook(new Uint8Array(await patched.blob.arrayBuffer()));
    applyRecordSave({data,kind,record});
    recordMessage(`${kind==='screen'?'画面':'遷移'} ${record.id} をExcelとHTMLに保存しました。`);
  }catch(e){recordMessage('保存できませんでした。 '+e.message,true)}finally{setRecordBusy(false)}
}
function openRecordEditor(kind='screen',id=''){
  $('recordKind').value=kind;renderRecordTargets(id);
  $('recordFolderName').textContent=localSaveAvailable()
    ?`保存先：${app.editor.excel} ／ ${app.editor.html}`
    :'保存するには run_generate.bat または run_viewer.bat から開いてください。';
  setRecordBusy(false);
  $('recordSave').disabled=!localSaveAvailable();
  $('recordEditorDialog').showModal();
}
function initRecordEditor(){
  $('editDiagram').onclick=()=>openRecordEditor();
  document.addEventListener('click',e=>{const button=e.target.closest('#editCurrentScreen');if(button)openRecordEditor('screen',button.dataset.screenId)});
  $('closeRecordEditor').onclick=()=>$('recordEditorDialog').close();
  $('recordKind').onchange=()=>renderRecordTargets();$('recordTarget').onchange=renderRecordFields;
  $('recordSave').onclick=saveRecord;
  $('recordEditorDialog').addEventListener('cancel',e=>{if(recordEditor.busy)e.preventDefault()});
  window.addEventListener('beforeunload',e=>{if(recordEditor.busy){e.preventDefault();e.returnValue=''}});
}
