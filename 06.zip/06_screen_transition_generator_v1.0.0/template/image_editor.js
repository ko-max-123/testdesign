// 通常の画像登録はローカルサーバー経由で保存する。HTML単体で開いた場合は従来のフォルダ選択にも対応する。
// Excelでは画像ファイル名のセルだけ変更し、他のxlsx内部ファイルはそのまま残す。
const imageEditor={root:null,files:[],screenId:null,selected:null,previewUrl:null,busy:false,pending:null};
const xmlNS='http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const utf8Decoder=new TextDecoder('utf-8'),utf8Encoder=new TextEncoder();
function crc32(bytes){let c=0xffffffff;for(const b of bytes){c^=b;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0)}return (c^0xffffffff)>>>0}
async function sha256(bytes){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('')}

// Excelファイル（xlsx）の中から必要なXMLを読み、指定した1ファイルだけ差し替える。
class WorkbookZip{
  constructor(bytes){
    this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.entries=[];
    if(bytes.length>256*1024*1024)throw new Error('Excelファイルが大きすぎます（上限256MB）。');
    let end=-1;
    for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--){if(this.view.getUint32(i,true)===0x06054b50&&i+22+this.view.getUint16(i+20,true)===bytes.length){end=i;break}}
    if(end<0)throw new Error('通常の.xlsx形式のExcelを選択してください。');
    const v=this.view,count=v.getUint16(end+10,true);let offset=v.getUint32(end+16,true);
    if(v.getUint16(end+4,true)||v.getUint16(end+6,true)||count===65535||offset===0xffffffff)throw new Error('分割ZIP・ZIP64形式のExcelは更新できません。');
    this.centralOffset=offset;this.end=bytes.slice(end);
    for(let i=0;i<count;i++){
      if(offset+46>bytes.length||v.getUint32(offset,true)!==0x02014b50)throw new Error('Excelファイルの構造を読み取れません。');
      const length=46+v.getUint16(offset+28,true)+v.getUint16(offset+30,true)+v.getUint16(offset+32,true);
      const entry={name:utf8Decoder.decode(bytes.slice(offset+46,offset+46+v.getUint16(offset+28,true))),central:bytes.slice(offset,offset+length),method:v.getUint16(offset+10,true),flags:v.getUint16(offset+8,true),size:v.getUint32(offset+24,true),compressed:v.getUint32(offset+20,true),crc:v.getUint32(offset+16,true),offset:v.getUint32(offset+42,true)};
      if(entry.flags&1||entry.size===0xffffffff||entry.compressed===0xffffffff||entry.offset===0xffffffff)throw new Error('暗号化されたExcelまたはZIP64形式には対応していません。');
      if(this.entries.some(e=>e.name===entry.name))throw new Error('Excel内に重複したファイルがあります。');
      this.entries.push(entry);offset+=length;
    }
    if(this.entries.some(e=>e.name.startsWith('_xmlsignatures/')))throw new Error('署名付きExcelは変更できません。署名のない作業用台帳を使用してください。');
    const ordered=[...this.entries].sort((a,b)=>a.offset-b.offset);
    ordered.forEach((e,i)=>{e.end=ordered[i+1]?.offset??this.centralOffset});
  }
  async read(name){
    // 圧縮を解いてCRCを照合し、壊れたデータを編集しないようにする。
    const e=this.entries.find(e=>e.name===name);if(!e)throw new Error('Excel内に必要なデータがありません: '+name);
    const v=this.view,o=e.offset;
    if(v.getUint32(o,true)!==0x04034b50)throw new Error('Excel内のファイルヘッダーが不正です。');
    const start=o+30+v.getUint16(o+26,true)+v.getUint16(o+28,true);
    if(start+e.compressed>e.end||e.size>64*1024*1024)throw new Error('Excel内のデータサイズが不正または大きすぎます。');
    let bytes=this.bytes.slice(start,start+e.compressed);
    if(e.method===8)bytes=new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
    else if(e.method!==0)throw new Error('このExcelの圧縮形式には対応していません。');
    if(bytes.length!==e.size||crc32(bytes)!==e.crc)throw new Error('Excelファイルが破損しています。');
    return bytes;
  }
  replace(name,replacement){
    return this.replaceMany(new Map([[name,replacement]]));
  }
  replaceMany(replacements){
    // 変更対象以外のZIPデータはバイト列のままコピーする。
    for(const name of replacements.keys())if(!this.entries.some(e=>e.name===name))throw new Error('Excel内に更新先がありません: '+name);
    const locals=[],centrals=[];let offset=0;
    for(const e of this.entries){
      const central=e.central.slice(),cv=new DataView(central.buffer);let local;
      if(replacements.has(e.name)){
        const replacement=replacements.get(e.name),filename=utf8Encoder.encode(e.name),crc=crc32(replacement),flags=(e.flags&~8)|0x800;
        local=new Uint8Array(30+filename.length+replacement.length);const v=new DataView(local.buffer);
        v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,flags,true);v.setUint16(8,0,true);
        v.setUint16(10,cv.getUint16(12,true),true);v.setUint16(12,cv.getUint16(14,true),true);
        v.setUint32(14,crc,true);v.setUint32(18,replacement.length,true);v.setUint32(22,replacement.length,true);v.setUint16(26,filename.length,true);
        local.set(filename,30);local.set(replacement,30+filename.length);
        cv.setUint16(8,flags,true);cv.setUint16(10,0,true);cv.setUint32(16,crc,true);cv.setUint32(20,replacement.length,true);cv.setUint32(24,replacement.length,true);
      }else local=this.bytes.slice(e.offset,e.end);
      cv.setUint32(42,offset,true);locals.push(local);centrals.push(central);offset+=local.length;
    }
    const end=this.end.slice(),ev=new DataView(end.buffer),centralSize=centrals.reduce((n,c)=>n+c.length,0);
    ev.setUint32(12,centralSize,true);ev.setUint32(16,offset,true);
    return new Blob([...locals,...centrals,end],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
  }
}
function parseXml(text){const doc=new DOMParser().parseFromString(text,'application/xml');if(doc.getElementsByTagName('parsererror').length)throw new Error('ExcelのXMLを読み取れません。');return doc}
function xmlElements(root,name){return [...root.getElementsByTagNameNS(xmlNS,name)]}
function cellColumn(ref){let n=0;for(const c of ref.match(/^[A-Z]+/)[0])n=n*26+c.charCodeAt(0)-64;return n}
function cellValue(cell,shared){if(!cell)return '';const type=cell.getAttribute('t');if(type==='inlineStr')return xmlElements(cell,'t').map(t=>t.textContent).join('');const raw=xmlElements(cell,'v')[0]?.textContent||'';return type==='s'?shared[Number(raw)]??'':raw}
function packagePath(target){const parts=(target.startsWith('/')?target.slice(1):'xl/'+target).split('/'),out=[];for(const p of parts){if(p==='..')out.pop();else if(p&&p!=='.')out.push(p)}return out.join('/')}
// 「画面マスタ」で画面IDに一致する行の「画像ファイル」セルだけ書き換える。
async function patchWorkbookImage(bytes,screenId,filename,expectedFilename){
  const zip=new WorkbookZip(bytes),workbook=parseXml(utf8Decoder.decode(await zip.read('xl/workbook.xml')));
  const sheet=xmlElements(workbook,'sheet').find(s=>s.getAttribute('name')==='画面マスタ');if(!sheet)throw new Error('画面マスタシートがありません。');
  const relId=sheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
  const rels=parseXml(utf8Decoder.decode(await zip.read('xl/_rels/workbook.xml.rels')));
  const rel=[...rels.getElementsByTagNameNS('*','Relationship')].find(r=>r.getAttribute('Id')===relId);
  if(!rel||rel.getAttribute('TargetMode')==='External')throw new Error('画面マスタシートの参照が不正です。');
  const sheetPath=packagePath(rel.getAttribute('Target')),raw=utf8Decoder.decode(await zip.read(sheetPath)),doc=parseXml(raw);
  if(xmlElements(doc,'sheetProtection').length)throw new Error('画面マスタが保護されています。Excelで保護を解除してから再生成してください。');
  let shared=[];
  if(zip.entries.some(e=>e.name==='xl/sharedStrings.xml'))shared=xmlElements(parseXml(utf8Decoder.decode(await zip.read('xl/sharedStrings.xml'))),'si').map(si=>xmlElements(si,'t').map(t=>t.textContent).join(''));
  const rows=xmlElements(doc,'row');let header=null,idColumn=null,imageColumn=null;
  for(const row of rows){const cells=xmlElements(row,'c');const id=cells.find(c=>cellValue(c,shared).trim()==='画面ID'),image=cells.find(c=>cellValue(c,shared).trim()==='画像ファイル');if(id&&image){header=row;idColumn=id.getAttribute('r').match(/^[A-Z]+/)[0];imageColumn=image.getAttribute('r').match(/^[A-Z]+/)[0];break}}
  if(!header)throw new Error('画面ID・画像ファイルの見出しが見つかりません。');
  // 一意の画面IDを確認し、前回読み込んだファイル名と違う場合は上書きしない。
  const matches=rows.slice(rows.indexOf(header)+1).filter(row=>xmlElements(row,'c').some(c=>c.getAttribute('r')===idColumn+row.getAttribute('r')&&cellValue(c,shared).trim()===screenId));
  if(matches.length!==1)throw new Error('対象の画面IDが存在しないか、重複しています。');
  const row=matches[0],ref=imageColumn+row.getAttribute('r'),oldCell=xmlElements(row,'c').find(c=>c.getAttribute('r')===ref);
  if(cellValue(oldCell,shared).trim()!==(expectedFilename||''))throw new Error('Excelの画像設定が変更されています。HTMLを再生成してから登録してください。');
  if(oldCell&&xmlElements(oldCell,'f').length)throw new Error('画像ファイル欄が数式のため更新できません。');
  const tag=oldCell?.tagName||xmlElements(row,'c')[0]?.tagName||'c',prefix=tag.includes(':')?tag.split(':')[0]+':':'';
  const cell=oldCell?oldCell.cloneNode(false):doc.createElementNS(xmlNS,tag);cell.setAttribute('r',ref);cell.setAttribute('t','inlineStr');
  const is=doc.createElementNS(xmlNS,prefix+'is'),text=doc.createElementNS(xmlNS,prefix+'t');text.textContent=filename;is.append(text);cell.append(is);
  const serialized=new XMLSerializer().serializeToString(cell);
  const cellRE=/<(?:[\w]+:)?c\b[^>]*\br="([A-Z]+\d+)"[^>]*(?:\/>|>[\s\S]*?<\/(?:[\w]+:)?c>)/g;
  let updated=raw;
  if(oldCell){let found=false;updated=raw.replace(cellRE,(full,r)=>{if(r!==ref)return full;found=true;return serialized});if(!found)throw new Error('更新対象セルを特定できません。')}
  else{
    const rowRE=/<(?:[\w]+:)?row\b[^>]*\br="(\d+)"[^>]*>[\s\S]*?<\/(?:[\w]+:)?row>/g;let found=false;
    updated=raw.replace(rowRE,(full,r)=>{if(r!==row.getAttribute('r'))return full;found=true;let inserted=false;let result=full.replace(cellRE,(c,cr)=>{if(!inserted&&cellColumn(cr)>cellColumn(ref)){inserted=true;return serialized+c}return c});return inserted?result:result.replace(/<\/(?:[\w]+:)?row>$/,serialized+'$&')});
    if(!found)throw new Error('更新対象行を特定できません。');
  }
  parseXml(updated);return {blob:zip.replace(sheetPath,utf8Encoder.encode(updated)),sheetPath,cell:ref};
}

function imageEditorSection(screen){return `<section class="image-registration"><h3>${screen.imageMissing?'画像を登録':'登録画像'}</h3><p>${screen.imageMissing?'screenshotsフォルダから画像を選び、ExcelとHTMLに保存できます。':esc(screen.imageFile||'')}</p><button id="chooseScreenImage" type="button">${screen.imageMissing?'画像を選んで登録':'画像を変更'}</button> <button id="editCurrentScreen" type="button" data-screen-id="${esc(screen.id)}">画面情報を編集</button></section>`}
function editorMessage(text,error=false){$('imageEditorStatus').textContent=text;$('imageEditorStatus').classList.toggle('error',error)}
function editorSupported(){return localSaveAvailable()||!!(window.showDirectoryPicker&&window.DecompressionStream&&crypto.subtle&&app.editor)}
// 生成時に記録された相対パスだけを使い、親フォルダへの脱出を防ぐ。
function pathSegments(path){const parts=String(path).replaceAll('\\','/').split('/');if(!parts.length||parts.some(p=>!p||p==='.'||p==='..'||p.includes(':')))throw new Error('保存先のパスが不正です。');return parts}
function localFileError(error,path){
  let message=error.message;
  if(error.name==='NotFoundError')message=`次のファイルまたはフォルダが見つかりません：${path}`;
  else if(error.name==='NotAllowedError'||error.name==='SecurityError')message=`アクセスできません：${path}。作業フォルダを選び直し、ブラウザの確認画面で許可してください。`;
  else if(error.name==='TypeMismatchError')message=`ファイルとフォルダの種類が想定と異なります：${path}`;
  else if(/Name is not allowed/i.test(error.message))message=`ブラウザがこのファイル名を許可していません：${path}`;
  const result=new Error(message);result.name=error.name;return result;
}
async function directoryAt(root,path,create=false){let dir=root;const walked=[root.name||'選択したフォルダ'];for(const part of pathSegments(path)){walked.push(part);try{dir=await dir.getDirectoryHandle(part,{create})}catch(e){throw localFileError(e,walked.join('/'))}}return dir}
async function fileAt(root,path,create=false){const parts=pathSegments(path),name=parts.pop();let dir=parts.length?await directoryAt(root,parts.join('/'),create):root;try{return await dir.getFileHandle(name,{create})}catch(e){throw localFileError(e,[root.name||'選択したフォルダ',...parts,name].join('/'))}}
async function fileBytes(handle){return new Uint8Array(await (await handle.getFile()).arrayBuffer())}
async function writeFile(handle,data){const stream=await handle.createWritable();try{await stream.write(data);await stream.close()}catch(e){try{await stream.abort()}catch{}throw e}}
function fileAsDataUrl(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(new Error('画像を読み込めません。'));reader.readAsDataURL(file)})}
// HTML生成後に台帳が変わっていたら、古いHTMLからの保存を止める。
async function assertWorkbookCurrent(root){const bytes=await fileBytes(await fileAt(root,app.editor.excel));if(await sha256(bytes)!==app.editor.workbookHash)throw new Error('ExcelがこのHTMLの生成後に変更されています。run_generate.batで再生成して、HTMLを開き直してください。');return bytes}
// 利用者が選んだのがscreenshots単体ではなく、inputとoutputの親フォルダか確かめる。
async function connectImageFolder(){
  if(!editorSupported())throw new Error('画像の保存にはEdgeまたはChromeで、このツールのフォルダ内に生成したHTMLを開いてください。');
  const root=await window.showDirectoryPicker({id:'screen-transition-project',mode:'readwrite'});
  // 選び直しに失敗した場合、以前のフォルダや画像で保存できないよう状態を消す。
  imageEditor.root=null;imageEditor.files=[];imageEditor.selected=null;
  $('saveScreenImage').disabled=true;$('imageFileChoice').disabled=true;
  $('imageFileChoice').innerHTML='<option value="">作業フォルダを選択してください</option>';$('imageChoicePreview').hidden=true;
  $('imageFolderName').textContent=`選択したフォルダ：${root.name||'（名前なし）'}（確認中）`;
  try{
    await assertWorkbookCurrent(root);
    await fileAt(root,app.editor.html);await directoryAt(root,app.editor.screenshots);
  }catch(e){
    $('imageFolderName').textContent=`選択したフォルダ：${root.name||'（名前なし）'}（未接続）`;
    if(e.name==='NotFoundError'||e.name==='TypeMismatchError'){
      const imageFolder=pathSegments(app.editor.screenshots).at(-1),inputFolder=pathSegments(app.editor.excel)[0],outputFolder=pathSegments(app.editor.html)[0];
      const nested=[imageFolder,inputFolder,outputFolder].includes(root.name);
      throw new Error(`${e.message}\n${nested?`「${root.name}」の中ではなく、`:'選択したフォルダ内に必要なファイルがありません。\n'}「${inputFolder}」と「${outputFolder}」が並んで入っている親フォルダを選んでください。\n例：${app.editor.projectName||'このツールのフォルダ'}\n正しい親フォルダを選択済みの場合は、ファイルを移動・改名していないか確認してください。`);
    }
    throw e;
  }
  imageEditor.root=root;$('imageFolderName').textContent=root.name+' / '+app.editor.screenshots;
  await loadImageChoices();
}
// screenshots内の画像だけを一覧に出す。
async function loadImageChoices(){
  imageEditor.files=[];imageEditor.selected=null;$('saveScreenImage').disabled=true;
  if(localSaveAvailable()){
    const response=await fetch('/api/images',{headers:{'X-Viewer-Token':localSaveToken()},cache:'no-store'});
    const result=await response.json();if(!response.ok)throw new Error(result.error||'画像一覧を読み込めません。');
    imageEditor.files=result.images.map(name=>({name}));
  }else{
    const dir=await directoryAt(imageEditor.root,app.editor.screenshots);
    for await(const [name,handle] of dir.entries())if(handle.kind==='file'&&/\.(png|jpe?g|webp|gif|bmp)$/i.test(name))imageEditor.files.push({name,handle});
  }
  imageEditor.files.sort((a,b)=>a.name.localeCompare(b.name,'ja'));
  $('imageFileChoice').innerHTML='<option value="">画像ファイルを選択</option>'+imageEditor.files.map((f,i)=>`<option value="${i}">${esc(f.name)}</option>`).join('');
  $('imageFileChoice').disabled=false;$('imageChoicePreview').hidden=true;
  editorMessage(imageEditor.files.length?`${imageEditor.files.length}件の画像があります。ファイルを選んでプレビューを確認してください。`:'画像がありません。screenshotsフォルダに画像を入れ、「一覧を更新」を押してください。');
}
// ファイルがまだ存在し、画像として開けることを確認してから保存ボタンを有効にする。
async function previewSelectedImage(){
  $('saveScreenImage').disabled=true;imageEditor.selected=null;const value=$('imageFileChoice').value;
  if(imageEditor.previewUrl){URL.revokeObjectURL(imageEditor.previewUrl);imageEditor.previewUrl=null}
  $('imageChoicePreview').hidden=true;if(value==='')return;
  const item=imageEditor.files[Number(value)];if(!item)return;
  let file;
  if(localSaveAvailable()){
    const response=await fetch('/api/image?name='+encodeURIComponent(item.name),{headers:{'X-Viewer-Token':localSaveToken()},cache:'no-store'});
    if(!response.ok)throw new Error(`画像「${item.name}」を読み込めません。一覧を更新して選び直してください。`);
    file=await response.blob();
  }else try{file=await item.handle.getFile()}catch(e){if(e.name==='NotFoundError')throw new Error(`画像「${item.name}」が見つかりません。移動・削除・改名されている可能性があります。「一覧を更新」を押して選び直してください。`);throw localFileError(e,item.name)}
  if(file.size>30*1024*1024)throw new Error('画像は30MB以下にしてください。');
  const url=URL.createObjectURL(file);imageEditor.previewUrl=url;
  const img=$('imageChoicePreview');img.src=url;
  try{await img.decode()}catch{throw new Error('このファイルを画像として読み込めません。別の画像を選んでください。')}
  if($('imageFileChoice').value!==value)return;
  imageEditor.selected={...item,file};img.hidden=false;$('saveScreenImage').disabled=false;
  editorMessage(`${item.name} を「${byId(imageEditor.screenId).name}」に登録します。`);
}
async function openImageRegistration(id){
  imageEditor.screenId=id;$('imageEditorTitle').textContent=`画像登録：${id} ${byId(id).name}`;
  $('imageFolderGuide').textContent=app.editor?`選ぶフォルダ：${app.editor.projectName||'このツールのフォルダ'}\n  ├ ${app.editor.excel}\n  ├ ${app.editor.screenshots}/\n  └ ${app.editor.html}`:'';
  $('imageEditorDialog').showModal();
  if(localSaveAvailable()){
    $('imageEditorIntro').textContent='screenshotsフォルダ内の画像を選び、「保存」を押してください。ExcelとHTMLへ直接反映します。';
    $('connectImageFolder').hidden=true;$('imageFolderGuide').hidden=true;$('imageFolderName').hidden=true;
    $('saveScreenImage').textContent='保存';
    try{await loadImageChoices()}catch(e){editorMessage(e.message,true)}
    return;
  }
  if(imageEditor.pending){editorMessage('Excelは保存済みです。HTMLへの反映を再試行してください。',true);$('retryHtmlSave').hidden=false;return}
  $('retryHtmlSave').hidden=true;
  if(!editorSupported()){editorMessage('保存にはEdge／Chromeを使用し、元の作業フォルダから生成したHTMLを開いてください。',true);return}
  if(imageEditor.root){try{await loadImageChoices()}catch(e){editorMessage(e.message,true)}}
  else editorMessage('「作業フォルダを選択」で、inputとoutputが入ったフォルダを選んでください。');
}
// 元HTMLの埋め込みデータ部分だけを、新しい画像情報に置き換える。
function serializedViewer(html,data){
  const marker='<script type="application/json" id="appData">',start=html.indexOf(marker),end=html.indexOf('</scr'+'ipt>',start);
  if(start<0||end<0)throw new Error('保存先のHTML形式が異なります。再生成してください。');
  const payload=JSON.stringify(data).replaceAll('</','<\\/');return html.slice(0,start+marker.length)+payload+html.slice(end);
}
// ExcelとHTMLを変更する前に、両方の状態と保存内容を確定する。
async function prepareImageSave(){
  if(!imageEditor.root||!imageEditor.selected)throw new Error('作業フォルダと画像を選択してください。');
  if(recordEditor.busy)throw new Error('画面・遷移の保存が完了してから画像を登録してください。');
  const root=imageEditor.root,config=app.editor;
  // Excelの「~$」ロックファイルは参照しない。ブラウザがその名前を拒否するため。
  // 使用中のExcelかどうかは、実ファイルの書き込み時のエラーで判断する。
  const original=await assertWorkbookCurrent(root),excelHandle=await fileAt(root,config.excel),htmlHandle=await fileAt(root,config.html);
  const originalHtml=await (await htmlHandle.getFile()).text();
  const loaded=new DOMParser().parseFromString(originalHtml,'text/html').getElementById('appData');
  if(!loaded||JSON.stringify(JSON.parse(loaded.textContent))!==JSON.stringify(app))throw new Error('保存先のHTMLが更新されています。HTMLを開き直してください。');
  const selected=imageEditor.selected,screen=byId(imageEditor.screenId),latest=await selected.handle.getFile();
  if(latest.size!==selected.file.size||latest.lastModified!==selected.file.lastModified)throw new Error('選択した画像が変更されました。もう一度画像を選択してください。');
  const patch=await patchWorkbookImage(original,screen.id,selected.name,screen.imageFile),bytes=new Uint8Array(await patch.blob.arrayBuffer());
  const data=structuredClone(app),target=data.screens.find(x=>x.id===screen.id);
  target.image=await fileAsDataUrl(latest);target.imageFile=selected.name;target.imageMissing=false;
  data.warnings=data.screens.filter(x=>x.imageMissing).map(x=>`画像なし: ${x.id} ${x.imageFile||'(未指定)'}`);
  data.editor.workbookHash=await sha256(bytes);
  return {root,excelHandle,htmlHandle,original,originalHtml,bytes,data,html:serializedViewer(originalHtml,data),screenId:screen.id};
}
function setImageSaving(busy){imageEditor.busy=busy;for(const id of ['connectImageFolder','refreshImageChoices','imageFileChoice','saveScreenImage'])$(id).disabled=busy||!!imageEditor.pending;for(const id of ['closeImageEditor','retryHtmlSave'])$(id).disabled=busy;if(!busy)$('saveScreenImage').disabled=!imageEditor.selected||!!imageEditor.pending}
// 保存した画像を、画面一覧・遷移図・詳細パネルへすぐ反映する。
function applyImageSave(saved){
  // 各表示が同じ画面オブジェクトを参照しているため、その場で内容を更新する。
  saved.data.screens.forEach(n=>Object.assign(byId(n.id),n));app.warnings=saved.data.warnings;app.editor=saved.data.editor;
  $('warningCount').textContent=app.warnings.length;$('warnings').hidden=!app.warnings.length;$('warnings').textContent=app.warnings.join(' / ');
  const scale=diagramScale,left=$('flow').scrollLeft,top=$('flow').scrollTop;
  renderScreens();renderFlow(diagramCategory);setDiagramScale(scale,false);$('flow').scrollTo(left,top);openDetail(saved.screenId);
}
// 先に両方のバックアップを作り、その後でExcelとHTMLを保存する。
async function saveRegisteredImage(){
  if(localSaveAvailable()){
    if(imageEditor.busy||!imageEditor.selected)return;
    if(recordEditor.busy){editorMessage('画面・遷移の保存が完了してから画像を登録してください。',true);return}
    setImageSaving(true);editorMessage('ExcelとHTMLを保存しています…');
    try{
      const screen=byId(imageEditor.screenId),original=await localWorkbookBytes();
      const patched=await patchWorkbookImage(original,screen.id,imageEditor.selected.name,screen.imageFile);
      const data=await localCommitWorkbook(new Uint8Array(await patched.blob.arrayBuffer()));
      applyImageSave({data,screenId:screen.id});imageEditor.selected=null;
      editorMessage('ExcelとHTMLに保存しました。');
    }catch(e){editorMessage('保存できませんでした。 '+e.message,true)}finally{setImageSaving(false)}
    return;
  }
  if(imageEditor.busy||imageEditor.pending)return;
  setImageSaving(true);editorMessage('ExcelとHTMLを保存しています…');let excelStream=null,htmlStream=null,excelSaved=false,saved=null,step='登録内容の確認';
  try{
    saved=await prepareImageSave();
    // 元ファイルを開いて書き込む前に、復旧用のコピーを残す。
    step='バックアップフォルダの準備';
    const backupDir=await directoryAt(imageEditor.root,'backups',true);
    const stamp=new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomUUID().slice(0,8);
    step='Excelのバックアップ';
    await writeFile(await fileAt(backupDir,stamp+'-'+pathSegments(app.editor.excel).at(-1),true),saved.original);
    step='HTMLのバックアップ';
    await writeFile(await fileAt(backupDir,stamp+'-viewer.html',true),saved.originalHtml);
    step='保存直前の変更確認';
    await assertWorkbookCurrent(saved.root);
    if(await(await saved.htmlHandle.getFile()).text()!==saved.originalHtml)throw new Error('保存先のHTMLが更新されています。開き直してください。');
    // Excel確定後にHTMLだけ失敗するケースを減らすため、両方の書き込み口を先に開く。
    step='Excelの書き込み準備';excelStream=await saved.excelHandle.createWritable();
    step='HTMLの書き込み準備';htmlStream=await saved.htmlHandle.createWritable();
    step='Excelの書き込み';await excelStream.write(saved.bytes);
    step='HTMLの書き込み';await htmlStream.write(saved.html);
    step='Excelの保存確定';await excelStream.close();excelStream=null;excelSaved=true;
    step='HTMLの保存確定';await htmlStream.close();htmlStream=null;
    applyImageSave(saved);imageEditor.selected=null;editorMessage('保存しました。Excelの「画像ファイル」とHTMLに反映しました。保存前のファイルはbackupsフォルダにあります。');
  }catch(e){
    if(excelSaved){imageEditor.pending=saved;$('retryHtmlSave').hidden=false;editorMessage('Excelは保存済みですが、HTMLの保存に失敗しました。「HTML保存を再試行」を押してください。 '+e.message,true)}
    else {
      let hint='';
      if(e.name==='NotAllowedError'||e.name==='SecurityError')hint='\nブラウザで作業フォルダへの書き込みを許可してください。';
      else if(e.name==='NoModificationAllowedError'||e.name==='InvalidStateError')hint='\n他のアプリで対象ファイルを使用している場合は、閉じてから再試行してください。';
      editorMessage(`保存できませんでした（${step}）。\n${e.message}${hint}`,true);
    }
  }finally{for(const stream of [excelStream,htmlStream])if(stream)try{await stream.abort()}catch{}setImageSaving(false)}
}
// Excelだけ保存できた場合、重複更新せずHTMLへの反映だけを再試行する。
async function retryImageHtmlSave(){
  const saved=imageEditor.pending;if(!saved||imageEditor.busy)return;setImageSaving(true);
  try{if(await sha256(await fileBytes(saved.excelHandle))!==saved.data.editor.workbookHash)throw new Error('Excelがさらに変更されました。run_generate.batでHTMLを再生成してください。');const current=await(await saved.htmlHandle.getFile()).text();if(current!==saved.originalHtml&&current!==saved.html)throw new Error('HTMLが別の操作で変更されました。run_generate.batで再生成してください。');await writeFile(saved.htmlHandle,saved.html);applyImageSave(saved);imageEditor.pending=null;imageEditor.selected=null;$('retryHtmlSave').hidden=true;editorMessage('ExcelとHTMLの保存が完了しました。')}
  catch(e){editorMessage('HTMLを保存できませんでした。 '+e.message,true)}finally{setImageSaving(false)}
}
// 画像登録画面のボタンと、画面を閉じるときの注意を設定する。
function initImageEditor(){
  const run=fn=>async()=>{try{await fn()}catch(e){editorMessage(e.name==='AbortError'?'選択をキャンセルしました。':e.message,true)}};
  $('connectImageFolder').onclick=run(connectImageFolder);$('refreshImageChoices').onclick=run(async()=>{if(!localSaveAvailable()&&!imageEditor.root)throw new Error('先に作業フォルダを選択してください。');await loadImageChoices()});
  $('imageFileChoice').onchange=run(previewSelectedImage);$('saveScreenImage').onclick=saveRegisteredImage;$('retryHtmlSave').onclick=retryImageHtmlSave;
  $('closeImageEditor').onclick=()=>$('imageEditorDialog').close();$('imageEditorDialog').addEventListener('cancel',e=>{if(imageEditor.busy)e.preventDefault()});
  window.addEventListener('beforeunload',e=>{if(imageEditor.busy||imageEditor.pending){e.preventDefault();e.returnValue=''}});
}
