// ブラウザだけでExcelを出力する。下地となるxlsxは生成時にHTMLへ埋め込まれる。
// 画面画像・条件欄・矢印は個別のExcel図形として追加する。
const excelDiagramBase='__EXCEL_DIAGRAM_BASE__';
const excelMime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const drawingNS='http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing';
const artNS='http://schemas.openxmlformats.org/drawingml/2006/main';
const relationNS='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const xmlEscape=v=>String(v??'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
const emu=px=>Math.round(px*9525);
// xlsxは複数のXMLと画像をまとめたZIP。各ファイルの長さとCRCを記録して組み立てる。
function zipExcelEntries(entries){
  const local=[],central=[];let offset=0;
  if(entries.size>65534)throw new Error('Excelに出力する画像の数が多すぎます。機能別に出力してください。');
  for(const [name,value] of entries){
    const bytes=typeof value==='string'?utf8Encoder.encode(value):value,n=utf8Encoder.encode(name),crc=crc32(bytes);
    const header=new Uint8Array(30+n.length),h=new DataView(header.buffer);
    h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint16(12,33,true);
    h.setUint32(14,crc,true);h.setUint32(18,bytes.length,true);h.setUint32(22,bytes.length,true);h.setUint16(26,n.length,true);header.set(n,30);
    const c=new Uint8Array(46+n.length),cv=new DataView(c.buffer);
    cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint16(14,33,true);
    cv.setUint32(16,crc,true);cv.setUint32(20,bytes.length,true);cv.setUint32(24,bytes.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);c.set(n,46);
    local.push(header,bytes);central.push(c);offset+=header.length+bytes.length;
    if(offset>512*1024*1024)throw new Error('Excelが大きすぎます。機能別に出力してください。');
  }
  const end=new Uint8Array(22),e=new DataView(end.buffer);e.setUint32(0,0x06054b50,true);e.setUint16(8,entries.size,true);e.setUint16(10,entries.size,true);e.setUint32(12,central.reduce((s,c)=>s+c.length,0),true);e.setUint32(16,offset,true);
  return new Blob([...local,...central,end],{type:excelMime});
}
// 図形の位置は画面上のピクセルで計算し、Excelのセル位置とEMU単位に変換する。
function excelAnchor(x,y,w,h,content){return `<xdr:oneCellAnchor><xdr:from><xdr:col>${Math.floor(x/20)}</xdr:col><xdr:colOff>${emu(x%20)}</xdr:colOff><xdr:row>${Math.floor(y/20)}</xdr:row><xdr:rowOff>${emu(y%20)}</xdr:rowOff></xdr:from><xdr:ext cx="${Math.max(1,emu(w))}" cy="${Math.max(1,emu(h))}"/>${content}<xdr:clientData/></xdr:oneCellAnchor>`}
function excelTransform(x,y,w,h){return `<a:xfrm><a:off x="${emu(x)}" y="${emu(y)}"/><a:ext cx="${Math.max(1,emu(w))}" cy="${Math.max(1,emu(h))}"/></a:xfrm>`}
// 画面カードや条件欄を、後から文字を直せるテキスト図形として作る。
function excelTextShape(id,name,x,y,w,h,lines,{fill='FFFFFF',line='C5D8CE',color='20342D',bold=false,size=10,dashed=false}={}){
  const text=lines.map(t=>`<a:p><a:pPr algn="ctr"/><a:r><a:rPr lang="ja-JP" sz="${size*100}" b="${bold?1:0}"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:latin typeface="Arial"/><a:ea typeface="Meiryo"/></a:rPr><a:t xml:space="preserve">${xmlEscape(t)}</a:t></a:r><a:endParaRPr lang="ja-JP" sz="${size*100}"/></a:p>`).join('');
  return excelAnchor(x,y,w,h,`<xdr:sp><xdr:nvSpPr><xdr:cNvPr id="${id}" name="${xmlEscape(name)}"/><xdr:cNvSpPr txBox="1"/></xdr:nvSpPr><xdr:spPr>${excelTransform(x,y,w,h)}<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="${fill}"/></a:solidFill><a:ln w="9525"><a:solidFill><a:srgbClr val="${line}"/></a:solidFill>${dashed?'<a:prstDash val="dash"/>':''}</a:ln></xdr:spPr><xdr:txBody><a:bodyPr wrap="square" lIns="47625" rIns="47625" tIns="47625" bIns="47625" anchor="ctr"><a:noAutofit/></a:bodyPr><a:lstStyle/>${text||'<a:p/>'}</xdr:txBody></xdr:sp>`);
}
// 条件文は省略せず、図形の幅に収まる位置で改行する。
function wrapExcelText(text,width=202,size=10){
  const context=document.createElement('canvas').getContext('2d');context.font=`${size*96/72}px Meiryo,Arial`;
  const lines=[];
  for(const paragraph of String(text??'').split(/\r?\n/)){let line='';for(const char of paragraph){if(line&&context.measureText(line+char).width>width){lines.push(line);line=''}line+=char}lines.push(line)}
  return lines;
}
// 画像をExcelへ内蔵できるPNGに変える。大きな元画像は長辺900pxまで縮小する。
async function excelImage(screen){
  const img=new Image();img.src=screen.image;
  try{await img.decode()}catch{throw new Error(`画像を読み込めません：${screen.id} ${screen.name}。画像を登録し直してからExcel出力してください。`)}
  const scale=Math.min(1,900/Math.max(img.naturalWidth,img.naturalHeight)),canvas=document.createElement('canvas');
  canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
  const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
  let blob;try{blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'))}catch{throw new Error(`画像 ${screen.id} をExcelに埋め込めません。設定のimage_modeをembedにしてHTMLを再生成してください。`)}
  if(!blob)throw new Error(`画像 ${screen.id} の変換に失敗しました。`);
  return {bytes:new Uint8Array(await blob.arrayBuffer()),width:canvas.width,height:canvas.height};
}
// 遷移の折れ線を直線の図形に分け、終点に矢印を置く。
function excelRouteSegments(nextId,route){
  const color=route.t.retiredRelease?'9EAAA3':route.back?'97613A':'23795F',shapes=[];
  function shape(x,y,w,h,geometry,name){
    return excelAnchor(x,y,w,h,`<xdr:sp><xdr:nvSpPr><xdr:cNvPr id="${nextId()}" name="${xmlEscape(name)}"/><xdr:cNvSpPr/></xdr:nvSpPr><xdr:spPr>${excelTransform(x,y,w,h)}<a:prstGeom prst="${geometry}"><a:avLst/></a:prstGeom>${geometry==='line'?'<a:noFill/>':`<a:solidFill><a:srgbClr val="${color}"/></a:solidFill>`}<a:ln w="14288"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill>${route.back&&geometry==='line'?'<a:prstDash val="dash"/>':''}</a:ln></xdr:spPr></xdr:sp>`);
  }
  route.points.slice(1).forEach((q,i)=>{const p=route.points[i];if(p[0]===q[0]&&p[1]===q[1])return;shapes.push(shape(Math.min(p[0],q[0]),Math.min(p[1],q[1]),Math.max(.01,Math.abs(q[0]-p[0])),Math.max(.01,Math.abs(q[1]-p[1])),'line',`${route.t.id} 経路 ${i+1}`))});
  const end=route.points.at(-1);shapes.push(shape(end[0]-12,end[1]-5,12,10,'rightArrow',`${route.t.id} 遷移先`));return shapes;
}
async function buildExcelDiagram(model,category){
  // Excelでは条件全文を表示するため、HTMLより広い列間隔で位置を計算し直す。
  model=layoutDiagram(model.nodes,model.edges,340);
  const scaffold=new WorkbookZip(Uint8Array.from(atob(excelDiagramBase),c=>c.charCodeAt(0))),entries=new Map();
  for(const e of scaffold.entries)entries.set(e.name,await scaffold.read(e.name));
  let id=1;const drawings=[],relationships=[],topOffset=110,labelBoxes=[];
  const routes=model.routes.map(r=>({...r,points:r.points.map(p=>[p[0],p[1]+topOffset]),ly:r.ly+topOffset}));
  // 条件欄の横位置は必ず画面列の間へ寄せる。戻る矢印も画面に被せない。
  const ranks=[...new Set([...model.positions.values()].map(p=>p.rank))].sort((a,b)=>a-b);
  const laneCenters=ranks.slice(0,-1).map(rank=>50+rank*(CARD_W+340)+CARD_W+170);
  if(!laneCenters.length&&ranks.length)laneCenters.push(50+CARD_W+170);
  // 条件全文に必要な高さを確保し、同じ場所の条件欄を縦にずらす。
  routes.forEach(r=>{
    r.lx=laneCenters.reduce((best,x)=>Math.abs(x-r.lx)<Math.abs(best-r.lx)?x:best,laneCenters[0]??r.lx);
    const text=[r.t.action||'操作未記入',r.t.condition||'条件未記入',`対象OS：${r.t.os||'未記入'}`,r.t.retiredRelease?`廃止：${r.t.retiredRelease}`:''].filter(Boolean).join('\n');
    const lines=wrapExcelText(text),box={x:r.lx-108,y:r.ly,w:216,h:Math.max(84,lines.length*19+12),lines,r};
    let conflict;while((conflict=labelBoxes.find(b=>box.x<b.x+b.w+6&&box.x+box.w+6>b.x&&box.y<b.y+b.h+16&&box.y+box.h+16>b.y)))box.y=conflict.y+conflict.h+16;
    const center=box.y+box.h/2;r.points[2][1]=center;r.points[3][1]=center;labelBoxes.push(box);
  });
  // 矢印を先に置き、その上に画面カードと条件欄を重ねる。
  routes.forEach(r=>drawings.push(...excelRouteSegments(()=>id++,r)));
  let imageIndex=0;
  for(const screen of model.nodes){
    const p=model.positions.get(screen.id),x=p.x,y=p.y+topOffset;
    drawings.push(excelTextShape(id++,`画面 ${screen.id}`,x,y,CARD_W,CARD_H,[],{fill:'F3F7F4',line:'83A995',dashed:category!==null&&screen.category!==category}).replace('<a:solidFill><a:srgbClr val="F3F7F4"/></a:solidFill>','<a:noFill/>'));
    drawings.push(excelTextShape(id++,`ID ${screen.id}`,x+1,y+1,CARD_W-2,26,[screen.id],{fill:'E9F1EC',line:'E9F1EC',color:'23795F',bold:true}));
    const image=await excelImage(screen),ratio=Math.min((CARD_W-16)/image.width,170/image.height),w=image.width*ratio,h=image.height*ratio,ix=x+(CARD_W-w)/2,iy=y+32+(170-h)/2;
    const rel='image'+(++imageIndex),name=`image${imageIndex}.png`;
    entries.set('xl/media/'+name,image.bytes);relationships.push(`<Relationship Id="${rel}" Type="${relationNS}/image" Target="../media/${name}"/>`);
    drawings.push(excelAnchor(ix,iy,w,h,`<xdr:pic><xdr:nvPicPr><xdr:cNvPr id="${id++}" name="${xmlEscape('画像 '+screen.id)}" descr="${xmlEscape(screen.name)}"/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr><xdr:blipFill><a:blip r:embed="${rel}"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr>${excelTransform(ix,iy,w,h)}<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic>`));
    const lines=wrapExcelText(screen.name,CARD_W-12,10);
    drawings.push(excelTextShape(id++,`画面名 ${screen.id}`,x+1,y+208,CARD_W-2,Math.max(55,lines.length*19+12),lines,{fill:'F3F7F4',line:'F3F7F4',bold:true}));
  }
  for(const b of labelBoxes)drawings.push(excelTextShape(id++,`条件 ${b.r.t.id}`,b.x,b.y,b.w,b.h,b.lines,{fill:b.r.back?'FFF9F1':'FFFFFF',color:b.r.back?'97613A':'20342D',line:b.r.back?'D7BEA4':'C5D8CE'}));
  // 配置した図形が切れないよう、印刷範囲を一番右・下の条件欄まで広げる。
  const width=Math.ceil(Math.max(model.width,...labelBoxes.map(b=>b.x+b.w+50))),height=Math.ceil(Math.max(model.height+topOffset,...labelBoxes.map(b=>b.y+b.h+50))),cols=Math.ceil(width/20),rows=Math.ceil(height/20);
  function colName(n){let s='';for(;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s}
  const end=colName(cols)+rows,inline=(ref,text,style=1)=>`<x:c r="${ref}" s="${style}" t="inlineStr"><x:is><x:t xml:space="preserve">${xmlEscape(text)}</x:t></x:is></x:c>`;
  const title=`${s.system_name} 画面遷移図 / ${category??'全体図'}`;
  // ワークシートの見出しと図形への参照を追加する。
  entries.set('xl/worksheets/sheet1.xml',`<?xml version="1.0" encoding="UTF-8"?><x:worksheet xmlns:x="${xmlNS}" xmlns:r="${relationNS}"><x:sheetPr><x:tabColor rgb="FF23795F"/></x:sheetPr><x:dimension ref="A1:${end}"/><x:sheetViews><x:sheetView showGridLines="0" zoomScale="75" workbookViewId="0"/></x:sheetViews><x:sheetFormatPr defaultRowHeight="15"/><x:cols><x:col min="1" max="${cols}" width="2.14" customWidth="1"/></x:cols><x:sheetData><x:row r="2">${inline('B2',title,2)}</x:row><x:row r="4">${inline('B4',`リリース ${s.current_release}　${model.nodes.length}画面・${model.edges.length}遷移　緑：進む　茶色の破線：戻る・循環　灰色：廃止記録あり`)}</x:row><x:row r="5">${inline('B5','画像・矢印・条件文は個別に編集できます。出力後の編集は元の台帳・HTMLには反映されません。')}</x:row></x:sheetData><x:pageMargins left="0.3" right="0.3" top="0.4" bottom="0.4" header="0.2" footer="0.2"/><x:pageSetup orientation="landscape" paperSize="8" scale="75"/><x:drawing r:id="diagram"/></x:worksheet>`);
  entries.set('xl/worksheets/_rels/sheet1.xml.rels',`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="diagram" Type="${relationNS}/drawing" Target="../drawings/drawing1.xml"/></Relationships>`);
  entries.set('xl/drawings/drawing1.xml',`<?xml version="1.0" encoding="UTF-8"?><xdr:wsDr xmlns:xdr="${drawingNS}" xmlns:a="${artNS}" xmlns:r="${relationNS}">${drawings.join('')}</xdr:wsDr>`);
  entries.set('xl/drawings/_rels/drawing1.xml.rels',`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relationships.join('')}</Relationships>`);
  // xlsx内部の目次へ、追加した画像と図形ファイルの種類を登録する。
  const types=parseXml(utf8Decoder.decode(entries.get('[Content_Types].xml'))),tns=types.documentElement.namespaceURI;
  const imageType=types.createElementNS(tns,'Default');imageType.setAttribute('Extension','png');imageType.setAttribute('ContentType','image/png');types.documentElement.append(imageType);
  const drawingType=types.createElementNS(tns,'Override');drawingType.setAttribute('PartName','/xl/drawings/drawing1.xml');drawingType.setAttribute('ContentType','application/vnd.openxmlformats-officedocument.drawing+xml');types.documentElement.append(drawingType);
  entries.set('[Content_Types].xml',new XMLSerializer().serializeToString(types));
  const workbook=parseXml(utf8Decoder.decode(entries.get('xl/workbook.xml'))),sheet=xmlElements(workbook,'sheet')[0];
  const names=workbook.createElementNS(xmlNS,'definedNames'),area=workbook.createElementNS(xmlNS,'definedName');area.setAttribute('name','_xlnm.Print_Area');area.setAttribute('localSheetId','0');area.textContent=`'${sheet.getAttribute('name')}'!$A$1:$${colName(cols)}$${rows}`;names.append(area);
  const calc=xmlElements(workbook,'calcPr')[0];workbook.documentElement.insertBefore(names,calc||null);entries.set('xl/workbook.xml',new XMLSerializer().serializeToString(workbook));
  return zipExcelEntries(entries);
}
// 「Excel出力」ボタンから呼ばれ、表示中の全体図または機能別の図を保存する。
async function exportDiagramExcel(){
  const button=$('exportDiagramExcel'),status=$('excelExportStatus');if(button.disabled)return;
  button.disabled=true;status.hidden=false;status.textContent='画面画像と矢印をExcelに配置しています…';
  try{
    const category=diagramCategory,model=structuredClone(diagramModel);if(!model?.nodes.length)throw new Error('出力する画面がありません。');
    const blob=await buildExcelDiagram(model,category),url=URL.createObjectURL(blob),link=document.createElement('a');
    link.href=url;link.download=`画面遷移図_${category??'全体図'}.xlsx`.replace(/[\\/:*?"<>|]/g,'_');document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
    status.textContent=`Excelを出力しました（${model.nodes.length}画面・${model.edges.length}遷移）。ブラウザのダウンロード先を確認してください。`;
  }catch(e){status.textContent='Excelを出力できませんでした。 '+e.message}finally{button.disabled=false}
}
