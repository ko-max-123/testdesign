// generate.pyが完成HTMLへ埋め込む。図の表示にサーバーや外部ライブラリは不要。
let diagramCategory = null, diagramScale = .8, diagramModel = null;
// 画面カードの寸法と、通常のHTML表示での画面間隔。
const CARD_W = 156, CARD_H = 264, COLUMN_GAP = 254, ROW_GAP = 160;

// 画面を左から右へ並べ、遷移ごとの矢印の折れ線と条件欄の位置を決める。
// columnGapはExcel出力時だけ広げ、長い条件欄が画面画像に重ならないようにする。
function layoutDiagram(nodes, edges, columnGap=COLUMN_GAP) {
  const index = new Map(nodes.map((n,i)=>[n.id,i]));
  const outgoing = new Map(nodes.map(n=>[n.id,[]]));
  const forward = [], feedback = [], state = new Map();
  edges.forEach(t=>outgoing.get(t.from)?.push(t));
  // 戻る遷移・循環だけを配置計算から外す。図にはすべての遷移を残す。
  function visit(id) {
    state.set(id,1);
    for (const t of outgoing.get(id)) {
      if (t.type==='戻る' || t.from===t.to || state.get(t.to)===1) { feedback.push(t); continue; }
      forward.push(t);
      if (!state.has(t.to)) visit(t.to);
    }
    state.set(id,2);
  }
  nodes.forEach(n=>{if(!state.has(n.id))visit(n.id)});
  const rank = new Map(nodes.map(n=>[n.id,0])), indegree = new Map(nodes.map(n=>[n.id,0]));
  const parents = new Map(nodes.map(n=>[n.id,[]]));
  forward.forEach(t=>{indegree.set(t.to,indegree.get(t.to)+1);parents.get(t.to).push(t.from)});
  const queue = nodes.filter(n=>!indegree.get(n.id)).map(n=>n.id);
  for(let i=0;i<queue.length;i++) {
    const id=queue[i];
    forward.filter(t=>t.from===id).forEach(t=>{
      rank.set(t.to,Math.max(rank.get(t.to),rank.get(id)+1));
      indegree.set(t.to,indegree.get(t.to)-1);if(!indegree.get(t.to))queue.push(t.to);
    });
  }
  // 遷移元より遷移先を右の列に置き、同じ列の画面は縦にずらす。
  const columns=[];nodes.forEach(n=>(columns[rank.get(n.id)]??=[]).push(n));
  const positions=new Map(), top=140;
  columns.forEach((column,col)=>{
    const desired=n=>{
      const ys=parents.get(n.id).map(id=>positions.get(id)?.y).filter(y=>y!==undefined);
      return ys.length?ys.reduce((a,b)=>a+b,0)/ys.length:top;
    };
    column.sort((a,b)=>desired(a)-desired(b)||index.get(a.id)-index.get(b.id));
    let bottom=top-ROW_GAP;
    column.forEach(n=>{
      const y=Math.max(top,desired(n),bottom+ROW_GAP);
      positions.set(n.id,{x:50+col*(CARD_W+columnGap),y,rank:col});bottom=y+CARD_H;
    });
  });
  const baseBottom=Math.max(top+CARD_H,...[...positions.values()].map(p=>p.y+CARD_H));
  // 同じ画面に複数の矢印が集まっても見えるよう、接続位置を分散する。
  const routes=[], labelSlots=new Map();
  function port(t,end){
    const id=t[end];
    const peers=edges.filter(e=>e[end]===id), pos=peers.indexOf(t);
    return positions.get(id).y+70+(pos+1)*140/(peers.length+1);
  }
  const extra=forward.filter(t=>rank.get(t.to)>rank.get(t.from)+1);
  forward.forEach(t=>{
    const a=positions.get(t.from),b=positions.get(t.to),sx=a.x+CARD_W,tx=b.x;
    const sy=port(t,'from'),ty=port(t,'to'), mid=sx+columnGap/2;
    let points,lx,ly;
    if(b.rank===a.rank+1){
      // 隣の列へ進む遷移は、列の間に条件欄を置く。
      const slots=labelSlots.get(a.rank)||[];
      ly=sy-42;while(slots.some(y=>Math.abs(y-ly)<100))ly+=100;
      slots.push(ly);labelSlots.set(a.rank,slots);lx=mid;
      points=[[sx,sy],[sx+20,sy],[sx+20,ly+42],[tx-20,ly+42],[tx-20,ty],[tx,ty]];
    }else{
      const y=45+extra.indexOf(t)*100;lx=(sx+tx)/2;ly=-y;
      points=[[sx,sy],[sx+24,sy],[sx+24,ly+42],[tx-24,ly+42],[tx-24,ty],[tx,ty]];
    }
    routes.push({t,points,lx,ly,back:false});
  });
  // 戻る遷移や循環は下側を通し、通常の遷移と見分けられるようにする。
  feedback.forEach((t,i)=>{
    const a=positions.get(t.from),b=positions.get(t.to),y=baseBottom+90+i*100;
    const sx=a.x+CARD_W,tx=b.x,sy=port(t,'from'),ty=port(t,'to');
    const side=24+(i%5)*12;
    const points=[[sx,sy],[sx+side,sy],[sx+side,y],[tx-side,y],[tx-side,ty],[tx,ty]];
    routes.push({t,points,lx:(sx+tx)/2,ly:y-42,back:true});
  });
  const minY=Math.min(0,...routes.map(r=>r.ly-12));
  if(minY<0){positions.forEach(p=>p.y-=minY);routes.forEach(r=>{r.ly-=minY;r.points.forEach(p=>p[1]-=minY)})}
  const width=Math.max(500,...[...positions.values()].map(p=>p.x+CARD_W+70));
  const height=Math.max(500,...[...positions.values()].map(p=>p.y+CARD_H+70),...routes.map(r=>Math.max(r.ly+100,...r.points.map(p=>p[1]+50))));
  return {nodes,edges,positions,routes,width,height};
}

// 「全体図／機能別」ボタンを作り、選択に応じて図を描き直す。
function renderChips(){
  $('chips').innerHTML=[`<button class="chip active" data-all="true">全体図</button>`,...categories.map(x=>`<button class="chip" data-cat="${esc(x)}">${esc(x)}</button>`)].join('');
  $('chips').querySelectorAll('button').forEach(b=>b.onclick=()=>renderFlow(b.dataset.all?null:b.dataset.cat));
  renderFlow(null);
}
// 選択した機能と、その機能につながる別機能の画面まで表示する。
function renderFlow(cat=null){
  diagramCategory=cat;
  document.querySelectorAll('#chips button').forEach(b=>b.classList.toggle('active',cat===null?!!b.dataset.all:b.dataset.cat===cat));
  const local=new Set(screens.filter(n=>cat===null||n.category===cat).map(n=>n.id));
  const edges=transitions.filter(t=>local.has(t.from)||local.has(t.to));
  const visible=new Set(local);edges.forEach(t=>{visible.add(t.from);visible.add(t.to)});
  const nodes=screens.filter(n=>visible.has(n.id));
  diagramModel=layoutDiagram(nodes,edges);
  const m=diagramModel;
  $('diagramCount').textContent=`${cat??'全体図'} · ${nodes.length}画面 / ${edges.length}遷移${cat!==null?'（接続する別機能の画面を含む）':''}`;
  const marker=(id,color)=>`<marker id="${id}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="${color}"/></marker>`;
  const paths=m.routes.map((r,i)=>`<g class="diagram-edge ${r.back?'back-edge':''} ${r.t.retiredRelease?'retired-edge':''}" data-edge="${i}"><path d="${r.points.map((p,j)=>(j?'L':'M')+p.join(' ')).join(' ')}" marker-end="url(#${r.back?'returnArrow':'forwardArrow'})"/><title>${esc(r.t.from+' → '+r.t.to+' : '+r.t.action+' / '+r.t.condition)}</title></g>`).join('');
  const cards=nodes.map(n=>{const p=m.positions.get(n.id);return `<button class="diagram-node ${cat!==null&&!local.has(n.id)?'external-node':''}" data-id="${esc(n.id)}" style="left:${p.x}px;top:${p.y}px"><span class="diagram-node-id">${esc(n.id)} <small>${esc(n.category)}</small></span><img draggable="false" src="${esc(n.image)}" alt="${esc(n.name)}"><strong>${esc(n.name)}</strong></button>`}).join('');
  const labels=m.routes.map((r,i)=>`<button class="edge-label ${r.back?'return-label':''}" data-route="${i}" style="left:${r.lx-108}px;top:${r.ly}px" title="${esc(r.t.action+'\n'+r.t.condition+'\n対象OS：'+(r.t.os||'未記入'))}"><strong>${esc(r.t.action||'操作未記入')}</strong><span>${esc(r.t.condition||'条件未記入')}</span>${r.t.os&&r.t.os!=='共通'?`<em>${esc(r.t.os)}</em>`:''}${r.t.retiredRelease?'<em>廃止記録あり</em>':''}</button>`).join('');
  $('flow').innerHTML=`<div id="diagramSizer"><div id="diagramCanvas" style="width:${m.width}px;height:${m.height}px"><svg class="diagram-lines" width="${m.width}" height="${m.height}" aria-label="画面をつなぐ遷移矢印"><defs>${marker('forwardArrow','#23795f')}${marker('returnArrow','#97613a')}</defs>${paths}</svg>${cards}${labels}</div></div>`;
  $('diagramCanvas').querySelectorAll('.diagram-node').forEach(b=>{
    b.onclick=()=>{highlightDiagram(b.dataset.id);openDetail(b.dataset.id)};
    b.onmouseenter=()=>highlightDiagram(b.dataset.id);b.onmouseleave=()=>highlightDiagram(null);
    b.onfocus=()=>highlightDiagram(b.dataset.id);b.onblur=()=>highlightDiagram(null);
  });
  $('diagramCanvas').querySelectorAll('[data-route]').forEach(b=>b.onclick=()=>openTransition(m.routes[Number(b.dataset.route)].t));
  $('miniMap').innerHTML=`<svg viewBox="0 0 ${m.width} ${m.height}" preserveAspectRatio="none">${m.routes.map(r=>`<path d="${r.points.map((p,j)=>(j?'L':'M')+p.join(' ')).join(' ')}" fill="none" stroke="${r.back?'#c59a79':'#8aa99e'}" stroke-width="8"/>`).join('')}${nodes.map(n=>{const p=m.positions.get(n.id);return `<rect x="${p.x}" y="${p.y}" width="${CARD_W}" height="${CARD_H}" rx="12" fill="#426f60"/>`}).join('')}<rect id="miniViewport" fill="#53af8b33" stroke="#008b5f" stroke-width="14"/></svg>`;
  setDiagramScale(.8,false);$('flow').scrollTo(0,0);updateMiniMap();
}
// 画面に触れたとき、つながる画面と遷移を見つけやすくする。
function highlightDiagram(id){
  if(!diagramModel)return;
  const neighbors=new Set([id]);diagramModel.edges.forEach(t=>{if(t.from===id||t.to===id){neighbors.add(t.from);neighbors.add(t.to)}});
  document.querySelectorAll('.diagram-node').forEach(n=>n.classList.toggle('dimmed',!!id&&!neighbors.has(n.dataset.id)));
  document.querySelectorAll('.diagram-edge').forEach(g=>{const t=diagramModel.routes[Number(g.dataset.edge)].t;g.classList.toggle('dimmed',!!id&&t.from!==id&&t.to!==id)});
  document.querySelectorAll('.edge-label').forEach(b=>{const t=diagramModel.routes[Number(b.dataset.route)].t;b.classList.toggle('dimmed',!!id&&t.from!==id&&t.to!==id)});
}
function openTransition(t){
  $('drawerBody').innerHTML=`<h2 class="detail-title">遷移 ${esc(t.id)}</h2><div class="transition-endpoints"><button class="flow-link" data-id="${esc(t.from)}">${esc(t.from)} ${esc(byId(t.from)?.name)}</button><span>↓</span><button class="flow-link" data-id="${esc(t.to)}">${esc(t.to)} ${esc(byId(t.to)?.name)}</button></div>${transitionLabel(t)}`;
  const edit=document.createElement('button');edit.className='edit-transition';edit.textContent='この遷移を編集';edit.onclick=()=>openRecordEditor('transition',t.id);$('drawerBody').append(edit);
  $('drawerBody').querySelectorAll('[data-id]').forEach(b=>b.onclick=()=>openDetail(b.dataset.id));
  $('drawer').classList.add('open');$('backdrop').classList.add('open');$('drawer').setAttribute('aria-hidden','false');
}
// 拡大率とスクロール位置を合わせて更新する。
function setDiagramScale(value,center=true){
  if(!diagramModel)return;
  const el=$('flow'),old=diagramScale;diagramScale=Math.max(.08,Math.min(2,value));
  const cx=(el.scrollLeft+el.clientWidth/2)/old,cy=(el.scrollTop+el.clientHeight/2)/old;
  $('diagramCanvas').style.transform=`scale(${diagramScale})`;
  $('diagramSizer').style.width=diagramModel.width*diagramScale+'px';$('diagramSizer').style.height=diagramModel.height*diagramScale+'px';
  $('zoomValue').textContent=Math.round(diagramScale*100)+'%';
  if(center)el.scrollTo(cx*diagramScale-el.clientWidth/2,cy*diagramScale-el.clientHeight/2);
  updateMiniMap();
}
function fitDiagram(){if(!diagramModel)return;setDiagramScale(Math.min(($('flow').clientWidth-24)/diagramModel.width,($('flow').clientHeight-24)/diagramModel.height,1),false);$('flow').scrollTo(0,0);updateMiniMap()}
// 小さな全体図の枠を、現在見えている領域へ合わせる。
function updateMiniMap(){
  const rect=$('miniViewport');if(!rect||!diagramModel)return;
  const f=$('flow');rect.setAttribute('x',f.scrollLeft/diagramScale);rect.setAttribute('y',f.scrollTop/diagramScale);rect.setAttribute('width',Math.min(diagramModel.width,f.clientWidth/diagramScale));rect.setAttribute('height',Math.min(diagramModel.height,f.clientHeight/diagramScale));
}
// 拡大・縮小、ドラッグ移動、全体図クリックなどの操作を登録する。
function initDiagramControls(){
  $('zoomIn').onclick=()=>setDiagramScale(diagramScale*1.25);$('zoomOut').onclick=()=>setDiagramScale(diagramScale/1.25);$('zoomReset').onclick=()=>setDiagramScale(1);$('zoomFit').onclick=fitDiagram;
  $('expandDiagram').onclick=()=>{const expanded=$('mapPanel').classList.toggle('expanded');$('expandDiagram').textContent=expanded?'通常表示に戻す':'広く表示';requestAnimationFrame(updateMiniMap)};
  $('flow').addEventListener('scroll',updateMiniMap);window.addEventListener('resize',updateMiniMap);
  $('miniMap').onclick=e=>{if(!diagramModel)return;const r=$('miniMap').getBoundingClientRect();$('flow').scrollTo((e.clientX-r.left)/r.width*diagramModel.width*diagramScale-$('flow').clientWidth/2,(e.clientY-r.top)/r.height*diagramModel.height*diagramScale-$('flow').clientHeight/2)};
  let drag=null;
  $('flow').addEventListener('pointerdown',e=>{if(e.button!==0||e.target.closest('button'))return;drag={x:e.clientX,y:e.clientY,left:$('flow').scrollLeft,top:$('flow').scrollTop};$('flow').setPointerCapture(e.pointerId);$('flow').classList.add('dragging')});
  $('flow').addEventListener('pointermove',e=>{if(drag)$('flow').scrollTo(drag.left+drag.x-e.clientX,drag.top+drag.y-e.clientY)});
  const end=()=>{drag=null;$('flow').classList.remove('dragging')};$('flow').addEventListener('pointerup',end);$('flow').addEventListener('pointercancel',end);
  $('flow').addEventListener('wheel',e=>{if(e.ctrlKey||e.metaKey){e.preventDefault();setDiagramScale(diagramScale*(e.deltaY<0?1.12:1/1.12))}},{passive:false});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('mapPanel').classList.remove('expanded');$('expandDiagram').textContent='広く表示'}});
}
