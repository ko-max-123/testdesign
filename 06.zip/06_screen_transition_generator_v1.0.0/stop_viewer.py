#!/usr/bin/env python3
"""この作業フォルダから起動した画面遷移ビューアのサーバーを停止する。"""

from __future__ import annotations

import sys
import os
import signal
import subprocess
import urllib.error
import urllib.request

from launch_viewer import ROOT, health


def stop_legacy_server(port):
    """停止APIのない旧版だけ、同じ待受ポートのプロセスを終了する。"""
    result = subprocess.run(["netstat", "-ano", "-p", "tcp"], capture_output=True, text=True, errors="replace")
    if result.returncode:
        raise RuntimeError("起動中サーバーのプロセスを特定できませんでした。")
    pids = set()
    for line in result.stdout.splitlines():
        columns = line.split()
        if (len(columns) >= 5 and columns[0].upper() == "TCP"
                and columns[1] == f"127.0.0.1:{port}"
                and columns[-2].upper() == "LISTENING"):
            if columns[-1].isdigit() and columns[-1] != "0":
                pids.add(int(columns[-1]))
    if len(pids) != 1:
        raise RuntimeError(f"ポート {port} のサーバープロセスを一意に特定できませんでした。")
    if (health(port) or {}).get("project") != str(ROOT):
        raise RuntimeError("停止直前にサーバーが変わったため、処理を中止しました。")
    os.kill(pids.pop(), signal.SIGTERM)


def main():
    stopped = 0
    for port in range(8765, 8785):
        status = health(port)
        if not status or status.get("project") != str(ROOT):
            continue
        token = status.get("shutdownToken")
        if token:
            request = urllib.request.Request(
                f"http://127.0.0.1:{port}/api/shutdown",
                data=b"",
                headers={"X-Viewer-Token": token},
                method="POST",
            )
            try:
                with urllib.request.urlopen(request, timeout=5):
                    stopped += 1
                    continue
            except (OSError, urllib.error.URLError):
                pass
        stop_legacy_server(port)
        stopped += 1
    print(f"画面遷移ビューアのサーバーを{stopped}件停止しました。" if stopped else "この作業フォルダのサーバーは起動していません。")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(exc, file=sys.stderr)
        sys.exit(1)
