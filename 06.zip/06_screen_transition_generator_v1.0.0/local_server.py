#!/usr/bin/env python3
"""作業フォルダ内の台帳とHTMLだけを保存する、ローカル専用サーバー。"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import mimetypes
import os
import re
import secrets
import threading
import uuid
import webbrowser
import zipfile
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit
from xml.etree import ElementTree as ET

from generate import DEFAULT_EXCEL, ROOT, build

MAX_WORKBOOK = 256 * 1024 * 1024
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "p": "http://schemas.openxmlformats.org/package/2006/relationships"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def part_path(base: str, target: str) -> str:
    if target.startswith("/"):
        return target.lstrip("/")
    parts = (str(Path(base).parent).replace("\\", "/") + "/" + target).split("/")
    result = []
    for part in parts:
        if part == "..":
            result.pop()
        elif part and part != ".":
            result.append(part)
    return "/".join(result)


def editable_members(package: zipfile.ZipFile) -> set[str]:
    """ブラウザに変更を許すのは、画面・遷移シートと各テーブルのXMLだけ。"""
    workbook = ET.fromstring(package.read("xl/workbook.xml"))
    rels = ET.fromstring(package.read("xl/_rels/workbook.xml.rels"))
    relations = {item.attrib["Id"]: item.attrib["Target"] for item in rels.findall("p:Relationship", NS)}
    allowed = set()
    for sheet in workbook.findall("m:sheets/m:sheet", NS):
        if sheet.attrib["name"] not in {"画面マスタ", "遷移マスタ"}:
            continue
        sheet_path = part_path("xl/workbook.xml", relations[sheet.attrib[f"{{{NS['r']}}}id"]])
        allowed.add(sheet_path)
        sheet_doc = ET.fromstring(package.read(sheet_path))
        rel_path = sheet_path.rsplit("/", 1)
        rel_path = rel_path[0] + "/_rels/" + rel_path[1] + ".rels"
        if rel_path not in package.namelist():
            continue
        sheet_rels = ET.fromstring(package.read(rel_path))
        table_rels = {item.attrib["Id"]: item.attrib["Target"] for item in sheet_rels.findall("p:Relationship", NS)}
        for table in sheet_doc.findall("m:tableParts/m:tablePart", NS):
            target = table_rels.get(table.attrib.get(f"{{{NS['r']}}}id"))
            if target:
                allowed.add(part_path(sheet_path, target))
    return allowed


def validate_workbook(original: bytes, updated: bytes) -> None:
    """ZIPの破損と、編集対象外のシートや設定への変更を拒否する。"""
    try:
        with zipfile.ZipFile(io.BytesIO(original)) as before, zipfile.ZipFile(io.BytesIO(updated)) as after:
            if after.testzip() is not None:
                raise ValueError("Excelファイルが破損しています。")
            if set(before.namelist()) != set(after.namelist()):
                raise ValueError("Excel内部のファイル構成が変わっています。")
            allowed = editable_members(before)
            if not allowed:
                raise ValueError("画面・遷移の編集先が見つかりません。")
            for name in before.namelist():
                if name not in allowed and before.read(name) != after.read(name):
                    raise ValueError("画面・遷移以外のExcelデータは変更できません。")
            for name in allowed:
                if name in after.namelist() and name.endswith((".xml", ".rels")):
                    ET.fromstring(after.read(name))
    except (zipfile.BadZipFile, KeyError, ET.ParseError) as exc:
        raise ValueError("Excelファイルの形式を読み取れません。") from exc


def atomic_restore(path: Path, data: bytes) -> None:
    temporary = path.with_name(path.name + ".restore-" + uuid.uuid4().hex)
    temporary.write_bytes(data)
    os.replace(temporary, path)


class ViewerServer(ThreadingHTTPServer):
    def __init__(self, address):
        generated = build(DEFAULT_EXCEL)
        self.output_path = generated["output_path"]
        self.data = generated["data"]
        self.token = secrets.token_urlsafe(32)
        self.write_lock = threading.Lock()
        super().__init__(address, ViewerHandler)


class ViewerHandler(BaseHTTPRequestHandler):
    server: ViewerServer

    def log_message(self, format_string, *args):
        # 起動用バッチから隠して起動するため、アクセスごとのログは出さない。
        pass

    def send_bytes(self, status: int, body: bytes, content_type: str):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, status: int, value):
        self.send_bytes(status, json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8"), "application/json; charset=utf-8")

    def authorized(self) -> bool:
        origin = self.headers.get("Origin")
        expected = f"http://127.0.0.1:{self.server.server_port}"
        if origin and origin != expected:
            return False
        return secrets.compare_digest(self.headers.get("X-Viewer-Token", ""), self.server.token)

    def screenshot_dir(self) -> Path:
        folder = self.server.data["settings"].get("screenshots_folder", "screenshots")
        root = (ROOT / "input").resolve()
        result = (root / folder).resolve()
        if not result.is_relative_to(root):
            raise ValueError("画像フォルダの設定が不正です。")
        return result

    def do_GET(self):
        route = urlsplit(self.path)
        try:
            if route.path == "/api/health":
                self.send_json(200, {"project": str(ROOT), "version": 1, "shutdownToken": self.server.token})
            elif route.path in {"/", "/index.html"}:
                # ブラウザで開くたびに現在の台帳を反映する。既存サーバーを再利用しても古い図を見せない。
                with self.server.write_lock:
                    generated = build(DEFAULT_EXCEL)
                    self.server.output_path = generated["output_path"]
                    self.server.data = generated["data"]
                    source = self.server.output_path.read_bytes()
                token = self.server.token
                meta = f'<meta name="local-save-token" content="{token}"><meta name="local-html-hash" content="{digest(source)}">'
                html = source.decode("utf-8").replace("</head>", meta + "</head>", 1).encode("utf-8")
                self.send_bytes(200, html, "text/html; charset=utf-8")
            elif route.path == "/api/workbook":
                if not self.authorized():
                    self.send_json(403, {"error": "保存用の接続を確認できません。起動用バッチから開き直してください。"});return
                self.send_bytes(200, DEFAULT_EXCEL.read_bytes(), "application/octet-stream")
            elif route.path == "/api/images":
                if not self.authorized():
                    self.send_json(403, {"error": "保存用の接続を確認できません。"});return
                folder = self.screenshot_dir()
                names = sorted(p.name for p in folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS) if folder.exists() else []
                self.send_json(200, {"images": names})
            elif route.path == "/api/image":
                if not self.authorized():
                    self.send_json(403, {"error": "保存用の接続を確認できません。"});return
                name = parse_qs(route.query).get("name", [""])[0]
                if not name or name != Path(name).name or "\\" in name or Path(name).suffix.lower() not in IMAGE_EXTENSIONS:
                    self.send_json(400, {"error": "画像ファイル名が不正です。"});return
                image = self.screenshot_dir() / name
                if not image.is_file() or image.stat().st_size > 30 * 1024 * 1024:
                    self.send_json(404, {"error": "画像が見つからないか、大きすぎます。"});return
                self.send_bytes(200, image.read_bytes(), mimetypes.guess_type(name)[0] or "application/octet-stream")
            elif self.server.data["settings"].get("image_mode") == "relative":
                # relativeモードでHTMLが参照する、出力先の画像だけを配信する。
                output_dir = self.server.output_path.parent.resolve()
                image_dir = (output_dir / self.server.data["settings"]["screenshots_folder"]).resolve()
                name = unquote(route.path.lstrip("/"))
                image = (output_dir / name).resolve()
                if (not image_dir.is_relative_to(output_dir) or not image.is_relative_to(image_dir)
                        or not image.is_file() or image.suffix.lower() not in IMAGE_EXTENSIONS):
                    self.send_json(404, {"error": "画像が見つかりません。"});return
                self.send_bytes(200, image.read_bytes(), mimetypes.guess_type(image.name)[0] or "application/octet-stream")
            else:
                self.send_json(404, {"error": "ページが見つかりません。"})
        except (OSError, ValueError) as exc:
            self.send_json(500, {"error": str(exc)})

    def do_POST(self):
        route = urlsplit(self.path).path
        if route not in {"/api/save-workbook", "/api/shutdown"}:
            self.send_json(404, {"error": "保存先が見つかりません。"});return
        if not self.authorized():
            self.send_json(403, {"error": "保存用の接続を確認できません。起動用バッチから開き直してください。"});return
        if route == "/api/shutdown":
            self.send_json(200, {"stopping": True})
            # 待受を止め、進行中のExcel保存が終わってからプロセスを終了する。
            def finish_shutdown():
                self.server.shutdown()
                with self.server.write_lock:
                    pass
            threading.Thread(target=finish_shutdown).start()
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_WORKBOOK:
                self.send_json(413, {"error": "Excelファイルが大きすぎます。"});return
            updated = self.rfile.read(length)
            expected_excel = self.headers.get("X-Expected-Workbook-Hash", "")
            expected_html = self.headers.get("X-Expected-Html-Hash", "")
            if not re.fullmatch(r"[0-9a-f]{64}", expected_excel) or not re.fullmatch(r"[0-9a-f]{64}", expected_html):
                self.send_json(400, {"error": "保存元の確認情報がありません。"});return
            with self.server.write_lock:
                original = DEFAULT_EXCEL.read_bytes()
                old_html = self.server.output_path.read_bytes()
                if digest(original) != expected_excel or digest(old_html) != expected_html:
                    self.send_json(409, {"error": "ExcelまたはHTMLが別の操作で変更されました。ページを開き直してください。"});return
                validate_workbook(original, updated)
                backup = ROOT / "backups";backup.mkdir(exist_ok=True)
                stamp = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]
                (backup / f"{stamp}-{DEFAULT_EXCEL.name}").write_bytes(original)
                (backup / f"{stamp}-viewer.html").write_bytes(old_html)
                temporary = DEFAULT_EXCEL.with_name(DEFAULT_EXCEL.name + ".new-" + uuid.uuid4().hex)
                workbook_replaced = False
                try:
                    temporary.write_bytes(updated)
                    os.replace(temporary, DEFAULT_EXCEL)
                    workbook_replaced = True
                    generated = build(DEFAULT_EXCEL)
                    if generated["output_path"].resolve() != self.server.output_path.resolve():
                        raise ValueError("出力先の設定が変更されています。")
                except Exception:
                    if temporary.exists():temporary.unlink()
                    if workbook_replaced:
                        atomic_restore(DEFAULT_EXCEL, original)
                        atomic_restore(self.server.output_path, old_html)
                    raise
                self.server.data = generated["data"]
                self.send_json(200, {"data": generated["data"], "htmlHash": digest(self.server.output_path.read_bytes())})
        except ValueError as exc:
            self.send_json(400, {"error": str(exc)})
        except OSError as exc:
            self.send_json(500, {"error": f"保存できませんでした。Excelを閉じて再試行してください。 {exc}"})
        except Exception as exc:
            self.send_json(500, {"error": f"保存できませんでした。 {exc}"})


def main():
    parser = argparse.ArgumentParser(description="画面遷移ビューアのローカル保存サーバー")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--open-browser", action="store_true", help="起動後にビューアをブラウザで開く")
    args = parser.parse_args()
    server = ViewerServer(("127.0.0.1", args.port))
    url = f"http://127.0.0.1:{server.server_port}/"
    print(f"画面遷移ビューア: {url}", flush=True)
    try:
        if args.open_browser and not webbrowser.open(url):
            print(f"ブラウザで {url} を開いてください。", flush=True)
        print("サーバー稼働中。停止するにはこの画面で Ctrl+C を押すか、ウィンドウを閉じてください。", flush=True)
        server.serve_forever()
    except KeyboardInterrupt:
        print("サーバーを停止しました。", flush=True)
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
