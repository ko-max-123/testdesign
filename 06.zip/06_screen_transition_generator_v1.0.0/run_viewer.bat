@echo off
rem Open the viewer and keep its server in this window.
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 stop_viewer.py
  if errorlevel 1 goto :failed
  py -3 local_server.py --open-browser
) else (
  python stop_viewer.py
  if errorlevel 1 goto :failed
  python local_server.py --open-browser
)
if errorlevel 1 goto :failed

echo.
echo The server has stopped.
exit /b 0

:failed
echo.
echo The viewer could not start or stop. See the error above.
pause
exit /b 1
