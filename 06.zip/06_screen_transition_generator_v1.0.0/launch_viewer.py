#!/usr/bin/env python3
"""保存サーバーを裏で起動し、ブラウザで画面遷移ビューアを開く。"""

from __future__ import annotations

import json
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser

from generate import ROOT


def health(port: int):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=0.5) as response:
            return json.load(response)
    except (OSError, ValueError, urllib.error.URLError):
        return None


def occupied(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.3):
            return True
    except OSError:
        return False


def main():
    for port in range(8765, 8785):
        status = health(port)
        if status and status.get("project") == str(ROOT):
            break
        if occupied(port):
            continue
        log_path = ROOT / "output" / "viewer-server.log"
        log_path.parent.mkdir(exist_ok=True)
        with log_path.open("ab") as log:
            subprocess.Popen(
                [sys.executable, str(ROOT / "local_server.py"), "--port", str(port)],
                cwd=ROOT,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        for _ in range(40):
            time.sleep(0.2)
            status = health(port)
            if status and status.get("project") == str(ROOT):
                break
        else:
            raise RuntimeError(f"保存用サーバーを起動できませんでした。{log_path} を確認してください。")
        break
    else:
        raise RuntimeError("利用できるローカルポートがありません。")
    url = f"http://127.0.0.1:{port}/"
    if not webbrowser.open(url):
        print("ブラウザで次のURLを開いてください:", url)
    else:
        print("画面遷移ビューアを開きました:", url)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("起動できませんでした:", exc, file=sys.stderr)
        sys.exit(1)
