@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo.
echo =============================================
echo  Evidence Organizer - Setup v0.3
echo =============================================
echo.

rem Use the environment if it was created during a previous setup.
if exist ".venv\Scripts\python.exe" goto CHECK_VENV

echo Looking for Python 3.11 or newer...
py -3.11 -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
if not errorlevel 1 (
    echo Python 3.11 found.
    py -3.11 -m venv ".venv"
    goto CHECK_VENV
)
py -3.12 -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
if not errorlevel 1 (
    echo Python 3.12 found.
    py -3.12 -m venv ".venv"
    goto CHECK_VENV
)
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
if not errorlevel 1 (
    echo Python 3 found via the py launcher.
    py -3 -m venv ".venv"
    goto CHECK_VENV
)
python -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
if not errorlevel 1 (
    echo Python 3 found via PATH.
    python -m venv ".venv"
    goto CHECK_VENV
)

echo [ERROR] Python 3.11 or newer was not found.
echo Install Python with the Windows launcher, then try again.
goto FAIL

:CHECK_VENV
if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] Could not create .venv.
    goto FAIL
)
".venv\Scripts\python.exe" -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Existing .venv uses Python older than 3.11.
    echo Rename or delete the .venv directory and run install.bat again.
    goto FAIL
)
echo Installing Python requirements...
".venv\Scripts\python.exe" -m pip install -r "requirements.txt"
if errorlevel 1 (
    echo [ERROR] Could not install Python requirements.
    echo Check the error above, your network, and Python version.
    goto FAIL
)

echo.
echo [OK] Setup completed. Run run.bat to start the app.
pause
exit /b 0

:FAIL
echo.
echo Setup failed. See the error above.
pause
exit /b 1
