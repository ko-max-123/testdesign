import os
from pathlib import Path
import sys
import pytest
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from excel_catalog import WorkbookCatalog
from simple_engine import options_from_catalog, make_start, make_end, sort_folder, order_by_capture_sequence
from evidence_core import ImageItem, read_qr, workspace_paths

DEMO=Path(__file__).resolve().parent

def test_excel_two_styles():
    for fn in ('仕様書_シナリオ型.xlsx','仕様書_複数手順型.xlsx'):
        book=WorkbookCatalog.from_file(DEMO/fn)
        opt=options_from_catalog(book)
        assert opt and all(row[3] for row in opt)
        assert opt[0][1] and opt[0][2]

def test_shiori_and_folder_structure(tmp_path):
    session, start=make_start(tmp_path,'案件A','テスト.xlsx','Sheet1','P1-1','10',False)
    end=make_end(tmp_path,session)
    assert read_qr(start)[0]==(session.sid,'START')
    assert read_qr(end)[0]==(session.sid,'END')
    assert session.folder(tmp_path,'And')==tmp_path/'エビデンス'/'案件A'/'テスト.xlsx'/'P1-1'/'And'
    session2,_=make_start(tmp_path,'案件A','テスト.xlsx','Sheet1','P1-1','11',True)
    assert session2.folder(tmp_path,'iOS')==tmp_path/'エビデンス'/'案件A'/'テスト.xlsx'/'P1-1'/'11'/'iOS'

def test_order_when_metadata_missing(tmp_path):
    def row(n):return ImageItem(tmp_path/f'IMG_{n:04}.JPG', float(9999-n), 'mtime')
    rows=[row(n) for n in (1010,1009,1007,1008)]
    ordered,what=order_by_capture_sequence(rows)
    assert what=='IMG連番'
    assert [r.path.name for r in ordered]==[f'IMG_{n:04}.JPG' for n in (1007,1008,1009,1010)]

def test_full_evidence_flow_and_no_rename(tmp_path):
    input_dir=tmp_path/'photos';input_dir.mkdir()
    sess,start=make_start(tmp_path/'work','決済機能','仕様書A.xlsx','Sheet1','P1-1','5')
    end=make_end(tmp_path/'work',sess)
    # Photo capture simulated: marker screen was photographed in order.
    with Image.open(start) as img:
        img.save(input_dir/'IMG_1001.JPG',quality=95)
    ios=Image.new('RGB',(700,1100),'#6699dd'); ios.save(input_dir/'IMG_1002.PNG')
    android=Image.new('RGB',(900,1400),'#448866');android.save(input_dir/'IMG_1003.JPG')
    with Image.open(end) as img:
        img.save(input_dir/'IMG_1004.JPG',quality=95)
    for name in ('IMG_1001.JPG','IMG_1002.PNG','IMG_1003.JPG','IMG_1004.JPG'):
        assert (input_dir/name).exists()
    result=sort_folder(input_dir,tmp_path/'work')
    assert (result.copied,result.markers,result.hold)==(2,2,0),result
    target=tmp_path/'work'/'エビデンス'/'決済機能'/'仕様書A.xlsx'/'P1-1'
    assert (target/'iOS'/'IMG_1002.PNG').read_bytes()==(input_dir/'IMG_1002.PNG').read_bytes()
    assert (target/'And'/'IMG_1003.JPG').read_bytes()==(input_dir/'IMG_1003.JPG').read_bytes()
    assert set(p.name for p in (target/'iOS').iterdir())=={'IMG_1002.PNG'}
    assert set(p.name for p in (target/'And').iterdir())=={'IMG_1003.JPG'}
    assert len(list(input_dir.iterdir()))==4
    # No auto-rename / overwrite on 2nd run.
    result2=sort_folder(input_dir,tmp_path/'work')
    assert result2.copied==0
    assert result2.hold==2
    assert result2.report.exists()

@pytest.mark.parametrize('miss', ['start','end'])
def test_unpaired_marker_hold(tmp_path,miss):
    src=tmp_path/'photos';src.mkdir()
    seg,start=make_start(tmp_path/'work','A','Book.xlsx','Sheet1','S1','1')
    end=make_end(tmp_path/'work',seg)
    if miss=='end':
        with Image.open(start) as im:im.save(src/'IMG_0001.JPG')
        Image.new('RGB',(900,900)).save(src/'IMG_0002.PNG')
    else:
        Image.new('RGB',(900,900)).save(src/'IMG_0001.PNG')
        with Image.open(end) as im:im.save(src/'IMG_0002.JPG')
    result=sort_folder(src,tmp_path/'work')
    assert result.copied==0
    assert result.hold==1
    assert result.warnings
