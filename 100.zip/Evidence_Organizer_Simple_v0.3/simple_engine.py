"""Small workflow around existing tested marker/copy engine. No image rewrite/rename."""
from __future__ import annotations
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from excel_catalog import WorkbookCatalog, SheetCatalog
from evidence_core import (
    Segment, load_sessions, save_sessions, make_marker, scan_images,
    assign_segments, plan_rows, copy_approved, save_report,
)


def options_from_catalog(book: WorkbookCatalog):
    """Show simple scenario entries from sheets with usable expected ID columns."""
    result = []
    valid_sheets = [s for s in book.sheets if s.expected_col and s.records()]
    for sheet in valid_sheets:
        for scenario, records in sheet.records().items():
            ids = list(dict.fromkeys(v for v, _, _ in records if v))
            if not ids:
                continue
            label = f'{sheet.name} / {scenario}' if len(valid_sheets) > 1 else scenario
            result.append((label, sheet.name, scenario, ids))
    return result


def make_start(root: Path, feature: str, spec: str, sheet: str, scenario: str,
               expected_id: str, item_folder: bool = False):
    # The expected ID is one label for the whole run; never for each photo.
    session = Segment.create(feature, spec, scenario,
                             item_id=expected_id if item_folder else '',
                             expect_start=expected_id, expect_end=expected_id,
                             source_sheet=sheet)
    segments = load_sessions(root)
    segments.append(session)
    save_sessions(root, segments)
    return session, make_marker(root, session, 'START')


def make_end(root: Path, session: Segment):
    if session.sid not in {s.sid for s in load_sessions(root)}:
        raise ValueError('開始しおりが見つかりません。開始しおりを作成してください。')
    return make_marker(root, session, 'END')


def hold_unpaired_marker_runs(rows):
    """Do not copy evidence from a sequence unless its START and END match.

    This is deliberately stricter than the legacy UI: without an END marker,
    later photos might belong to a different test and must not be misfiled.
    """
    active_id = None
    pending = []
    held = 0
    for row in rows:
        if row.kind == 'marker':
            if row.marker_tag == 'START':
                if active_id is not None:
                    for image in pending:
                        image.skipped = True
                        held += 1
                active_id, pending = row.segment_id, []
            elif row.marker_tag == 'END':
                if active_id is not None and row.segment_id == active_id:
                    active_id, pending = None, []
                elif active_id is not None:
                    for image in pending:
                        image.skipped = True
                        held += 1
                    active_id, pending = None, []
        elif active_id is not None:
            pending.append(row)
    if active_id is not None:
        for image in pending:
            image.skipped = True
            held += 1
    return held


def order_by_capture_sequence(rows):
    """Prefer sequential native iPhone IMG_#### filenames when ALL input names qualify.

    Files copied from a phone often lose timestamps. Do not use mixed methods
    blindly: if names do not form a unique sequence, retain metadata ordering.
    """
    if not rows:
        return rows, 'なし'
    matches = [re.fullmatch(r'IMG_(\d{3,6})', row.path.stem, re.IGNORECASE) for row in rows]
    if all(matches) and len(set(int(m.group(1)) for m in matches)) == len(rows):
        nums = [int(m.group(1)) for m in matches]
        if max(nums) - min(nums) < 9000:  # avoid wraparound unless detected
            return sorted(rows, key=lambda r: int(re.fullmatch(r'IMG_(\d{3,6})',r.path.stem,re.I).group(1))), 'IMG連番'
    return rows, '撮影日時（取得可能な情報）'


@dataclass
class SortResult:
    total: int
    markers: int
    copied: int
    hold: int
    warnings: list[str]
    report: Path
    order: str
    reasons: dict[str,int]


def sort_folder(import_dir: Path, root: Path, progress: Callable[[int,int,str],None] | None = None) -> SortResult:
    known = {s.sid:s for s in load_sessions(root)}
    if not known:
        raise ValueError('しおりが未作成です。先に開始しおりと終了しおりを作成してください。')
    rows = scan_images(import_dir, root, progress=progress)
    if not rows:
        raise ValueError('指定フォルダに画像が見つかりません。')
    rows, order = order_by_capture_sequence(rows)
    warnings = assign_segments(rows, known)
    skipped = hold_unpaired_marker_runs(rows)
    if skipped:
        warnings.append(f'開始・終了しおりが揃っていないため、{skipped}枚を保留しました')
    plan = plan_rows(rows, known, root)
    copied_records, copied = copy_approved(plan)
    report = save_report(root, plan, copied_records)
    markers = sum(row.kind == 'marker' for row in rows)
    reasons = dict(Counter(status for row,status,_ in plan if row.kind != 'marker' and status != '分類可能'))
    for rec in copied_records:
        if rec['status'] != 'コピー完了':
            reasons['コピー失敗・保留'] = reasons.get('コピー失敗・保留',0)+1
    hold = sum(reasons.values())
    return SortResult(len(rows), markers, copied, hold, warnings, report, order, reasons)
