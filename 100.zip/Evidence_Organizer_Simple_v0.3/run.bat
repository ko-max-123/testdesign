@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto NO_VENV
".venv\Scripts\python.exe" "app.py"
if errorlevel 1 goto RUN_FAILED
exit /b 0

:NO_VENV
echo [ERROR] Python environment not found.
echo Please run install.bat first.
pause
exit /b 1

:RUN_FAILED
echo.
echo [ERROR] The app exited with an error. See the message above.
pause
exit /b 1
