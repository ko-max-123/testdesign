"""Evidence Organizer v0.2.3 - laptop-friendly Windows Tkinter GUI."""
from __future__ import annotations

import queue
import threading
import re
from collections import Counter
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk, ImageOps

from excel_catalog import WorkbookCatalog, save_catalogs, load_catalogs, col_label
from evidence_core import (
    Segment, ImageItem, load_sessions, save_sessions, make_marker, scan_images,
    assign_segments, plan_rows, copy_approved, save_report, workspace_paths,
    HEIF_AVAILABLE, QR_AVAILABLE
)


class EvidenceApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Evidence Organizer  |  Excel連動・しおり・画像自動仕分け  v0.2.3')
        # Fit inside the available desktop, even with Windows display scaling.
        display_w = self.winfo_screenwidth()
        display_h = self.winfo_screenheight()
        width = min(1080, max(640, display_w - 100))
        height = min(790, max(460, display_h - 130))
        self.geometry(f'{width}x{height}')
        self.minsize(620, 450)
        self.option_add('*Font', ('Yu Gothic UI', 10))
        self.style = ttk.Style(self)
        if 'vista' in self.style.theme_names():
            self.style.theme_use('vista')
        self.style.configure('Title.TLabel', font=('Yu Gothic UI', 15, 'bold'))
        self.style.configure('Accent.TButton', padding=(10, 7))
        self.style.configure('Info.TLabel', foreground='#506273')
        self.style.configure('Treeview', rowheight=29)
        self.style.configure('TNotebook.Tab', padding=(13, 7))

        self.workspace_var = tk.StringVar(value=str(Path.home() / 'EvidenceOrganizer作業'))
        self.import_var = tk.StringVar()
        self.feature_var = tk.StringVar()
        self.spec_var = tk.StringVar()
        self.scenario_var = tk.StringVar()
        self.item_var = tk.StringVar()
        self.expect_start_var = tk.StringVar()
        self.expect_end_var = tk.StringVar()
        self.catalog_choice_var = tk.StringVar()
        self.sheet_var = tk.StringVar()
        self.include_id_var = tk.BooleanVar(value=False)
        self.excel_status_var = tk.StringVar(value='Excel未読込：先にExcelを追加してください（手入力も利用できます）')
        self.destination_var = tk.StringVar(value='エビデンス / （機能） / （仕様書） / （シナリオ） / And・iOS')
        self.selection_hint_var = tk.StringVar(value='Excelを読み込むと、シナリオと期待値IDの候補が自動表示されます。')
        self.details_open = False
        self.catalogs: list[WorkbookCatalog] = []
        self.active_catalog = None
        self.assign_var = tk.StringVar()
        self.sort_var = tk.StringVar(value='撮影日時（自動）')
        self.message_var = tk.StringVar(value='作業フォルダを選択してください。')
        self.summary_var = tk.StringVar(value='画像未取り込み')
        self.progress_var = tk.StringVar(value='')
        self.sessions: list[Segment] = []
        self.rows: list[ImageItem] = []
        self.current_sid = ''
        self.busy = False
        self.events: queue.Queue = queue.Queue()
        self.preview_photo = None
        self.marker_photo = None
        self._build_ui()
        for var in (self.feature_var, self.spec_var, self.scenario_var, self.item_var,
                    self.expect_start_var, self.expect_end_var):
            var.trace_add('write', lambda *_: self._refresh_destination())
        self._load_workspace()
        self.after(110, self._poll_events)

    @property
    def root_dir(self) -> Path:
        return Path(self.workspace_var.get()).expanduser().resolve()

    @property
    def known(self) -> dict[str, Segment]:
        return {seg.sid: seg for seg in self.sessions}

    def _build_ui(self):
        # A two-line workspace header is easier to read on narrow laptop displays.
        top = ttk.Frame(self, padding=(12, 9, 12, 4))
        top.pack(fill='x')
        ttk.Label(top, text='Evidence Organizer', style='Title.TLabel').pack(anchor='w')
        workspace = ttk.Frame(top)
        workspace.pack(fill='x', pady=(4, 1))
        workspace.columnconfigure(1, weight=1)
        ttk.Label(workspace, text='作業フォルダ').grid(row=0, column=0, sticky='w')
        ttk.Entry(workspace, textvariable=self.workspace_var, state='readonly').grid(row=0, column=1, sticky='ew', padx=5)
        ttk.Button(workspace, text='選択...', command=self._choose_workspace).grid(row=0, column=2, padx=(0,4))
        ttk.Button(workspace, text='読込', command=self._load_workspace).grid(row=0, column=3)

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill='both', expand=True, padx=8, pady=(2, 3))
        self.marker_page = ttk.Frame(self.tabs, padding=3)
        self.sort_page = ttk.Frame(self.tabs, padding=3)
        self.tabs.add(self.marker_page, text='1  Excel・しおり')
        self.tabs.add(self.sort_page, text='2  画像仕分け')
        self._build_marker_ui()
        self._build_sort_ui()
        bar = ttk.Frame(self, padding=(10, 4, 10, 7))
        bar.pack(fill='x')
        self.status_message = ttk.Label(bar, textvariable=self.message_var,
                                        foreground='#42566c', anchor='w')
        self.status_message.pack(fill='x')
        ttk.Label(bar, text=f'HEIC: {"対応" if HEIF_AVAILABLE else "未対応"} / QR: {"対応" if QR_AVAILABLE else "未対応"}',
                  style='Info.TLabel').pack(anchor='w', pady=(2, 0))
        self.bind('<Configure>', self._on_window_resize, add='+')
        self.after_idle(self._on_window_resize)

    def _scroll_area(self, page, *, horizontal=False):
        """Scrollable page. Horizontal fallback prevents hidden controls at high DPI."""
        outer = ttk.Frame(page)
        outer.pack(fill='both', expand=True)
        canvas = tk.Canvas(outer, highlightthickness=0, borderwidth=0)
        vert = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
        vert.pack(side='right', fill='y')
        if horizontal:
            bottom = ttk.Scrollbar(page, orient='horizontal', command=canvas.xview)
            bottom.pack(side='bottom', fill='x')
            canvas.configure(xscrollcommand=bottom.set)
        canvas.configure(yscrollcommand=vert.set)
        canvas.pack(side='left', fill='both', expand=True)
        body = ttk.Frame(canvas, padding=(6, 2, 10, 10))
        window_id = canvas.create_window((0, 0), window=body, anchor='nw')

        def resize(_=None):
            # Do not clip a control that cannot physically shrink further.
            target_w = max(canvas.winfo_width(), body.winfo_reqwidth())
            target_h = max(canvas.winfo_height(), body.winfo_reqheight())
            canvas.itemconfigure(window_id, width=target_w, height=target_h)
            canvas.configure(scrollregion=canvas.bbox('all'))

        canvas.bind('<Configure>', resize)
        body.bind('<Configure>', lambda e: canvas.after_idle(resize))
        # Scroll when pointer is over the page; Treeview keeps its own scroll.
        def wheel(e):
            widget = e.widget
            while widget is not None and widget is not canvas:
                if isinstance(widget, (ttk.Treeview, tk.Text, tk.Listbox)):
                    return
                widget = getattr(widget, 'master', None)
            canvas.yview_scroll(-1 if e.delta > 0 else 1, 'units')
        canvas.bind('<MouseWheel>', wheel)
        def bind_wheel(w):
            # Bind on the page's descendants, without overriding list/text input behavior.
            for child in w.winfo_children():
                if not isinstance(child, (ttk.Treeview, tk.Text, tk.Listbox, ttk.Combobox)):
                    child.bind('<MouseWheel>', wheel, add='+')
                bind_wheel(child)
        body.after(100, lambda: bind_wheel(body))
        return body

    def _on_window_resize(self, event=None):
        if event is not None and event.widget is not self:
            return
        width = max(360, self.winfo_width() - 75)
        for name in ('marker_desc_label', 'excel_status_label', 'scenario_desc_label',
                     'ids_desc_label', 'selection_hint_label', 'dest_path_label',
                     'detail_desc_label', 'step3_desc_label', 'status_message',
                     'sort_desc_label'):
            label = getattr(self, name, None)
            if label is not None and label.winfo_exists():
                label.configure(wraplength=width)

    def _build_marker_ui(self):
        root = self._scroll_area(self.marker_page, horizontal=True)
        ttk.Label(root, text='撮影区間の選択と、開始・終了しおりの作成',
                  style='Title.TLabel').pack(anchor='w', pady=(1, 4))
        self.marker_desc_label = ttk.Label(root, text='写真1枚ずつのID付与や撮影枚数の指定は不要です。',
                                           style='Info.TLabel')
        self.marker_desc_label.pack(anchor='w', pady=(0, 8))

        excel = ttk.LabelFrame(root, text='Step 1   テスト仕様書を読み込む', padding=9)
        excel.pack(fill='x', pady=(0, 8))
        excel.columnconfigure(1, weight=1)
        ttk.Button(excel, text='Excelを追加（複数可）...',
                   command=self._add_spec_files).grid(row=0, column=0, columnspan=3,
                                                      sticky='w', pady=(0, 5))
        ttk.Label(excel, text='仕様書').grid(row=1, column=0, sticky='w', pady=3)
        self.catalog_combo = ttk.Combobox(excel, textvariable=self.catalog_choice_var,
                                         state='readonly', width=16)
        self.catalog_combo.grid(row=1, column=1, columnspan=2, sticky='ew', padx=(8,0), pady=3)
        self.catalog_combo.bind('<<ComboboxSelected>>', self._on_catalog_selected)
        ttk.Label(excel, text='シート').grid(row=2, column=0, sticky='w', pady=3)
        self.sheet_combo = ttk.Combobox(excel, textvariable=self.sheet_var, state='readonly', width=15)
        self.sheet_combo.grid(row=2, column=1, sticky='ew', padx=(8,8), pady=3)
        self.sheet_combo.bind('<<ComboboxSelected>>', self._on_sheet_selected)
        ttk.Button(excel, text='列の対応を変更...',
                   command=self._mapping_dialog).grid(row=2, column=2, sticky='e')
        self.excel_status_label = ttk.Label(excel, textvariable=self.excel_status_var,
                                            style='Info.TLabel')
        self.excel_status_label.grid(row=3, column=0, columnspan=3, sticky='w', pady=(4,0))

        form = ttk.LabelFrame(root, text='Step 2   撮影する範囲を選択', padding=10)
        form.pack(fill='x', pady=(0, 8))
        form.columnconfigure(0, weight=1)
        ttk.Label(form, text='① シナリオIDを選ぶ', font=('Yu Gothic UI', 11, 'bold')).grid(row=0, column=0, sticky='w')
        self.scenario_combo = ttk.Combobox(form, textvariable=self.scenario_var, state='normal')
        self.scenario_combo.grid(row=1, column=0, sticky='ew', pady=(4, 2))
        self.scenario_combo.bind('<<ComboboxSelected>>', self._on_scenario_selected)
        self.scenario_desc_label = ttk.Label(form, text='Excelから抽出されたシナリオを選択します。',
                                             style='Info.TLabel')
        self.scenario_desc_label.grid(row=2, column=0, sticky='w')
        ttk.Label(form, text='② 今回撮影する期待値IDの範囲を選ぶ',
                  font=('Yu Gothic UI', 11, 'bold')).grid(row=3, column=0, sticky='w', pady=(9, 3))
        ids = ttk.Frame(form)
        ids.grid(row=4, column=0, sticky='ew', pady=(0, 3))
        ids.columnconfigure(1, weight=1)
        ids.columnconfigure(3, weight=1)
        ttk.Label(ids, text='開始ID').grid(row=0, column=0, padx=(0,5))
        self.expect_start_combo = ttk.Combobox(ids, textvariable=self.expect_start_var,
                                                state='normal', width=9)
        self.expect_start_combo.grid(row=0, column=1, sticky='ew', padx=(0, 8))
        ttk.Label(ids, text='終了ID').grid(row=0, column=2, padx=(0,5))
        self.expect_end_combo = ttk.Combobox(ids, textvariable=self.expect_end_var,
                                              state='normal', width=9)
        self.expect_end_combo.grid(row=0, column=3, sticky='ew')
        id_actions = ttk.Frame(form)
        id_actions.grid(row=5, column=0, sticky='w', pady=(4, 1))
        ttk.Button(id_actions, text='シナリオの全ID', command=self._set_entire_scenario).pack(side='left')
        ttk.Button(id_actions, text='開始IDのみ', command=self._set_single_expected).pack(side='left', padx=6)
        self.expect_start_combo.bind('<<ComboboxSelected>>', self._on_expected_selected)
        self.expect_end_combo.bind('<<ComboboxSelected>>', self._on_expected_selected)
        self.ids_desc_label = ttk.Label(form, text='最初は全IDが選ばれます。一部だけ撮影するときに変更してください。',
                                         style='Info.TLabel')
        self.ids_desc_label.grid(row=6, column=0, sticky='w', pady=(4,5))

        ttk.Label(form, text='選択した範囲の内容（Excelより）',
                  font=('Yu Gothic UI', 10, 'bold')).grid(row=7, column=0, sticky='w')
        self.selection_hint_label = ttk.Label(form, textvariable=self.selection_hint_var,
                                               style='Info.TLabel')
        self.selection_hint_label.grid(row=8, column=0, sticky='w', pady=(2,3))
        self.expected_preview = tk.Text(form, height=3, wrap='word', font=('Yu Gothic UI', 9),
                                        state='disabled', foreground='#42566c', relief='solid', bd=1)
        self.expected_preview.grid(row=9, column=0, sticky='ew', pady=(0, 5))
        dest = ttk.Frame(form, padding=8, relief='ridge')
        dest.grid(row=10, column=0, sticky='ew', pady=(4, 4))
        ttk.Label(dest, text='保存先フォルダ（自動）',
                  font=('Yu Gothic UI', 10, 'bold')).pack(anchor='w')
        self.dest_path_label = ttk.Label(dest, textvariable=self.destination_var,
                                         style='Info.TLabel')
        self.dest_path_label.pack(anchor='w', pady=(3,0))
        self.detail_desc_label = ttk.Label(dest,
            text='期待値IDはしおりに記録します。通常はIDごとのフォルダを作りません。',
            style='Info.TLabel')
        self.detail_desc_label.pack(anchor='w', pady=(2,0))
        self.details_button = ttk.Button(form, text='▶ 詳細設定（案件名・仕様書名・任意のIDフォルダ）',
                                         command=self._toggle_details)
        self.details_button.grid(row=11, column=0, sticky='w', pady=(5, 0))
        self.details_frame = ttk.Frame(form, padding=8)
        self.details_frame.grid(row=12, column=0, sticky='ew', pady=(3, 3))
        self.details_frame.columnconfigure(0, weight=1)
        ttk.Label(self.details_frame, text='機能（案件名）').grid(row=0, column=0, sticky='w')
        ttk.Entry(self.details_frame, textvariable=self.feature_var).grid(row=1, column=0,
                                                      sticky='ew', pady=(2,5))
        ttk.Label(self.details_frame, text='仕様書のファイル名').grid(row=2, column=0, sticky='w')
        ttk.Entry(self.details_frame, textvariable=self.spec_var).grid(row=3, column=0,
                                                      sticky='ew', pady=(2,5))
        ttk.Checkbutton(self.details_frame, text='シナリオIDの下にIDフォルダを作る',
                        variable=self.include_id_var,
                        command=self._on_toggle_id_folder).grid(row=4, column=0, sticky='w')
        self.folder_id_entry = ttk.Entry(self.details_frame, textvariable=self.item_var, state='disabled')
        self.folder_id_entry.grid(row=5, column=0, sticky='ew', pady=(3,5))
        self.details_frame.grid_remove()
        ttk.Button(form, text='③ この範囲のしおりを作る（START表示）',
                   style='Accent.TButton', command=self._add_segment).grid(row=13, column=0,
                                                      sticky='w', pady=(10,3))
        ttk.Label(form, text='作成後、iPhoneでSTARTを撮影してください。',
                  style='Info.TLabel').grid(row=14, column=0, sticky='w')

        lower = ttk.LabelFrame(root, text='Step 3   開始しおり → 撮影 → 終了しおり', padding=9)
        lower.pack(fill='both', expand=True)
        self.step3_desc_label = ttk.Label(lower,
            text='作成済みの撮影区間を選び、STARTとENDのしおりを表示できます。',
            style='Info.TLabel')
        self.step3_desc_label.pack(anchor='w', pady=(0,5))
        self.segment_list = tk.Listbox(lower, height=4, activestyle='none', exportselection=False)
        self.segment_list.pack(fill='both', expand=True)
        self.segment_list.bind('<<ListboxSelect>>', self._on_segment_selected)
        marker_actions = ttk.Frame(lower)
        marker_actions.pack(fill='x', pady=(8, 3))
        ttk.Button(marker_actions, text='① STARTを表示',
                   command=lambda:self._open_marker('START')).pack(side='left', padx=(0,6))
        ttk.Button(marker_actions, text='② ENDを表示',
                   command=lambda:self._open_marker('END')).pack(side='left')
        next_actions = ttk.Frame(lower)
        next_actions.pack(fill='x', pady=(3,0))
        ttk.Button(next_actions, text='しおり保存先を開く',
                   command=self._open_marker_folder).pack(side='left')
        ttk.Button(next_actions, text='③ 画像仕分けへ',
                   command=lambda: self.tabs.select(self.sort_page)).pack(side='right')

    def _toggle_details(self):
        self.details_open = not self.details_open
        if self.details_open:
            self.details_button.configure(text='▼ 詳細設定を閉じる')
            self.details_frame.grid()
        else:
            self.details_button.configure(text='▶ 詳細設定を表示（案件名・仕様書名・任意のIDフォルダ）')
            self.details_frame.grid_remove()

    def _set_entire_scenario(self):
        sh = self._active_sheet()
        if sh:
            ids = sh.ids_for(self.scenario_var.get())
            if ids:
                self.expect_start_var.set(ids[0])
                self.expect_end_var.set(ids[-1])
                self._on_expected_selected()

    def _set_single_expected(self):
        self.expect_end_var.set(self.expect_start_var.get())
        self._on_expected_selected()

    def _refresh_destination(self):
        feature = self.feature_var.get().strip() or '（機能名）'
        spec = self.spec_var.get().strip() or '（仕様書名）'
        scenario = self.scenario_var.get().strip() or '（シナリオID）'
        parts = ['エビデンス', feature, spec, scenario]
        if self.include_id_var.get():
            parts.append(self.item_var.get().strip() or '（任意のID）')
        self.destination_var.set(' / '.join(parts) + ' / And または iOS')
        start, end = self.expect_start_var.get().strip(), self.expect_end_var.get().strip()
        if start and end:
            tag = start if start == end else f'{start} ～ {end}'
            self.selection_hint_var.set(f'しおりに記録する期待値ID：{tag}（写真の枚数は自由）')
        else:
            self.selection_hint_var.set('期待値IDを選択すると内容が表示されます。')

    def _refresh_catalog_combo(self, select_source=None):
        labels = [f'{c.spec}  |  {Path(c.source).parent.name}' for c in self.catalogs]
        self.catalog_combo['values'] = labels
        if not self.catalogs:
            self.active_catalog = None
            self.catalog_choice_var.set('')
            self.sheet_combo['values'] = []
            return
        selected = 0
        if select_source:
            selected = next((i for i,c in enumerate(self.catalogs) if c.source == select_source),0)
        self.catalog_combo.current(selected)
        self._on_catalog_selected()

    def _add_spec_files(self):
        files = filedialog.askopenfilenames(title='テスト仕様書（.xlsx / .xlsm）を選択（複数選択可能）',
                                             filetypes=[('Excel', '*.xlsx *.xlsm'),('すべて', '*.*')])
        if not files:
            return
        successful = []
        errors = []
        for name in files:
            try:
                catalog = WorkbookCatalog.from_file(Path(name))
                self.catalogs = [item for item in self.catalogs if item.source != catalog.source]
                self.catalogs.append(catalog)
                successful.append(catalog.source)
            except Exception as e:
                errors.append(f'{Path(name).name}: {e}')
        if successful:
            save_catalogs(self.root_dir, self.catalogs)
            self._refresh_catalog_combo(select_source=successful[-1])
            self.message_var.set(f'Excel {len(successful)}冊から選択候補を生成しました。')
        if errors:
            messagebox.showwarning('読み取れないExcelがあります', '\n'.join(errors[:12]))

    def _on_catalog_selected(self, _event=None):
        index = self.catalog_combo.current()
        if index < 0 or index >= len(self.catalogs):
            return
        catalog = self.catalogs[index]
        self.active_catalog = catalog
        self.feature_var.set(catalog.feature)
        self.spec_var.set(catalog.spec)
        names = [sheet.name for sheet in catalog.sheets]
        self.sheet_combo['values'] = names
        if names:
            self.sheet_combo.current(0)
            self._on_sheet_selected()

    def _active_sheet(self):
        if self.active_catalog is None:
            return None
        return self.active_catalog.sheet(self.sheet_var.get())

    def _on_sheet_selected(self, _event=None):
        sh = self._active_sheet()
        if not sh:
            return
        entries = sh.records()
        scenarios = list(entries)
        self.scenario_combo['values'] = scenarios
        self.scenario_combo.configure(state='readonly' if scenarios else 'normal')
        self.excel_status_var.set(f'シート「{sh.name}」 / シナリオ {len(scenarios)}件 / '
                                  f'シナリオ列 {col_label(sh.scenario_col) or "未設定"} / '
                                  f'期待値ID列 {col_label(sh.expected_col) or "未設定"} / '
                                  f'見出し行 {sh.header_row}')
        if scenarios:
            self.scenario_var.set(scenarios[0])
            self._on_scenario_selected()
        else:
            self.scenario_var.set('')
            self.expect_start_var.set('')
            self.expect_end_var.set('')
            self._refresh_expected_preview()

    def _on_scenario_selected(self, _event=None):
        sh = self._active_sheet()
        if not sh:
            return
        ids = sh.ids_for(self.scenario_var.get())
        self.expect_start_combo['values'] = ids
        self.expect_end_combo['values'] = ids
        self.expect_start_combo.configure(state='readonly' if ids else 'normal')
        self.expect_end_combo.configure(state='readonly' if ids else 'normal')
        if ids:
            self.expect_start_var.set(ids[0])
            self.expect_end_var.set(ids[-1])
        else:
            self.expect_start_var.set('')
            self.expect_end_var.set('')
        self._refresh_expected_preview()
        if self.include_id_var.get():
            self.item_var.set(self.expect_start_var.get())

    def _on_expected_selected(self, _event=None):
        self._refresh_expected_preview()
        if self.include_id_var.get():
            first = self.expect_start_var.get().strip()
            last = self.expect_end_var.get().strip()
            self.item_var.set(first if not last or first == last else first + '～' + last)

    def _refresh_expected_preview(self):
        sh = self._active_sheet()
        preview = sh.short_preview(self.scenario_var.get(), self.expect_start_var.get(), self.expect_end_var.get()) if sh else 'Excelを読み込むと、対象の期待値IDと内容が表示されます。'
        self.expected_preview.configure(state='normal')
        self.expected_preview.delete('1.0','end')
        self.expected_preview.insert('1.0',preview)
        self.expected_preview.configure(state='disabled')

    def _on_toggle_id_folder(self):
        if self.include_id_var.get():
            self.folder_id_entry.configure(state='normal')
            self._on_expected_selected()
        else:
            self.item_var.set('')
            self.folder_id_entry.configure(state='disabled')
        self._refresh_destination()

    def _mapping_dialog(self):
        sh = self._active_sheet()
        if not sh:
            messagebox.showinfo('Excel未選択', '先にExcelとシートを選択してください。')
            return
        dialog = tk.Toplevel(self)
        dialog.title(f'列の対応変更 | {sh.name}')
        dialog.geometry(f'{min(640,max(490,self.winfo_width()-40))}x{min(570,max(400,self.winfo_height()-30))}')
        dialog.minsize(460, 380)
        dialog.transient(self)
        dialog.grab_set()
        frame = ttk.Frame(dialog, padding=12)
        frame.pack(fill='both',expand=True)
        ttk.Label(frame, text='Excelの列と見出し行を設定', style='Title.TLabel').pack(anchor='w')
        headerbar = ttk.Frame(frame)
        headerbar.pack(fill='x',pady=(12,5))
        ttk.Label(headerbar,text='見出し行').pack(side='left')
        head = tk.IntVar(value=sh.header_row)
        ttk.Spinbox(headerbar,from_=1,to=200,textvariable=head,width=7).pack(side='left',padx=8)
        combos={}
        labels = [('シナリオID列（省略するとシート名）','scenario_col'),
                  ('期待値ID列（必須）','expected_col'),
                  ('説明文の列（任意）','description_col')]
        options = sh.column_options()
        def options_for(header):
            return {i:f'{col_label(i)}列 | {sh.header(i) or "(見出しなし)"}' for i,_ in options}
        def update_options():
            try:
                sh.header_row=head.get()
                mapping=options_for(head.get())
                for prop, combo in combos.items():
                    i=getattr(sh,prop)
                    combo['values'] = ['(使用しない)']+list(mapping.values())
                    combo.set(mapping.get(i,'(使用しない)'))
            except (ValueError, tk.TclError):
                pass
        ttk.Button(headerbar,text='見出し更新',command=update_options).pack(side='left')
        for label,prop in labels:
            row=ttk.Frame(frame)
            row.pack(fill='x',pady=(6,2))
            ttk.Label(row,text=label).pack(anchor='w',pady=(0,2))
            combo=ttk.Combobox(row,state='readonly')
            combo.pack(fill='x')
            combos[prop]=combo
        update_options()
        ttk.Label(frame,
          text='例：パターンAはシナリオID=B列、期待値ID=A列またはSID=C列。パターンBはシナリオ=No列、期待値ID=A列。',
          style='Info.TLabel',wraplength=540).pack(anchor='w',pady=(9,2))
        def save():
            try:
                mapping=options_for(head.get())
                values={value:key for key,value in mapping.items()}
                chosen={prop:values.get(combo.get(),0) for prop,combo in combos.items()}
                if not chosen['expected_col']:
                    raise ValueError('期待値IDの列を選択してください。')
                sh.scenario_col=chosen['scenario_col']
                sh.expected_col=chosen['expected_col']
                sh.description_col=chosen['description_col']
                if self.active_catalog:
                    self.active_catalog.feature=self.feature_var.get().strip() or self.active_catalog.feature
                save_catalogs(self.root_dir,self.catalogs)
                self._on_sheet_selected()
                dialog.destroy()
            except Exception as e:
                messagebox.showerror('列対応の保存に失敗',str(e),parent=dialog)
        ttk.Button(frame,text='この列設定を適用',command=save).pack(anchor='e',pady=8)

    def _build_sort_ui(self):
        root = self._scroll_area(self.sort_page, horizontal=False)
        top = ttk.LabelFrame(root, text='① 撮影済み画像を取り込む', padding=8)
        top.pack(fill='x', pady=(0,6))
        ttk.Label(top, text='iPhoneからPCに取り込んだ画像フォルダ').pack(anchor='w')
        choose = ttk.Frame(top)
        choose.pack(fill='x',pady=(4,0))
        ttk.Entry(choose, textvariable=self.import_var).pack(side='left', fill='x', expand=True, padx=(0,5))
        ttk.Button(choose, text='選択...', command=self._choose_import).pack(side='left')
        ttk.Button(top, text='画像をスキャン', command=self._start_scan).pack(anchor='w', pady=(5,0))
        self.sort_desc_label = ttk.Label(root,
            text='しおり画像も同じフォルダに入れてください。元のファイル名を保持し、撮影区間とOSで分類します。',
            style='Info.TLabel')
        self.sort_desc_label.pack(anchor='w',pady=(0,7))

        ctr = ttk.LabelFrame(root, text='② 必要な画像だけ選んで修正', padding=8)
        ctr.pack(fill='x', pady=(0,6))
        ttk.Label(ctr, text='画像に割り当てる撮影区間').pack(anchor='w')
        self.assign_combo = ttk.Combobox(ctr, textvariable=self.assign_var,
                                         state='readonly', width=15)
        self.assign_combo.pack(fill='x', pady=(3,5))
        corrections = ttk.Frame(ctr)
        corrections.pack(fill='x')
        ttk.Button(corrections, text='区間を設定', command=self._set_segment).pack(side='left', padx=(0,6))
        ttk.Button(corrections, text='And', command=lambda:self._set_platform('And')).pack(side='left',padx=(0,6))
        ttk.Button(corrections, text='iOS', command=lambda:self._set_platform('iOS')).pack(side='left',padx=(0,6))
        ttk.Button(corrections, text='OS未判定', command=lambda:self._set_platform('')).pack(side='left')
        tools = ttk.Frame(ctr)
        tools.pack(fill='x',pady=(5,0))
        ttk.Button(tools, text='↑ 上へ', command=lambda:self._move(-1)).pack(side='left',padx=(0,5))
        ttk.Button(tools, text='↓ 下へ', command=lambda:self._move(1)).pack(side='left',padx=(0,5))
        ttk.Button(tools, text='区間を再判定', command=self._reassign).pack(side='left',padx=(0,5))
        ttk.Button(tools, text='除外 / 解除', command=self._toggle_skip).pack(side='left')
        sorting = ttk.Frame(ctr)
        sorting.pack(fill='x', pady=(6,0))
        ttk.Label(sorting, text='並び順').pack(side='left')
        ttk.Combobox(sorting, width=19, textvariable=self.sort_var, state='readonly',
                     values=['撮影日時（自動）','IMG連番（ファイル名）','ファイル名']).pack(side='left', padx=5)
        ttk.Button(sorting, text='適用', command=self._apply_sort).pack(side='left')

        ttk.Label(root, text='③ 分類結果を確認（表は左右にスクロール可能）',
                  font=('Yu Gothic UI', 10, 'bold')).pack(anchor='w',pady=(5,3))
        self.paned = ttk.Panedwindow(root, orient='vertical', height=370)
        self.paned.pack(fill='both', expand=True, pady=(0,4))
        treebox = ttk.Frame(self.paned, width=470)
        treebox.pack_propagate(False)
        self.paned.add(treebox, weight=4)
        cols = ('no','file','time','basis','type','segment','os','certainty','status')
        self.tree = ttk.Treeview(treebox, columns=cols, show='headings', selectmode='extended')
        details = [('no','#',45),('file','元ファイル名',190),('time','撮影日時（推定）',155),
                   ('basis','日時の根拠',120),('type','種類',70),('segment','区間',120),
                   ('os','OS',60),('certainty','推定精度',75),('status','状態',210)]
        for name, label, size in details:
            self.tree.heading(name, text=label)
            self.tree.column(name, width=size, minwidth=45, stretch=(name in ['file','status']))
        self.tree.pack(side='left', fill='both', expand=True)
        ys = ttk.Scrollbar(treebox, orient='vertical', command=self.tree.yview)
        ys.pack(side='right', fill='y')
        self.tree.configure(yscrollcommand=ys.set)
        xs = ttk.Scrollbar(root, orient='horizontal', command=self.tree.xview)
        xs.pack(fill='x', pady=(0,4))
        self.tree.configure(xscrollcommand=xs.set)
        self.tree.tag_configure('needs', background='#fff0dc')
        self.tree.tag_configure('marker', foreground='#607089')
        self.tree.bind('<<TreeviewSelect>>', self._on_image_selected)

        details_box = ttk.Frame(self.paned, width=540)
        details_box.pack_propagate(False)
        self.paned.add(details_box, weight=1)
        # Preview uses a separate row instead of requiring 2 wide columns.
        self.image_preview = ttk.Label(details_box,
                text='画像を選択するとプレビューが表示されます。', anchor='center')
        self.image_preview.pack(side='left', padx=(5,6), pady=5)
        side = ttk.Frame(details_box)
        side.pack(side='left', fill='both', expand=True, padx=5, pady=5)
        self.item_info = tk.Text(side, wrap='word', width=32, height=6, font=('Yu Gothic UI', 10),state='disabled')
        self.item_info.pack(fill='both',expand=True)

        bottom = ttk.LabelFrame(root, text='④ 分類できた画像だけコピー', padding=8)
        bottom.pack(fill='x',pady=(5,0))
        ttk.Label(bottom, textvariable=self.summary_var).pack(anchor='w',pady=(0,5))
        ttk.Button(bottom, text='分類可能な画像をコピー', style='Accent.TButton',
                   command=self._start_copy).pack(anchor='w',pady=(1,5))
        ttk.Button(bottom, text='分類計画CSVを保存', command=self._save_plan_report).pack(anchor='w')
        ttk.Label(root, textvariable=self.progress_var, style='Info.TLabel').pack(anchor='w',pady=(5,0))

    def _choose_workspace(self):
        folder = filedialog.askdirectory(title='作業フォルダを選択')
        if folder:
            self.workspace_var.set(folder)
            self._load_workspace()

    def _choose_spec(self):
        self._add_spec_files()

    def _choose_import(self):
        folder = filedialog.askdirectory(title='iPhone画像を取り込んだフォルダを選択')
        if folder:
            self.import_var.set(folder)

    def _load_workspace(self):
        if self.busy:
            messagebox.showwarning('処理中', '処理完了後に作業フォルダを変更してください。')
            return
        try:
            self.sessions = load_sessions(self.root_dir)
            self.catalogs = load_catalogs(self.root_dir)
            self.active_catalog = None
            self._refresh_catalog_combo()
            self.current_sid = ''
            self.rows.clear()
            self._refresh_segments()
            self._refresh_tree()
            self.message_var.set(f'作業フォルダ: {self.root_dir} / しおり区間 {len(self.sessions)} 件')
        except Exception as e:
            messagebox.showerror('読込エラー', str(e))

    def _refresh_segments(self):
        self.segment_list.delete(0, tk.END)
        for s in self.sessions:
            self.segment_list.insert(tk.END, s.label())
        self.assign_combo['values'] = ['未割当'] + [s.label() for s in self.sessions]
        self.assign_combo.current(0)

    def _clear_scenario(self):
        self.expect_start_var.set('')
        self.expect_end_var.set('')
        self._refresh_expected_preview()
        if self.include_id_var.get():
            self.item_var.set('')

    def _add_segment(self):
        try:
            sh = self._active_sheet()
            start = self.expect_start_var.get().strip()
            end = self.expect_end_var.get().strip() or start
            if sh and start and end:
                ids = sh.ids_for(self.scenario_var.get())
                if start not in ids or end not in ids:
                    raise ValueError('選択した期待値IDがExcelに見つかりません。IDとシナリオを確認してください。')
                if ids.index(start) > ids.index(end):
                    raise ValueError('期待値IDの終了が開始より前です。')
            if self.active_catalog:
                self.active_catalog.feature=self.feature_var.get().strip()
                save_catalogs(self.root_dir,self.catalogs)
            folder_id = self.item_var.get().strip() if self.include_id_var.get() else ''
            seg = Segment.create(self.feature_var.get(), self.spec_var.get(), self.scenario_var.get(), folder_id,
                                 start, end, self.sheet_var.get() if sh else '')
            self.sessions.append(seg)
            save_sessions(self.root_dir, self.sessions)
            make_marker(self.root_dir, seg, 'START')
            make_marker(self.root_dir, seg, 'END')
            self.current_sid = seg.sid
            self._refresh_segments()
            self.segment_list.selection_set(len(self.sessions)-1)
            self.segment_list.see(len(self.sessions)-1)
            self.message_var.set(f'撮影対象のしおりを作成しました。STARTをiPhoneで撮影し、撮影終了後はStep 3のENDを表示してください。: {seg.label()}')
            self._open_marker('START')
        except Exception as e:
            messagebox.showerror('区間登録に失敗', str(e))

    def _on_segment_selected(self, _event=None):
        selected = self.segment_list.curselection()
        if selected:
            self.current_sid = self.sessions[selected[0]].sid

    def _open_marker_folder(self):
        if not self.current_sid:
            messagebox.showinfo('選択してください', '区間を選んでください。')
            return
        folder = workspace_paths(self.root_dir)[0] / 'しおり' / self.current_sid
        try:
            import os
            if os.name == 'nt':
                os.startfile(str(folder))
            else:
                self.clipboard_clear(); self.clipboard_append(str(folder))
                messagebox.showinfo('保存先パス', f'パスをクリップボードへコピーしました。\n{folder}')
        except Exception as e:
            messagebox.showerror('フォルダ表示失敗', str(e))

    def _open_marker(self, tag: str):
        if not self.current_sid or self.current_sid not in self.known:
            messagebox.showinfo('区間未選択', 'まず登録済み区間を選択してください。')
            return
        path = make_marker(self.root_dir, self.known[self.current_sid], tag)
        window = tk.Toplevel(self)
        window.title('撮影開始しおり' if tag == 'START' else '撮影終了しおり')
        window.geometry(f'{min(720, max(450, self.winfo_screenwidth()-70))}x{min(760, max(430, self.winfo_screenheight()-110))}')
        window.configure(background='white')
        bar = ttk.Frame(window, padding=8)
        bar.pack(fill='x')
        ttk.Label(bar, text=('① テスト開始前にiPhoneのカメラで撮影してください。' if tag == 'START' else '② テスト撮影を終えたらiPhoneのカメラで撮影してください。'), font=('Yu Gothic UI', 10, 'bold'), wraplength=max(360,window.winfo_screenwidth()-100)).pack(anchor='w')
        holder = ttk.Label(window)
        holder.pack(fill='both', expand=True)
        original = Image.open(path)
        original.thumbnail((max(360, min(670, window.winfo_screenwidth()-115)), max(270, min(645, window.winfo_screenheight()-215))))
        window.marker_photo = ImageTk.PhotoImage(original)
        holder.configure(image=window.marker_photo)
        footer = ttk.Frame(window, padding=8)
        footer.pack(fill='x')
        ttk.Button(footer, text='START 表示', command=lambda:(window.destroy(), self._open_marker('START'))).pack(side='left', padx=4)
        ttk.Button(footer, text='END 表示', command=lambda:(window.destroy(), self._open_marker('END'))).pack(side='left', padx=4)
        ttk.Button(footer, text='閉じる', command=window.destroy).pack(side='right')

    def _start_scan(self):
        if self.busy:
            return
        directory = Path(self.import_var.get())
        if not directory.is_dir():
            messagebox.showerror('画像未指定', '取り込み画像があるフォルダを選択してください。')
            return
        if not QR_AVAILABLE:
            messagebox.showerror('QRライブラリ不足', 'OpenCVがありません。install.batで必要ライブラリをインストールしてください。')
            return
        self.busy = True
        self.progress_var.set('解析開始... （大量の画像ではしばらくかかります）')
        self.message_var.set('画像のQR・日時・OSを解析しています。')
        root = self.root_dir
        def worker():
            try:
                def progress(i, total, name):
                    if i % 5 == 0 or i == total:
                        self.events.put(('progress', f'解析中 {i}/{total}：{name}'))
                items = scan_images(directory, root, progress)
                self.events.put(('scanned', items))
            except Exception as exc:
                self.events.put(('failure', str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def _poll_events(self):
        try:
            while True:
                typ, payload = self.events.get_nowait()
                if typ == 'progress':
                    self.progress_var.set(payload)
                elif typ == 'scanned':
                    self.busy = False
                    self.rows = payload
                    warnings = assign_segments(self.rows, self.known)
                    self._refresh_tree()
                    self.progress_var.set(f'解析完了：{len(self.rows)}枚。注意事項 {len(warnings)}件。')
                    self.message_var.set('必要に応じて区間・OSを修正し、コピーを実行してください。')
                    if warnings:
                        messagebox.showwarning('しおりの確認', '\n'.join(warnings[:12]))
                elif typ == 'copied':
                    self.busy = False
                    copies, count, report = payload
                    self._refresh_tree()
                    self.progress_var.set(f'コピー完了 {count}枚 / 対象{len(copies)}枚。履歴：{report}')
                    problems = sum(r['status'] != 'コピー完了' for r in copies)
                    messagebox.showinfo('コピー完了', f'{count}枚をコピーしました。\nエラー・同名衝突: {problems}件\n\nレポート: {report}')
                elif typ == 'failure':
                    self.busy = False
                    self.progress_var.set('')
                    messagebox.showerror('処理失敗', payload)
        except queue.Empty:
            pass
        self.after(130, self._poll_events)

    def _plan(self):
        return plan_rows(self.rows, self.known, self.root_dir)

    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        plan = self._plan()
        counts = Counter()
        for i, (row, status, dest) in enumerate(plan):
            counts[status] += 1
            try:
                from datetime import datetime
                captured = datetime.fromtimestamp(row.timestamp).strftime('%Y-%m-%d %H:%M:%S')
            except Exception:
                captured = '日時不明'
            sid = row.segment_id[:12] if row.segment_id else '-'
            self.tree.insert('', 'end', iid=str(i), values=(i+1, row.path.name, captured, row.time_source,
                                ('しおり ' + row.marker_tag) if row.kind == 'marker' else '画像', sid,
                                row.platform or '-', row.confidence or '-', status),
                             tags=('marker',) if row.kind == 'marker' else ('needs',) if status.startswith('要確認') else ())
        self.summary_var.set(f'総数 {len(plan)} / 分類可能 {counts["分類可能"]} / 要確認 {sum(v for k,v in counts.items() if k.startswith("要確認"))} / しおり {counts["しおり（格納対象外）"]}')

    def _selected_indices(self) -> list[int]:
        return sorted(int(s) for s in self.tree.selection())

    def _keep_selection(self, indexes):
        if not indexes:
            return
        ids = [str(i) for i in indexes if i < len(self.rows)]
        self.tree.selection_set(ids)
        self.tree.see(ids[0])

    def _set_segment(self):
        selected = self._selected_indices()
        if not selected:
            return
        index = self.assign_combo.current()
        if index < 0:
            messagebox.showinfo('区間未選択', '割当先の区間を選択してください。')
            return
        sid = self.sessions[index-1].sid if index else ''
        for i in selected:
            if self.rows[i].kind != 'marker':
                self.rows[i].segment_id = sid
                self.rows[i].manually_set_segment = True
        self._refresh_tree(); self._keep_selection(selected)

    def _set_platform(self, platform: str):
        selected = self._selected_indices()
        if not selected:
            return
        for i in selected:
            if self.rows[i].kind != 'marker':
                self.rows[i].platform = platform
                self.rows[i].manually_set_platform = True
                self.rows[i].confidence = '手動' if platform else '低'
        self._refresh_tree(); self._keep_selection(selected)

    def _apply_sort(self):
        if not self.rows:
            return
        mode = self.sort_var.get()
        if mode == 'IMG連番（ファイル名）':
            matching = sum(bool(re.search(r'(?i)IMG[_ -]?(\d{3,})', r.path.stem)) for r in self.rows)
            if matching != len(self.rows):
                if not messagebox.askyesno('連番のないファイル',
                    f'全{len(self.rows)}枚のうち{len(self.rows)-matching}枚はIMG連番がありません。\n連番のない画像は末尾へ移動します。よろしいですか？'):
                    return
            def key(row):
                found = re.search(r'(?i)IMG[_ -]?(\d{3,})', row.path.stem)
                return (0, int(found.group(1)), str(row.path)) if found else (1, row.timestamp, str(row.path))
            self.rows.sort(key=key)
        elif mode == 'ファイル名':
            self.rows.sort(key=lambda row: (row.path.name.lower(), str(row.path)))
        else:
            self.rows.sort(key=lambda row: (row.timestamp, str(row.path)))
        warnings = assign_segments(self.rows, self.known)
        self._refresh_tree()
        self.message_var.set(f'「{mode}」で並び替えました。しおり対応の注意事項 {len(warnings)}件。')

    def _move(self, direction):
        selected = self._selected_indices()
        if len(selected) != 1:
            messagebox.showinfo('選択', '撮影順を変更する画像を1枚選択してください。')
            return
        index = selected[0]
        next_pos = index + direction
        if next_pos < 0 or next_pos >= len(self.rows):
            return
        self.rows[index], self.rows[next_pos] = self.rows[next_pos], self.rows[index]
        assign_segments(self.rows, self.known)
        self._refresh_tree()
        self._keep_selection([next_pos])

    def _reassign(self):
        warnings = assign_segments(self.rows, self.known)
        self._refresh_tree()
        self.message_var.set(f'しおりに基づき再判定しました。注意 {len(warnings)}件。手動修正は保持しています。')

    def _toggle_skip(self):
        selected = self._selected_indices()
        if not selected:
            return
        for i in selected:
            if self.rows[i].kind != 'marker':
                self.rows[i].skipped = not self.rows[i].skipped
        self._refresh_tree(); self._keep_selection(selected)

    def _on_image_selected(self, _event=None):
        indexes = self._selected_indices()
        if not indexes:
            return
        row = self.rows[indexes[0]]
        current_plan = self._plan()[indexes[0]]
        info = [f'ファイル: {row.path.name}', f'パス: {row.path}',
                f'区間: {row.segment_id or "未指定"}', f'OS: {row.platform or "未判定"}',
                f'判定: {current_plan[1]}', f'理由: {row.detail}',
                f'格納予定先: {current_plan[2] if current_plan[2] else "なし"}']
        self.item_info.configure(state='normal')
        self.item_info.delete('1.0', tk.END)
        self.item_info.insert('1.0', '\n'.join(info))
        self.item_info.configure(state='disabled')
        try:
            with Image.open(row.path) as opened:
                pic = ImageOps.exif_transpose(opened)
                pic.thumbnail((240, 140))
                self.preview_photo = ImageTk.PhotoImage(pic.convert('RGB'))
            self.image_preview.config(image=self.preview_photo, text='')
        except Exception:
            self.image_preview.config(image='', text='プレビュー不可（画像形式または破損）')

    def _save_plan_report(self):
        if not self.rows:
            messagebox.showinfo('未取込', '画像を先にスキャンしてください。')
            return
        try:
            report = save_report(self.root_dir, self._plan(), [])
            messagebox.showinfo('CSV出力', f'分類計画を出力しました。\n{report}')
        except Exception as e:
            messagebox.showerror('出力エラー', str(e))

    def _start_copy(self):
        if self.busy or not self.rows:
            return
        plan = self._plan()
        counts = Counter(status for _, status, _ in plan)
        count = counts['分類可能']
        if not count:
            messagebox.showwarning('コピー対象なし', '分類可能な画像がありません。要確認の画像を修正してください。')
            return
        unresolved = sum(v for k,v in counts.items() if k.startswith('要確認'))
        proceed = messagebox.askyesno('コピーの確認',
            f'分類可能: {count}枚\n要確認（コピーしない）: {unresolved}枚\n\n画像は元の名前・拡張子・内容を変更せず、指定フォルダへコピーします。\n元画像もそのまま残ります。\n\n実行しますか？')
        if not proceed:
            return
        self.busy = True
        self.progress_var.set('コピー中...')
        root = self.root_dir
        def worker():
            try:
                def progress(i, total, name):
                    if i % 10 == 0 or i == total:
                        self.events.put(('progress', f'コピー中 {i}/{total}：{name}'))
                copied, total = copy_approved(plan, progress)
                report = save_report(root, plan, copied)
                self.events.put(('copied', (copied, total, report)))
            except Exception as ex:
                self.events.put(('failure', str(ex)))
        threading.Thread(target=worker, daemon=True).start()


def main():
    app = EvidenceApp()
    app.mainloop()

if __name__ == '__main__':
    main()
