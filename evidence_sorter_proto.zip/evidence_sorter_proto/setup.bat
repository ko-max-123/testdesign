@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m pip install -r requirements.txt
  goto :end
)

where python >nul 2>nul
if %errorlevel%==0 (
  python -m pip install -r requirements.txt
  goto :end
)

echo Python was not found.
pause

:end
pause
endlocal
