from __future__ import annotations

import os
import re
import shutil
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from PIL import Image, ImageOps, ImageStat, ImageTk, ExifTags
except ImportError:
    Image = None
    ImageOps = None
    ImageStat = None
    ImageTk = None
    ExifTags = None


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".heic", ".heif", ".webp", ".bmp", ".tif", ".tiff"}
PHOTO_EXTS = {".jpg", ".jpeg", ".heic", ".heif"}


@dataclass
class EvidenceItem:
    path: Path
    category: str = "未判定"
    reason: str = ""
    bookmark_score: int = 0
    width: int = 0
    height: int = 0
    exif_camera: bool = False


class EvidenceSorterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Evidence Sorter Prototype")
        self.geometry("1180x760")
        self.minsize(980, 650)

        self.folder: Optional[Path] = None
        self.items: List[EvidenceItem] = []
        self.preview_img = None

        self.sort_mode = tk.StringVar(value="name")
        self.bookmark_threshold = tk.IntVar(value=72)
        self.prefix_seq = tk.BooleanVar(value=True)
        self.copy_bookmark = tk.BooleanVar(value=True)

        self._build_ui()

    def _build_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        ttk.Button(top, text="1. フォルダ選択", command=self.choose_folder).pack(side="left")
        self.folder_label = ttk.Label(top, text="未選択", width=60)
        self.folder_label.pack(side="left", padx=10)
        ttk.Button(top, text="2. 解析", command=self.analyze).pack(side="left", padx=(0, 8))
        ttk.Button(top, text="3. 分別実行", command=self.execute_sort).pack(side="left")

        opts = ttk.LabelFrame(self, text="設定", padding=8)
        opts.pack(fill="x", padx=10, pady=(0, 8))

        ttk.Label(opts, text="並び順:").pack(side="left")
        ttk.Radiobutton(opts, text="ファイル名順（推奨）", variable=self.sort_mode, value="name").pack(side="left", padx=(4, 10))
        ttk.Radiobutton(opts, text="更新日時順", variable=self.sort_mode, value="mtime").pack(side="left", padx=(0, 12))

        ttk.Label(opts, text="栞判定しきい値:").pack(side="left")
        ttk.Spinbox(opts, from_=50, to=95, width=5, textvariable=self.bookmark_threshold).pack(side="left", padx=(4, 12))
        ttk.Checkbutton(opts, text="連番を付ける", variable=self.prefix_seq).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(opts, text="栞も保存", variable=self.copy_bookmark).pack(side="left")

        main = ttk.Panedwindow(self, orient="horizontal")
        main.pack(fill="both", expand=True, padx=10, pady=(0, 8))

        left = ttk.Frame(main)
        right = ttk.Frame(main, padding=(10, 0, 0, 0))
        main.add(left, weight=3)
        main.add(right, weight=2)

        columns = ("no", "name", "type", "score", "reason")
        self.tree = ttk.Treeview(left, columns=columns, show="headings", selectmode="extended")
        self.tree.heading("no", text="#")
        self.tree.heading("name", text="ファイル")
        self.tree.heading("type", text="判定")
        self.tree.heading("score", text="栞score")
        self.tree.heading("reason", text="理由")
        self.tree.column("no", width=45, anchor="center")
        self.tree.column("name", width=250)
        self.tree.column("type", width=100, anchor="center")
        self.tree.column("score", width=75, anchor="center")
        self.tree.column("reason", width=350)
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        scroll = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scroll.set)

        self.preview = ttk.Label(right, text="画像プレビュー", anchor="center", relief="solid")
        self.preview.pack(fill="both", expand=True)

        manual = ttk.LabelFrame(right, text="手動補正（選択行）", padding=8)
        manual.pack(fill="x", pady=(8, 0))
        ttk.Button(manual, text="栞", command=lambda: self.set_category("栞")).pack(side="left", padx=3)
        ttk.Button(manual, text="iOS", command=lambda: self.set_category("iOS")).pack(side="left", padx=3)
        ttk.Button(manual, text="Android", command=lambda: self.set_category("Android")).pack(side="left", padx=3)
        ttk.Button(manual, text="不明", command=lambda: self.set_category("不明")).pack(side="left", padx=3)

        help_text = (
            "判定方針: 栞候補 → iOSメモのような白背景・低彩度スクショをヒューリスティック判定。\n"
            "iOS → 主にPNGスクショ。 Android → iPhoneカメラ写真（EXIF/HEIC/JPEG優先）。\n"
            "栞の誤判定は分別前に手動補正できます。元画像は移動せずコピーします。"
        )
        ttk.Label(right, text=help_text, wraplength=420, justify="left").pack(fill="x", pady=(8, 0))

        self.status = ttk.Label(self, text="準備完了", anchor="w", padding=(10, 5))
        self.status.pack(fill="x")

    def choose_folder(self):
        selected = filedialog.askdirectory(title="エビデンス画像フォルダを選択")
        if not selected:
            return
        self.folder = Path(selected)
        self.folder_label.config(text=str(self.folder))
        self.status.config(text="フォルダを選択しました。『解析』を押してください。")

    @staticmethod
    def natural_key(path: Path):
        parts = re.split(r"(\d+)", path.name.lower())
        return [int(p) if p.isdigit() else p for p in parts]

    def analyze(self):
        if not self.folder:
            messagebox.showwarning("確認", "先にフォルダを選択してください。")
            return
        self.status.config(text="解析中...")
        threading.Thread(target=self._analyze_worker, daemon=True).start()

    def _analyze_worker(self):
        files = [p for p in self.folder.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS and "_sorted" not in p.parts]
        if self.sort_mode.get() == "mtime":
            files.sort(key=lambda p: (p.stat().st_mtime, self.natural_key(p)))
        else:
            files.sort(key=self.natural_key)

        items = []
        threshold = self.bookmark_threshold.get()
        for path in files:
            items.append(self.classify(path, threshold))

        self.items = items
        self.after(0, self._refresh_tree)

    def classify(self, path: Path, threshold: int) -> EvidenceItem:
        ext = path.suffix.lower()
        item = EvidenceItem(path=path)

        # HEIC/HEIF is almost certainly an iPhone camera photo in this workflow.
        if ext in {".heic", ".heif"}:
            item.category = "Android"
            item.reason = "HEIC/HEIF = iPhoneカメラ撮影候補"
            return item

        if Image is None:
            if ext == ".png":
                item.category = "iOS"
                item.reason = "Pillow未導入: PNGをiOS候補として仮判定"
            elif ext in PHOTO_EXTS:
                item.category = "Android"
                item.reason = "Pillow未導入: 写真拡張子をAndroid候補として仮判定"
            else:
                item.category = "不明"
                item.reason = "Pillow未導入"
            return item

        try:
            with Image.open(path) as im:
                item.width, item.height = im.size
                item.exif_camera = self._has_camera_exif(im)

                if item.exif_camera:
                    item.category = "Android"
                    item.reason = "カメラEXIFあり"
                    return item

                # JPEG without camera EXIF still tends to be a photo/exported photo.
                if ext in {".jpg", ".jpeg"}:
                    item.category = "Android"
                    item.reason = "JPEG写真候補（EXIFなし）"
                    return item

                # PNG is treated as screenshot candidate. Try bookmark heuristic first.
                if ext == ".png":
                    score, detail = self._bookmark_score(im)
                    item.bookmark_score = score
                    if score >= threshold:
                        item.category = "栞"
                        item.reason = f"白背景/低彩度/文字中心のスクショ候補: {detail}"
                    else:
                        item.category = "iOS"
                        item.reason = f"PNGスクショ候補: {detail}"
                    return item

                item.category = "不明"
                item.reason = f"拡張子 {ext}"
                return item
        except Exception as e:
            item.category = "不明"
            item.reason = f"画像解析不可: {type(e).__name__}"
            return item

    @staticmethod
    def _has_camera_exif(im) -> bool:
        try:
            exif = im.getexif()
            if not exif:
                return False
            # 271 Make, 272 Model, 36867 DateTimeOriginal, 37386 FocalLength
            camera_tags = {271, 272, 36867, 37386, 33434, 34855}
            return any(tag in exif and exif.get(tag) not in (None, "") for tag in camera_tags)
        except Exception:
            return False

    @staticmethod
    def _bookmark_score(im):
        # Notes-like heuristic: bright background, low colorfulness, sparse dark ink,
        # and a bright center. Works for both typed and handwritten memo screenshots.
        rgb = im.convert("RGB")
        thumb = ImageOps.contain(rgb, (240, 480))
        stat = ImageStat.Stat(thumb)
        mean_r, mean_g, mean_b = stat.mean
        mean_brightness = (mean_r + mean_g + mean_b) / 3
        colorfulness = (abs(mean_r - mean_g) + abs(mean_g - mean_b) + abs(mean_b - mean_r)) / 3

        gray = thumb.convert("L")
        px = list(gray.getdata())
        n = max(1, len(px))
        bright_ratio = sum(1 for v in px if v >= 235) / n
        dark_ratio = sum(1 for v in px if v <= 180) / n

        w, h = gray.size
        crop = gray.crop((int(w * 0.12), int(h * 0.18), int(w * 0.88), int(h * 0.82)))
        center_mean = ImageStat.Stat(crop).mean[0]

        score = 0
        if bright_ratio >= 0.65:
            score += 35
        elif bright_ratio >= 0.50:
            score += 25
        elif bright_ratio >= 0.38:
            score += 12

        if colorfulness <= 18:
            score += 25
        elif colorfulness <= 30:
            score += 16
        elif colorfulness <= 45:
            score += 8

        if 0.01 <= dark_ratio <= 0.22:
            score += 20
        elif dark_ratio < 0.01:
            score += 8
        elif dark_ratio <= 0.32:
            score += 10

        if center_mean >= 225:
            score += 20
        elif center_mean >= 205:
            score += 12

        score = min(100, score)
        detail = f"明部{bright_ratio:.0%}, 暗部{dark_ratio:.0%}, 彩度差{colorfulness:.1f}, 中央{center_mean:.0f}"
        return score, detail

    def _refresh_tree(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for i, item in enumerate(self.items, 1):
            self.tree.insert("", "end", iid=str(i - 1), values=(i, item.path.name, item.category, item.bookmark_score, item.reason))
        self.status.config(text=f"解析完了: {len(self.items)}枚。栞候補を確認後、『分別実行』してください。")

    def on_select(self, _event=None):
        sel = self.tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        item = self.items[idx]
        if Image is None or ImageTk is None:
            self.preview.config(text=f"{item.path.name}\nPillow未導入のためプレビュー不可", image="")
            return
        try:
            with Image.open(item.path) as im:
                im = ImageOps.exif_transpose(im).convert("RGB")
                im.thumbnail((430, 520))
                self.preview_img = ImageTk.PhotoImage(im)
                self.preview.config(image=self.preview_img, text="")
        except Exception:
            self.preview.config(text=f"プレビューできません\n{item.path.name}", image="")

    def set_category(self, category: str):
        sel = self.tree.selection()
        if not sel:
            return
        for iid in sel:
            idx = int(iid)
            self.items[idx].category = category
            self.items[idx].reason = "手動補正"
            vals = list(self.tree.item(iid, "values"))
            vals[2] = category
            vals[4] = "手動補正"
            self.tree.item(iid, values=vals)
        self.status.config(text=f"{len(sel)}件を「{category}」に変更しました。")

    def execute_sort(self):
        if not self.folder or not self.items:
            messagebox.showwarning("確認", "先にフォルダを選択して解析してください。")
            return
        if not messagebox.askyesno("分別実行", "元画像は残したまま、_sorted フォルダへコピーします。実行しますか？"):
            return
        try:
            out = self.folder / "_sorted"
            out.mkdir(exist_ok=True)
            current_group = 0
            seq = {"iOS": 0, "Android": 0, "不明": 0, "栞": 0}
            seen_bookmark = False

            for item in self.items:
                if item.category == "栞":
                    current_group += 1
                    seen_bookmark = True
                    seq = {"iOS": 0, "Android": 0, "不明": 0, "栞": 0}
                    if self.copy_bookmark.get():
                        dest_dir = out / f"Group_{current_group:03d}" / "bookmark"
                        self._copy_with_seq(item.path, dest_dir, seq, "栞")
                    continue

                group_name = f"Group_{current_group:03d}" if seen_bookmark else "Before_First_Bookmark"
                dest_dir = out / group_name / (item.category if item.category in {"iOS", "Android"} else "Unknown")
                key = item.category if item.category in seq else "不明"
                self._copy_with_seq(item.path, dest_dir, seq, key)

            messagebox.showinfo("完了", f"分別が完了しました。\n\n出力先:\n{out}")
            self.status.config(text=f"分別完了: {out}")
        except Exception as e:
            messagebox.showerror("エラー", f"分別中にエラーが発生しました。\n{e}")

    def _copy_with_seq(self, src: Path, dest_dir: Path, seq: dict, key: str):
        dest_dir.mkdir(parents=True, exist_ok=True)
        seq[key] += 1
        if self.prefix_seq.get():
            name = f"{seq[key]:03d}_{src.name}"
        else:
            name = src.name
        dest = dest_dir / name
        n = 1
        while dest.exists():
            dest = dest_dir / f"{dest.stem}_{n}{dest.suffix}"
            n += 1
        shutil.copy2(src, dest)


if __name__ == "__main__":
    app = EvidenceSorterApp()
    app.mainloop()
