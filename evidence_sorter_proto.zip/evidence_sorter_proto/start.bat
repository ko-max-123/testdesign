@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 app.py
  goto :end
)

where python >nul 2>nul
if %errorlevel%==0 (
  python app.py
  goto :end
)

echo Python was not found.
echo Please install Python 3 and try again.
pause

:end
endlocal
