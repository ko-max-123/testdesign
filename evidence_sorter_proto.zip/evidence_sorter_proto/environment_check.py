import sys
import tkinter
print('Python:', sys.version)
print('Tkinter: OK')
try:
    import PIL
    print('Pillow:', PIL.__version__)
except Exception:
    print('Pillow: NOT INSTALLED')
