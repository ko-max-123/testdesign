from pathlib import Path
import hashlib
import os
import sys
import pytest
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from evidence_core import (Segment, component, make_marker, read_qr, ImageItem, assign_segments,
                           os_classification, plan_rows, exclusive_copy, copy_approved,
                           load_sessions, save_sessions)


def test_segment_path_and_validation(tmp_path):
    seg = Segment.create('案件', 'テスト.xlsx', 'P1-1', 'ID-2')
    assert seg.folder(tmp_path, 'And') == tmp_path/'エビデンス'/'案件'/'テスト.xlsx'/'P1-1'/'ID-2'/'And'
    assert seg.folder(tmp_path, 'iOS').parts[-1] == 'iOS'
    assert Segment.create('案件', 'テスト.xlsx', 'P1-1').folder(tmp_path,'iOS').parts[-2] == 'P1-1'
    with pytest.raises(ValueError):
        Segment.create('../secrets', 'a', 'b')
    with pytest.raises(ValueError):
        Segment.create('abc', 'CON', 'b')
    save_sessions(tmp_path, [seg])
    assert load_sessions(tmp_path)[0] == seg


def test_qr_marker(tmp_path):
    seg = Segment.create('案件', 'テスト.xlsx', 'P1-1')
    start = make_marker(tmp_path, seg, 'START')
    end = make_marker(tmp_path, seg, 'END')
    a, e = read_qr(start)
    assert e is None
    assert a == (seg.sid, 'START')
    a, e = read_qr(end)
    assert a == (seg.sid, 'END')


def test_assign_and_copy_filename_preserved(tmp_path):
    seg = Segment.create('決済', '仕様書A.xlsx', 'CASE-1')
    known = {seg.sid:seg}
    source = tmp_path/'in'; source.mkdir()
    a = source/'IMG_0002.PNG'; a.write_bytes(b'png original bytes')
    b = source/'IMG_0003.JPG'; b.write_bytes(b'jpg original bytes')
    rows = [ImageItem(source/'start.jpg', 1, '更新日時', kind='marker', segment_id=seg.sid, marker_tag='START'),
            ImageItem(a, 2, '更新日時', platform='iOS'),
            ImageItem(b, 3, '更新日時', platform='And'),
            ImageItem(source/'end.jpg', 4, '更新日時', kind='marker', segment_id=seg.sid, marker_tag='END')]
    assert assign_segments(rows,known) == []
    assert rows[1].segment_id == seg.sid and rows[2].segment_id == seg.sid
    plan = plan_rows(rows,known,tmp_path)
    assert sum(status == '分類可能' for _,status,_ in plan) == 2
    written, n = copy_approved(plan)
    assert n == 2
    assert (seg.folder(tmp_path,'iOS')/a.name).read_bytes() == a.read_bytes()
    assert (seg.folder(tmp_path,'And')/b.name).read_bytes() == b.read_bytes()
    assert sorted(p.name for p in source.iterdir()) == ['IMG_0002.PNG','IMG_0003.JPG']
    new_plan = plan_rows(rows,known,tmp_path)
    assert sum('同名ファイル' in s for _,s,_ in new_plan) == 2
    _, n = copy_approved(new_plan)
    assert n == 0


def test_collision_within_same_run(tmp_path):
    seg = Segment.create('決済', '仕様書.xlsx', 'P1-1')
    a = tmp_path/'fromA'/'IMG_0100.PNG'
    b = tmp_path/'fromB'/'IMG_0100.PNG'
    a.parent.mkdir(); b.parent.mkdir()
    a.write_bytes(b'different A'); b.write_bytes(b'different B')
    rows = [ImageItem(a,1,'更新日時',segment_id=seg.sid,platform='iOS'),
            ImageItem(b,2,'更新日時',segment_id=seg.sid,platform='iOS')]
    plan = plan_rows(rows,{seg.sid:seg},tmp_path)
    assert all('同じ格納先に同名画像' in status for _,status,_ in plan)
    assert not any(d.exists() for _,s,d in plan if d)


def test_os_guess(tmp_path):
    assert os_classification(tmp_path/'IMG_1001.heic')[0] == 'And'
    assert os_classification(tmp_path/'IMG_1002.png')[0] == 'iOS'
    assert os_classification(tmp_path/'Screenshot_20261026_202019.jpg')[0] == 'iOS'
    assert os_classification(tmp_path/'unknown.webp')[0] == ''


def test_missing_end_and_manual_override(tmp_path):
    seg = Segment.create('機能', 'テスト.xlsx', 'S1')
    rows = [ImageItem(tmp_path/'start.jpg',1,'mtime',kind='marker',segment_id=seg.sid,marker_tag='START'),
            ImageItem(tmp_path/'IMG.png',2,'mtime',platform='iOS',segment_id='foo',manually_set_segment=True)]
    warnings = assign_segments(rows,{seg.sid:seg})
    assert warnings and '終了しおり' in warnings[0]
    assert rows[1].segment_id == 'foo'
