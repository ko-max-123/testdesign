from pathlib import Path
import json
import sys
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from excel_catalog import WorkbookCatalog, save_catalogs, load_catalogs, col_label, col_number
from evidence_core import Segment, make_marker, read_qr, save_sessions, load_sessions

DEMOS=Path(__file__).resolve().parents[1]/'デモデータ'/'決済機能'


def test_both_sample_formats_auto_detected():
    a=WorkbookCatalog.from_file(DEMOS/'仕様書_シナリオ型.xlsx')
    assert a.feature=='決済機能'
    assert a.spec=='仕様書_シナリオ型.xlsx'
    sheet=a.sheets[0]
    assert (sheet.scenario_col,sheet.expected_col,sheet.header_row)==(2,1,1)
    assert sheet.ids_for('P1-1')==['1','2','3','4']
    assert sheet.ids_for('P1-2')==['5','6','7']
    assert '行2' in sheet.short_preview('P1-1','1','3')
    assert '行5' not in sheet.short_preview('P1-1','1','3')
    b=WorkbookCatalog.from_file(DEMOS/'仕様書_複数手順型.xlsx')
    sh=b.sheets[0]
    assert (sh.scenario_col,sh.expected_col)==(2,1)
    assert sh.ids_for('2')==['2','3']
    assert '再開動作' in sh.short_preview('2','2','3')


def test_manual_mapping_and_save_reload(tmp_path):
    c=WorkbookCatalog.from_file(DEMOS/'仕様書_シナリオ型.xlsx')
    sheet=c.sheets[0]
    sheet.expected_col=3 # SID alternate identifier
    assert sheet.ids_for('P1-1')==['S1-1','S1-2','S1-3','S1-4']
    save_catalogs(tmp_path,[c])
    restored=load_catalogs(tmp_path)
    assert len(restored)==1
    assert restored[0].sheets[0].expected_col==3
    assert restored[0].sheets[0].ids_for('P1-1')==sheet.ids_for('P1-1')


def test_section_expected_range_is_metadata_not_filename(tmp_path):
    s=Segment.create('決済機能','テスト.xlsx','P1-1',expect_start='3',expect_end='7',source_sheet='検証')
    assert s.folder(tmp_path,'And')==tmp_path/'エビデンス'/'決済機能'/'テスト.xlsx'/'P1-1'/'And'
    assert '期待値ID 3 ～ 7' in s.label()
    save_sessions(tmp_path,[s])
    saved=load_sessions(tmp_path)
    assert (saved[0].expect_start,saved[0].expect_end,saved[0].source_sheet)==('3','7','検証')
    assert read_qr(make_marker(tmp_path,s,'START'))[0]==(s.sid,'START')


def test_read_v01_existing_sessions(tmp_path):
    c=tmp_path/'管理データ';c.mkdir()
    (c/'segments.json').write_text(json.dumps({'schema':1,'segments':[
        {'sid':'123456789abc','feature':'F','spec':'spec.xlsx','scenario':'S', 'item_id':'E', 'created_at':'2026-10-26T00:00:00'}
    ]}),encoding='utf-8')
    seg=load_sessions(tmp_path)[0]
    assert seg.expect_start=='' and seg.item_id=='E'
    assert seg.folder(tmp_path,'iOS').parts[-2:] == ('E','iOS')


def test_col_supports_aa_and_beyond():
    assert col_number('AA321')==27
    assert col_label(27)=='AA'
