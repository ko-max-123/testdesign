"""Evidence Organizer v0.2 - offline Windows-oriented Tkinter GUI."""
from __future__ import annotations

import queue
import threading
import re
from collections import Counter
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk, ImageOps

from excel_catalog import WorkbookCatalog, save_catalogs, load_catalogs, col_label
from evidence_core import (
    Segment, ImageItem, load_sessions, save_sessions, make_marker, scan_images,
    assign_segments, plan_rows, copy_approved, save_report, workspace_paths,
    HEIF_AVAILABLE, QR_AVAILABLE
)


class EvidenceApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Evidence Organizer  |  Excel連動・しおり・画像自動仕分け  v0.2')
        self.geometry('1370x890')
        self.minsize(940, 630)
        self.option_add('*Font', ('Yu Gothic UI', 10))
        self.style = ttk.Style(self)
        if 'vista' in self.style.theme_names():
            self.style.theme_use('vista')
        self.style.configure('Title.TLabel', font=('Yu Gothic UI', 15, 'bold'))
        self.style.configure('Accent.TButton', padding=(10, 7))
        self.style.configure('Info.TLabel', foreground='#506273')
        self.style.configure('Treeview', rowheight=29)
        self.style.configure('TNotebook.Tab', padding=(13, 7))

        self.workspace_var = tk.StringVar(value=str(Path.home() / 'EvidenceOrganizer作業'))
        self.import_var = tk.StringVar()
        self.feature_var = tk.StringVar()
        self.spec_var = tk.StringVar()
        self.scenario_var = tk.StringVar()
        self.item_var = tk.StringVar()
        self.expect_start_var = tk.StringVar()
        self.expect_end_var = tk.StringVar()
        self.catalog_choice_var = tk.StringVar()
        self.sheet_var = tk.StringVar()
        self.include_id_var = tk.BooleanVar(value=False)
        self.excel_status_var = tk.StringVar(value='Excel未読込：手入力でもしおりを作成できます')
        self.catalogs: list[WorkbookCatalog] = []
        self.active_catalog = None
        self.assign_var = tk.StringVar()
        self.sort_var = tk.StringVar(value='撮影日時（自動）')
        self.message_var = tk.StringVar(value='作業フォルダを選択してください。')
        self.summary_var = tk.StringVar(value='画像未取り込み')
        self.progress_var = tk.StringVar(value='')
        self.sessions: list[Segment] = []
        self.rows: list[ImageItem] = []
        self.current_sid = ''
        self.busy = False
        self.events: queue.Queue = queue.Queue()
        self.preview_photo = None
        self.marker_photo = None
        self._build_ui()
        self._load_workspace()
        self.after(110, self._poll_events)

    @property
    def root_dir(self) -> Path:
        return Path(self.workspace_var.get()).expanduser().resolve()

    @property
    def known(self) -> dict[str, Segment]:
        return {seg.sid: seg for seg in self.sessions}

    def _build_ui(self):
        top = ttk.Frame(self, padding=(16, 13))
        top.pack(fill='x')
        ttk.Label(top, text='Evidence Organizer', style='Title.TLabel').pack(side='left', padx=(0, 20))
        ttk.Label(top, text='作業フォルダ').pack(side='left')
        ttk.Entry(top, textvariable=self.workspace_var, state='readonly').pack(side='left', fill='x', expand=True, padx=7)
        ttk.Button(top, text='選択...', command=self._choose_workspace).pack(side='left', padx=4)
        ttk.Button(top, text='読込', command=self._load_workspace).pack(side='left')

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill='both', expand=True, padx=15, pady=(2, 8))
        self.marker_page = ttk.Frame(self.tabs, padding=15)
        self.sort_page = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(self.marker_page, text='1   Excel読込・しおり作成')
        self.tabs.add(self.sort_page, text='2   画像の仕分け・確認')
        self._build_marker_ui()
        self._build_sort_ui()
        bar = ttk.Frame(self, padding=(15, 5, 15, 12))
        bar.pack(fill='x')
        ttk.Label(bar, textvariable=self.message_var, foreground='#42566c').pack(side='left', fill='x', expand=True)
        ttk.Label(bar, text=f'HEIC対応: {"あり" if HEIF_AVAILABLE else "なし"} / QR解析: {"あり" if QR_AVAILABLE else "なし"}', style='Info.TLabel').pack(side='right')

    def _build_marker_ui(self):
        root = self.marker_page
        ttk.Label(root, text='Excelから案件・仕様書・シナリオ・期待値IDを選択', style='Title.TLabel').pack(anchor='w', pady=(1, 4))
        ttk.Label(root, text='画像1枚ずつのID設定も、撮影枚数の指定も不要。区間を開始ID～終了IDで指定して、しおりを撮影します。', style='Info.TLabel').pack(anchor='w', pady=(0, 9))
        excel = ttk.LabelFrame(root, text='Step 1  テスト仕様書の読み込み', padding=9)
        excel.pack(fill='x', pady=(0, 8))
        ttk.Button(excel, text='Excelを追加（複数可）...', command=self._add_spec_files).grid(row=0, column=0, padx=(0, 8), pady=3, sticky='w')
        ttk.Label(excel, text='仕様書').grid(row=0, column=1, sticky='e')
        self.catalog_combo = ttk.Combobox(excel, textvariable=self.catalog_choice_var, state='readonly', width=46)
        self.catalog_combo.grid(row=0, column=2, columnspan=3, sticky='ew', padx=6)
        self.catalog_combo.bind('<<ComboboxSelected>>', self._on_catalog_selected)
        ttk.Label(excel, text='シート').grid(row=1, column=1, sticky='e')
        self.sheet_combo = ttk.Combobox(excel, textvariable=self.sheet_var, state='readonly', width=23)
        self.sheet_combo.grid(row=1, column=2, sticky='w', padx=6, pady=3)
        self.sheet_combo.bind('<<ComboboxSelected>>', self._on_sheet_selected)
        ttk.Button(excel, text='列の対応変更...', command=self._mapping_dialog).grid(row=1, column=3, padx=8, sticky='w')
        ttk.Label(excel, textvariable=self.excel_status_var, style='Info.TLabel').grid(row=2, column=0, columnspan=5, sticky='w', pady=(3,0))
        excel.columnconfigure(2, weight=1)

        form = ttk.LabelFrame(root, text='Step 2  区間に対応する期待値IDを選択', padding=10)
        form.pack(fill='x', pady=(0, 8))
        form.columnconfigure(1, weight=1)
        ttk.Label(form, text='機能（案件名）', width=22).grid(row=0, column=0, sticky='w', pady=4)
        ttk.Entry(form, textvariable=self.feature_var).grid(row=0, column=1, columnspan=2, sticky='ew', padx=(4,10), pady=3)
        ttk.Label(form, text='仕様書（元ファイル名）').grid(row=1, column=0, sticky='w', pady=4)
        ttk.Entry(form, textvariable=self.spec_var).grid(row=1, column=1, columnspan=2, sticky='ew', padx=(4,10), pady=3)
        ttk.Label(form, text='シナリオID').grid(row=2, column=0, sticky='w', pady=4)
        self.scenario_combo = ttk.Combobox(form, textvariable=self.scenario_var, state='normal')
        self.scenario_combo.grid(row=2, column=1, columnspan=2, sticky='ew', padx=(4,10), pady=3)
        self.scenario_combo.bind('<<ComboboxSelected>>', self._on_scenario_selected)
        ttk.Label(form, text='期待値ID（開始～終了）').grid(row=3, column=0, sticky='w', pady=4)
        id_row = ttk.Frame(form)
        id_row.grid(row=3, column=1, columnspan=2, sticky='ew', pady=3, padx=(4,10))
        id_row.columnconfigure(0, weight=1)
        id_row.columnconfigure(2, weight=1)
        self.expect_start_combo = ttk.Combobox(id_row, textvariable=self.expect_start_var, state='normal')
        self.expect_start_combo.grid(row=0, column=0, sticky='ew')
        ttk.Label(id_row, text=' ～ ').grid(row=0, column=1)
        self.expect_end_combo = ttk.Combobox(id_row, textvariable=self.expect_end_var, state='normal')
        self.expect_end_combo.grid(row=0, column=2, sticky='ew')
        self.expect_start_combo.bind('<<ComboboxSelected>>', self._on_expected_selected)
        self.expect_end_combo.bind('<<ComboboxSelected>>', self._on_expected_selected)
        folder_row = ttk.Frame(form)
        folder_row.grid(row=4, column=0, columnspan=3, sticky='ew', pady=(5, 2))
        ttk.Checkbutton(folder_row, text='シナリオIDの下にIDフォルダを作る場合のみ指定', variable=self.include_id_var,
                        command=self._on_toggle_id_folder).pack(side='left')
        self.folder_id_entry = ttk.Entry(folder_row, textvariable=self.item_var, width=25, state='disabled')
        self.folder_id_entry.pack(side='left', padx=9)
        ttk.Label(folder_row, text='通常はオフ（期待値IDはしおりにだけ記録）', style='Info.TLabel').pack(side='left')

        preview_row = ttk.Frame(form)
        preview_row.grid(row=5, column=0, columnspan=3, sticky='nsew', pady=(5, 0))
        ttk.Label(preview_row, text='選択範囲のExcel行:', width=22).pack(side='left', anchor='n')
        self.expected_preview = tk.Text(preview_row, height=3, wrap='word', font=('Yu Gothic UI', 9), state='disabled', foreground='#42566c')
        self.expected_preview.pack(side='left', fill='both', expand=True, padx=(0,10))
        controls = ttk.Frame(form)
        controls.grid(row=6, column=1, columnspan=2, sticky='w', pady=(7, 0))
        ttk.Button(controls, text='この範囲の開始・終了しおりを自動生成', style='Accent.TButton', command=self._add_segment).pack(side='left')
        ttk.Button(controls, text='期待値IDをクリア', command=self._clear_scenario).pack(side='left', padx=8)

        lower = ttk.LabelFrame(root, text='Step 3  登録済み撮影区間（同じIDの区間は何度でも登録可能）', padding=10)
        lower.pack(fill='both', expand=True)
        self.segment_list = tk.Listbox(lower, height=6, activestyle='none', exportselection=False)
        self.segment_list.pack(fill='both', expand=True)
        self.segment_list.bind('<<ListboxSelect>>', self._on_segment_selected)
        actions = ttk.Frame(lower)
        actions.pack(fill='x', pady=(9, 0))
        ttk.Button(actions, text='開始しおりを表示', command=lambda:self._open_marker('START')).pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='終了しおりを表示', command=lambda:self._open_marker('END')).pack(side='left')
        ttk.Button(actions, text='しおり保存先を開く', command=self._open_marker_folder).pack(side='left', padx=8)
        ttk.Label(lower, text='開始しおり撮影 → iOSスクショ・Androidカメラ撮影（枚数自由） → 終了しおり撮影', style='Info.TLabel').pack(side='left', padx=(14,0))

    def _refresh_catalog_combo(self, select_source=None):
        labels = [f'{c.spec}  |  {Path(c.source).parent.name}' for c in self.catalogs]
        self.catalog_combo['values'] = labels
        if not self.catalogs:
            self.active_catalog = None
            self.catalog_choice_var.set('')
            self.sheet_combo['values'] = []
            return
        selected = 0
        if select_source:
            selected = next((i for i,c in enumerate(self.catalogs) if c.source == select_source),0)
        self.catalog_combo.current(selected)
        self._on_catalog_selected()

    def _add_spec_files(self):
        files = filedialog.askopenfilenames(title='テスト仕様書（.xlsx / .xlsm）を選択（複数選択可能）',
                                             filetypes=[('Excel', '*.xlsx *.xlsm'),('すべて', '*.*')])
        if not files:
            return
        successful = []
        errors = []
        for name in files:
            try:
                catalog = WorkbookCatalog.from_file(Path(name))
                self.catalogs = [item for item in self.catalogs if item.source != catalog.source]
                self.catalogs.append(catalog)
                successful.append(catalog.source)
            except Exception as e:
                errors.append(f'{Path(name).name}: {e}')
        if successful:
            save_catalogs(self.root_dir, self.catalogs)
            self._refresh_catalog_combo(select_source=successful[-1])
            self.message_var.set(f'Excel {len(successful)}冊から選択候補を生成しました。')
        if errors:
            messagebox.showwarning('読み取れないExcelがあります', '\n'.join(errors[:12]))

    def _on_catalog_selected(self, _event=None):
        index = self.catalog_combo.current()
        if index < 0 or index >= len(self.catalogs):
            return
        catalog = self.catalogs[index]
        self.active_catalog = catalog
        self.feature_var.set(catalog.feature)
        self.spec_var.set(catalog.spec)
        names = [sheet.name for sheet in catalog.sheets]
        self.sheet_combo['values'] = names
        if names:
            self.sheet_combo.current(0)
            self._on_sheet_selected()

    def _active_sheet(self):
        if self.active_catalog is None:
            return None
        return self.active_catalog.sheet(self.sheet_var.get())

    def _on_sheet_selected(self, _event=None):
        sh = self._active_sheet()
        if not sh:
            return
        entries = sh.records()
        scenarios = list(entries)
        self.scenario_combo['values'] = scenarios
        self.excel_status_var.set(f'シート「{sh.name}」 / シナリオ {len(scenarios)}件 / '
                                  f'シナリオ列 {col_label(sh.scenario_col) or "未設定"} / '
                                  f'期待値ID列 {col_label(sh.expected_col) or "未設定"} / '
                                  f'見出し行 {sh.header_row}')
        if scenarios:
            self.scenario_var.set(scenarios[0])
            self._on_scenario_selected()
        else:
            self.scenario_var.set('')
            self.expect_start_var.set('')
            self.expect_end_var.set('')
            self._refresh_expected_preview()

    def _on_scenario_selected(self, _event=None):
        sh = self._active_sheet()
        if not sh:
            return
        ids = sh.ids_for(self.scenario_var.get())
        self.expect_start_combo['values'] = ids
        self.expect_end_combo['values'] = ids
        if ids:
            self.expect_start_var.set(ids[0])
            self.expect_end_var.set(ids[-1])
        else:
            self.expect_start_var.set('')
            self.expect_end_var.set('')
        self._refresh_expected_preview()
        if self.include_id_var.get():
            self.item_var.set(self.expect_start_var.get())

    def _on_expected_selected(self, _event=None):
        self._refresh_expected_preview()
        if self.include_id_var.get():
            first = self.expect_start_var.get().strip()
            last = self.expect_end_var.get().strip()
            self.item_var.set(first if not last or first == last else first + '～' + last)

    def _refresh_expected_preview(self):
        sh = self._active_sheet()
        preview = sh.short_preview(self.scenario_var.get(), self.expect_start_var.get(), self.expect_end_var.get()) if sh else 'Excelを読み込むと、対象の期待値IDと内容が表示されます。'
        self.expected_preview.configure(state='normal')
        self.expected_preview.delete('1.0','end')
        self.expected_preview.insert('1.0',preview)
        self.expected_preview.configure(state='disabled')

    def _on_toggle_id_folder(self):
        if self.include_id_var.get():
            self.folder_id_entry.configure(state='normal')
            self._on_expected_selected()
        else:
            self.item_var.set('')
            self.folder_id_entry.configure(state='disabled')

    def _mapping_dialog(self):
        sh = self._active_sheet()
        if not sh:
            messagebox.showinfo('Excel未選択', '先にExcelとシートを選択してください。')
            return
        dialog = tk.Toplevel(self)
        dialog.title(f'列の対応変更 | {sh.name}')
        dialog.geometry('780x410')
        dialog.transient(self)
        dialog.grab_set()
        frame = ttk.Frame(dialog, padding=18)
        frame.pack(fill='both',expand=True)
        ttk.Label(frame, text='ヘッダー位置・列の対応（実際のExcelが変則的でも変更可能）', style='Title.TLabel').pack(anchor='w')
        headerbar = ttk.Frame(frame)
        headerbar.pack(anchor='w',pady=(15,9))
        ttk.Label(headerbar,text='見出し行（Excel行番号）').pack(side='left')
        head = tk.IntVar(value=sh.header_row)
        ttk.Spinbox(headerbar,from_=1,to=200,textvariable=head,width=8).pack(side='left',padx=8)
        combos={}
        labels = [('シナリオIDの列（任意：空欄ならシート名）','scenario_col'),
                  ('期待値IDの列（必須）','expected_col'),
                  ('概要・期待値などの表示列（任意）','description_col')]
        options = sh.column_options()
        def options_for(header):
            sh.header_row=header
            return {i:f'{col_label(i)}列 | {sh.header(i) or "(見出しなし)"}' for i,_ in options}
        def update_options(*_):
            try:
                mapping = options_for(head.get())
                for prop, combo in combos.items():
                    i = getattr(sh,prop)
                    combo['values'] = ['(使用しない)']+list(mapping.values())
                    combo.set(mapping.get(i,'(使用しない)'))
            except Exception:
                pass
        for label,prop in labels:
            row=ttk.Frame(frame); row.pack(fill='x',pady=7)
            ttk.Label(row,text=label,width=48).pack(side='left')
            combo=ttk.Combobox(row,state='readonly',width=40)
            combo.pack(side='left',fill='x',expand=True)
            combos[prop]=combo
        update_options()
        ttk.Button(headerbar,text='見出しを再表示',command=update_options).pack(side='left')
        ttk.Label(frame,text='例：パターンAは「シナリオID=B列」「期待値ID=A列（またはSID=C列）」、パターンBは「No=B列」「ID=A列」。',style='Info.TLabel').pack(anchor='w',pady=12)
        def save():
            try:
                mapping = options_for(head.get())
                values={value:key for key,value in mapping.items()}
                chosen = {prop: values.get(combo.get(),0) for prop,combo in combos.items()}
                if not chosen['expected_col']:
                    raise ValueError('期待値IDの列を選択してください。')
                sh.scenario_col=chosen['scenario_col']
                sh.expected_col=chosen['expected_col']
                sh.description_col=chosen['description_col']
                if self.active_catalog:
                    self.active_catalog.feature=self.feature_var.get().strip() or self.active_catalog.feature
                save_catalogs(self.root_dir,self.catalogs)
                self._on_sheet_selected()
                dialog.destroy()
            except Exception as e:
                messagebox.showerror('列対応の保存に失敗',str(e),parent=dialog)
        ttk.Button(frame,text='この列設定を適用',command=save).pack(anchor='e',pady=8)

    def _build_sort_ui(self):
        root = self.sort_page
        top = ttk.Frame(root)
        top.pack(fill='x')
        ttk.Label(top, text='iPhoneから取り込んだ画像フォルダ', width=30).pack(side='left')
        ttk.Entry(top, textvariable=self.import_var).pack(side='left', fill='x', expand=True, padx=6)
        ttk.Button(top, text='選択...', command=self._choose_import).pack(side='left', padx=3)
        ttk.Button(top, text='画像をスキャン', command=self._start_scan).pack(side='left', padx=(5, 0))
        ttk.Label(root, text='しおり画像も一緒に取り込んでください。画像の元ファイル名は維持し、撮影区間とOSで分類します。', style='Info.TLabel').pack(anchor='w', pady=(7, 8))

        ctr = ttk.Frame(root)
        ctr.pack(fill='x', pady=(0, 6))
        ttk.Label(ctr, text='選択画像を区間へ:').pack(side='left')
        self.assign_combo = ttk.Combobox(ctr, textvariable=self.assign_var, width=54, state='readonly')
        self.assign_combo.pack(side='left', padx=6)
        ttk.Button(ctr, text='区間を設定', command=self._set_segment).pack(side='left')
        ttk.Button(ctr, text='And', command=lambda:self._set_platform('And')).pack(side='left', padx=(12, 3))
        ttk.Button(ctr, text='iOS', command=lambda:self._set_platform('iOS')).pack(side='left')
        ttk.Button(ctr, text='OS未判定', command=lambda:self._set_platform('')).pack(side='left', padx=3)

        tools = ttk.Frame(root)
        tools.pack(fill='x', pady=(0, 7))
        ttk.Button(tools, text='↑ 上へ', command=lambda:self._move(-1)).pack(side='left', padx=(0, 3))
        ttk.Button(tools, text='↓ 下へ', command=lambda:self._move(1)).pack(side='left', padx=3)
        ttk.Button(tools, text='区間を自動で再判定', command=self._reassign).pack(side='left', padx=7)
        ttk.Button(tools, text='除外 / 解除', command=self._toggle_skip).pack(side='left')
        ttk.Label(tools, text=' 並び順:').pack(side='left', padx=(12, 2))
        ttk.Combobox(tools, width=19, textvariable=self.sort_var, state='readonly',
                     values=['撮影日時（自動）','IMG連番（ファイル名）','ファイル名']).pack(side='left', padx=(0, 4))
        ttk.Button(tools, text='適用', command=self._apply_sort).pack(side='left')

        self.paned = ttk.Panedwindow(root, orient='vertical')
        self.paned.pack(fill='both', expand=True, pady=(3, 4))
        treebox = ttk.Frame(self.paned)
        self.paned.add(treebox, weight=4)
        cols = ('no','file','time','basis','type','segment','os','certainty','status')
        self.tree = ttk.Treeview(treebox, columns=cols, show='headings', selectmode='extended')
        details = [('no','#',45),('file','元ファイル名',220),('time','撮影日時（推定）',154),
                   ('basis','日時の根拠',125),('type','種類',77),('segment','区間',136),
                   ('os','OS',65),('certainty','推定精度',83),('status','状態',248)]
        for name, label, size in details:
            self.tree.heading(name, text=label)
            self.tree.column(name, width=size, minwidth=45, stretch=(name in ['file','status']))
        self.tree.pack(side='left', fill='both', expand=True)
        ys = ttk.Scrollbar(treebox, orient='vertical', command=self.tree.yview)
        ys.pack(side='right', fill='y')
        self.tree.configure(yscrollcommand=ys.set)
        xs = ttk.Scrollbar(root, orient='horizontal', command=self.tree.xview)
        xs.pack(fill='x')
        self.tree.configure(xscrollcommand=xs.set)
        self.tree.tag_configure('needs', background='#fff0dc')
        self.tree.tag_configure('marker', foreground='#607089')
        self.tree.bind('<<TreeviewSelect>>', self._on_image_selected)

        details_box = ttk.Frame(self.paned)
        self.paned.add(details_box, weight=1)
        self.image_preview = ttk.Label(details_box, text='画像を選択するとプレビューが表示されます。', anchor='center', width=26)
        self.image_preview.pack(side='left', fill='both', padx=8, pady=6)
        side = ttk.Frame(details_box)
        side.pack(side='left', fill='both', expand=True, padx=8, pady=6)
        self.item_info = tk.Text(side, wrap='word', height=6, font=('Yu Gothic UI', 10), state='disabled')
        self.item_info.pack(fill='both', expand=True)

        bottom = ttk.Frame(root)
        bottom.pack(fill='x', pady=(7, 0))
        ttk.Label(bottom, textvariable=self.summary_var).pack(side='left', fill='x', expand=True)
        ttk.Button(bottom, text='分類計画CSVを保存', command=self._save_plan_report).pack(side='right', padx=(6, 0))
        ttk.Button(bottom, text='分類可能な画像をフォルダへコピー', style='Accent.TButton', command=self._start_copy).pack(side='right')
        ttk.Label(root, textvariable=self.progress_var, style='Info.TLabel').pack(anchor='w', pady=(4, 0))

    def _choose_workspace(self):
        folder = filedialog.askdirectory(title='作業フォルダを選択')
        if folder:
            self.workspace_var.set(folder)
            self._load_workspace()

    def _choose_spec(self):
        self._add_spec_files()

    def _choose_import(self):
        folder = filedialog.askdirectory(title='iPhone画像を取り込んだフォルダを選択')
        if folder:
            self.import_var.set(folder)

    def _load_workspace(self):
        if self.busy:
            messagebox.showwarning('処理中', '処理完了後に作業フォルダを変更してください。')
            return
        try:
            self.sessions = load_sessions(self.root_dir)
            self.catalogs = load_catalogs(self.root_dir)
            self.active_catalog = None
            self._refresh_catalog_combo()
            self.current_sid = ''
            self.rows.clear()
            self._refresh_segments()
            self._refresh_tree()
            self.message_var.set(f'作業フォルダ: {self.root_dir} / しおり区間 {len(self.sessions)} 件')
        except Exception as e:
            messagebox.showerror('読込エラー', str(e))

    def _refresh_segments(self):
        self.segment_list.delete(0, tk.END)
        for s in self.sessions:
            self.segment_list.insert(tk.END, s.label())
        self.assign_combo['values'] = ['未割当'] + [s.label() for s in self.sessions]
        self.assign_combo.current(0)

    def _clear_scenario(self):
        self.expect_start_var.set('')
        self.expect_end_var.set('')
        self._refresh_expected_preview()
        if self.include_id_var.get():
            self.item_var.set('')

    def _add_segment(self):
        try:
            sh = self._active_sheet()
            start = self.expect_start_var.get().strip()
            end = self.expect_end_var.get().strip() or start
            if sh and start and end:
                ids = sh.ids_for(self.scenario_var.get())
                if start not in ids or end not in ids:
                    raise ValueError('選択した期待値IDがExcelに見つかりません。IDとシナリオを確認してください。')
                if ids.index(start) > ids.index(end):
                    raise ValueError('期待値IDの終了が開始より前です。')
            if self.active_catalog:
                self.active_catalog.feature=self.feature_var.get().strip()
                save_catalogs(self.root_dir,self.catalogs)
            folder_id = self.item_var.get().strip() if self.include_id_var.get() else ''
            seg = Segment.create(self.feature_var.get(), self.spec_var.get(), self.scenario_var.get(), folder_id,
                                 start, end, self.sheet_var.get() if sh else '')
            self.sessions.append(seg)
            save_sessions(self.root_dir, self.sessions)
            make_marker(self.root_dir, seg, 'START')
            make_marker(self.root_dir, seg, 'END')
            self.current_sid = seg.sid
            self._refresh_segments()
            self.segment_list.selection_set(len(self.sessions)-1)
            self.segment_list.see(len(self.sessions)-1)
            self.message_var.set(f'しおりを生成しました: {seg.label()}')
            self._open_marker('START')
        except Exception as e:
            messagebox.showerror('区間登録に失敗', str(e))

    def _on_segment_selected(self, _event=None):
        selected = self.segment_list.curselection()
        if selected:
            self.current_sid = self.sessions[selected[0]].sid

    def _open_marker_folder(self):
        if not self.current_sid:
            messagebox.showinfo('選択してください', '区間を選んでください。')
            return
        folder = workspace_paths(self.root_dir)[0] / 'しおり' / self.current_sid
        try:
            import os
            if os.name == 'nt':
                os.startfile(str(folder))
            else:
                self.clipboard_clear(); self.clipboard_append(str(folder))
                messagebox.showinfo('保存先パス', f'パスをクリップボードへコピーしました。\n{folder}')
        except Exception as e:
            messagebox.showerror('フォルダ表示失敗', str(e))

    def _open_marker(self, tag: str):
        if not self.current_sid or self.current_sid not in self.known:
            messagebox.showinfo('区間未選択', 'まず登録済み区間を選択してください。')
            return
        path = make_marker(self.root_dir, self.known[self.current_sid], tag)
        window = tk.Toplevel(self)
        window.title('撮影開始しおり' if tag == 'START' else '撮影終了しおり')
        window.geometry('820x790')
        window.configure(background='white')
        bar = ttk.Frame(window, padding=8)
        bar.pack(fill='x')
        ttk.Label(bar, text='iPhoneのカメラでこのQR画像を撮影してください。', font=('Yu Gothic UI', 11, 'bold')).pack(side='left')
        holder = ttk.Label(window)
        holder.pack(fill='both', expand=True)
        original = Image.open(path)
        original.thumbnail((740, 715))
        window.marker_photo = ImageTk.PhotoImage(original)
        holder.configure(image=window.marker_photo)
        footer = ttk.Frame(window, padding=8)
        footer.pack(fill='x')
        ttk.Button(footer, text='START 表示', command=lambda:(window.destroy(), self._open_marker('START'))).pack(side='left', padx=4)
        ttk.Button(footer, text='END 表示', command=lambda:(window.destroy(), self._open_marker('END'))).pack(side='left', padx=4)
        ttk.Button(footer, text='閉じる', command=window.destroy).pack(side='right')

    def _start_scan(self):
        if self.busy:
            return
        directory = Path(self.import_var.get())
        if not directory.is_dir():
            messagebox.showerror('画像未指定', '取り込み画像があるフォルダを選択してください。')
            return
        if not QR_AVAILABLE:
            messagebox.showerror('QRライブラリ不足', 'OpenCVがありません。install.batで必要ライブラリをインストールしてください。')
            return
        self.busy = True
        self.progress_var.set('解析開始... （大量の画像ではしばらくかかります）')
        self.message_var.set('画像のQR・日時・OSを解析しています。')
        root = self.root_dir
        def worker():
            try:
                def progress(i, total, name):
                    if i % 5 == 0 or i == total:
                        self.events.put(('progress', f'解析中 {i}/{total}：{name}'))
                items = scan_images(directory, root, progress)
                self.events.put(('scanned', items))
            except Exception as exc:
                self.events.put(('failure', str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def _poll_events(self):
        try:
            while True:
                typ, payload = self.events.get_nowait()
                if typ == 'progress':
                    self.progress_var.set(payload)
                elif typ == 'scanned':
                    self.busy = False
                    self.rows = payload
                    warnings = assign_segments(self.rows, self.known)
                    self._refresh_tree()
                    self.progress_var.set(f'解析完了：{len(self.rows)}枚。注意事項 {len(warnings)}件。')
                    self.message_var.set('必要に応じて区間・OSを修正し、コピーを実行してください。')
                    if warnings:
                        messagebox.showwarning('しおりの確認', '\n'.join(warnings[:12]))
                elif typ == 'copied':
                    self.busy = False
                    copies, count, report = payload
                    self._refresh_tree()
                    self.progress_var.set(f'コピー完了 {count}枚 / 対象{len(copies)}枚。履歴：{report}')
                    problems = sum(r['status'] != 'コピー完了' for r in copies)
                    messagebox.showinfo('コピー完了', f'{count}枚をコピーしました。\nエラー・同名衝突: {problems}件\n\nレポート: {report}')
                elif typ == 'failure':
                    self.busy = False
                    self.progress_var.set('')
                    messagebox.showerror('処理失敗', payload)
        except queue.Empty:
            pass
        self.after(130, self._poll_events)

    def _plan(self):
        return plan_rows(self.rows, self.known, self.root_dir)

    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        plan = self._plan()
        counts = Counter()
        for i, (row, status, dest) in enumerate(plan):
            counts[status] += 1
            try:
                from datetime import datetime
                captured = datetime.fromtimestamp(row.timestamp).strftime('%Y-%m-%d %H:%M:%S')
            except Exception:
                captured = '日時不明'
            sid = row.segment_id[:12] if row.segment_id else '-'
            self.tree.insert('', 'end', iid=str(i), values=(i+1, row.path.name, captured, row.time_source,
                                ('しおり ' + row.marker_tag) if row.kind == 'marker' else '画像', sid,
                                row.platform or '-', row.confidence or '-', status),
                             tags=('marker',) if row.kind == 'marker' else ('needs',) if status.startswith('要確認') else ())
        self.summary_var.set(f'総数 {len(plan)} / 分類可能 {counts["分類可能"]} / 要確認 {sum(v for k,v in counts.items() if k.startswith("要確認"))} / しおり {counts["しおり（格納対象外）"]}')

    def _selected_indices(self) -> list[int]:
        return sorted(int(s) for s in self.tree.selection())

    def _keep_selection(self, indexes):
        if not indexes:
            return
        ids = [str(i) for i in indexes if i < len(self.rows)]
        self.tree.selection_set(ids)
        self.tree.see(ids[0])

    def _set_segment(self):
        selected = self._selected_indices()
        if not selected:
            return
        index = self.assign_combo.current()
        if index < 0:
            messagebox.showinfo('区間未選択', '割当先の区間を選択してください。')
            return
        sid = self.sessions[index-1].sid if index else ''
        for i in selected:
            if self.rows[i].kind != 'marker':
                self.rows[i].segment_id = sid
                self.rows[i].manually_set_segment = True
        self._refresh_tree(); self._keep_selection(selected)

    def _set_platform(self, platform: str):
        selected = self._selected_indices()
        if not selected:
            return
        for i in selected:
            if self.rows[i].kind != 'marker':
                self.rows[i].platform = platform
                self.rows[i].manually_set_platform = True
                self.rows[i].confidence = '手動' if platform else '低'
        self._refresh_tree(); self._keep_selection(selected)

    def _apply_sort(self):
        if not self.rows:
            return
        mode = self.sort_var.get()
        if mode == 'IMG連番（ファイル名）':
            matching = sum(bool(re.search(r'(?i)IMG[_ -]?(\d{3,})', r.path.stem)) for r in self.rows)
            if matching != len(self.rows):
                if not messagebox.askyesno('連番のないファイル',
                    f'全{len(self.rows)}枚のうち{len(self.rows)-matching}枚はIMG連番がありません。\n連番のない画像は末尾へ移動します。よろしいですか？'):
                    return
            def key(row):
                found = re.search(r'(?i)IMG[_ -]?(\d{3,})', row.path.stem)
                return (0, int(found.group(1)), str(row.path)) if found else (1, row.timestamp, str(row.path))
            self.rows.sort(key=key)
        elif mode == 'ファイル名':
            self.rows.sort(key=lambda row: (row.path.name.lower(), str(row.path)))
        else:
            self.rows.sort(key=lambda row: (row.timestamp, str(row.path)))
        warnings = assign_segments(self.rows, self.known)
        self._refresh_tree()
        self.message_var.set(f'「{mode}」で並び替えました。しおり対応の注意事項 {len(warnings)}件。')

    def _move(self, direction):
        selected = self._selected_indices()
        if len(selected) != 1:
            messagebox.showinfo('選択', '撮影順を変更する画像を1枚選択してください。')
            return
        index = selected[0]
        next_pos = index + direction
        if next_pos < 0 or next_pos >= len(self.rows):
            return
        self.rows[index], self.rows[next_pos] = self.rows[next_pos], self.rows[index]
        assign_segments(self.rows, self.known)
        self._refresh_tree()
        self._keep_selection([next_pos])

    def _reassign(self):
        warnings = assign_segments(self.rows, self.known)
        self._refresh_tree()
        self.message_var.set(f'しおりに基づき再判定しました。注意 {len(warnings)}件。手動修正は保持しています。')

    def _toggle_skip(self):
        selected = self._selected_indices()
        if not selected:
            return
        for i in selected:
            if self.rows[i].kind != 'marker':
                self.rows[i].skipped = not self.rows[i].skipped
        self._refresh_tree(); self._keep_selection(selected)

    def _on_image_selected(self, _event=None):
        indexes = self._selected_indices()
        if not indexes:
            return
        row = self.rows[indexes[0]]
        current_plan = self._plan()[indexes[0]]
        info = [f'ファイル: {row.path.name}', f'パス: {row.path}',
                f'区間: {row.segment_id or "未指定"}', f'OS: {row.platform or "未判定"}',
                f'判定: {current_plan[1]}', f'理由: {row.detail}',
                f'格納予定先: {current_plan[2] if current_plan[2] else "なし"}']
        self.item_info.configure(state='normal')
        self.item_info.delete('1.0', tk.END)
        self.item_info.insert('1.0', '\n'.join(info))
        self.item_info.configure(state='disabled')
        try:
            with Image.open(row.path) as opened:
                pic = ImageOps.exif_transpose(opened)
                pic.thumbnail((240, 140))
                self.preview_photo = ImageTk.PhotoImage(pic.convert('RGB'))
            self.image_preview.config(image=self.preview_photo, text='')
        except Exception:
            self.image_preview.config(image='', text='プレビュー不可（画像形式または破損）')

    def _save_plan_report(self):
        if not self.rows:
            messagebox.showinfo('未取込', '画像を先にスキャンしてください。')
            return
        try:
            report = save_report(self.root_dir, self._plan(), [])
            messagebox.showinfo('CSV出力', f'分類計画を出力しました。\n{report}')
        except Exception as e:
            messagebox.showerror('出力エラー', str(e))

    def _start_copy(self):
        if self.busy or not self.rows:
            return
        plan = self._plan()
        counts = Counter(status for _, status, _ in plan)
        count = counts['分類可能']
        if not count:
            messagebox.showwarning('コピー対象なし', '分類可能な画像がありません。要確認の画像を修正してください。')
            return
        unresolved = sum(v for k,v in counts.items() if k.startswith('要確認'))
        proceed = messagebox.askyesno('コピーの確認',
            f'分類可能: {count}枚\n要確認（コピーしない）: {unresolved}枚\n\n画像は元の名前・拡張子・内容を変更せず、指定フォルダへコピーします。\n元画像もそのまま残ります。\n\n実行しますか？')
        if not proceed:
            return
        self.busy = True
        self.progress_var.set('コピー中...')
        root = self.root_dir
        def worker():
            try:
                def progress(i, total, name):
                    if i % 10 == 0 or i == total:
                        self.events.put(('progress', f'コピー中 {i}/{total}：{name}'))
                copied, total = copy_approved(plan, progress)
                report = save_report(root, plan, copied)
                self.events.put(('copied', (copied, total, report)))
            except Exception as ex:
                self.events.put(('failure', str(ex)))
        threading.Thread(target=worker, daemon=True).start()


def main():
    app = EvidenceApp()
    app.mainloop()

if __name__ == '__main__':
    main()
