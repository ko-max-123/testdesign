"""Create fake evidence images to safely test sorting. Does not touch real photos."""
from pathlib import Path
import os
import shutil
import time
from PIL import Image, ImageDraw, ImageFont
from evidence_core import Segment, save_sessions, make_marker

BASE = Path(__file__).resolve().parent / 'デモデータ'
WORK = BASE / '作業'
INPUT = BASE / 'iPhoneから取り込んだ画像'

def fake_marker(original: Path, output: Path, modified_at: float) -> None:
    panel = Image.open(original).convert('RGB')
    background = Image.new('RGB', (1120, 1020), '#d0d8de')
    background.paste(panel, (190, 75))
    background.save(output, 'JPEG', quality=96, subsampling=0)
    os.utime(output, (modified_at, modified_at))

def fake_capture(output: Path, label: str, is_screenshot: bool, modified_at: float) -> None:
    image = Image.new('RGB', (760, 1430) if is_screenshot else (1100, 900), '#eef3f7' if is_screenshot else '#dadfe7')
    d = ImageDraw.Draw(image)
    d.rounded_rectangle((100, 180, image.width - 100, image.height - 150), radius=30, fill='#ffffff', outline='#728195', width=4)
    d.text((145, 300), label, fill='#263c53', font=ImageFont.load_default())
    d.rectangle((145, 470, image.width-145, 530), fill='#508cca')
    image.save(output, 'PNG' if is_screenshot else 'JPEG', quality=94)
    os.utime(output, (modified_at, modified_at))

def main():
    if BASE.exists():
        shutil.rmtree(BASE)
    INPUT.mkdir(parents=True)
    a = Segment.create('決済機能', '総合テストA.xlsx', 'P1-1')
    b = Segment.create('決済機能', '総合テストB.xlsx', 'P1-2', 'ID-005')
    save_sessions(WORK, [a, b])
    ts = 1793060000
    commands = [
        ('IMG_0001.JPG', 'marker', a, 'START'),
        ('IMG_0002.PNG', 'screen', None, 'iOS 操作1'),
        ('IMG_0003.JPG', 'photo', None, 'And 操作1'),
        ('IMG_0004.PNG', 'screen', None, 'iOS 操作2'),
        ('IMG_0005.JPG', 'marker', a, 'END'),
        ('IMG_0006.JPG', 'marker', b, 'START'),
        ('IMG_0007.JPG', 'photo', None, 'And 操作1'),
        ('IMG_0008.PNG', 'screen', None, 'iOS 操作1'),
        ('IMG_0009.JPG', 'marker', b, 'END'),
        ('IMG_0010.PNG', 'screen', None, '区間外（保留）'),
    ]
    for i, (filename, kind, segment, desc) in enumerate(commands):
        at = ts + i * 21
        dest = INPUT / filename
        if kind == 'marker':
            mark = make_marker(WORK, segment, desc)
            fake_marker(mark, dest, at)
        else:
            fake_capture(dest, desc, kind=='screen', at)
    print(f'デモ生成完了: {BASE}')
    print(f'作業フォルダ: {WORK}')
    print(f'画像フォルダ: {INPUT}')

if __name__ == '__main__':
    main()
