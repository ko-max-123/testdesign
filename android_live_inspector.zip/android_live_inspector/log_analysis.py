"""Parser and conservative annotation for adb logcat -v threadtime.

Logcat severity is authoritative for ordinary messages: English words like
'Error' are not evidence that Android emitted an error-level log.
"""
import re
from datetime import datetime

THREADTIME = re.compile(
    r'^\s*(?P<date>\d{2}-\d{2})\s+'
    r'(?P<clock>\d{2}:\d{2}:\d{2}\.\d{3,6})\s+'
    r'(?P<pid>\d+)\s+(?P<tid>\d+)\s+'
    r'(?P<level>[VDIWEAFS])\s+(?P<tag>[^:]+?):\s?(?P<message>.*)$'
)
LEVEL_SEVERITY = {
    'V':'debug', 'D':'debug', 'I':'info', 'W':'warning',
    'E':'error', 'F':'critical', 'A':'critical', 'S':'debug',
}
CATEGORY_SEVERITY = {
    'debug': 'DEBUG', 'info': 'INFO', 'warning': 'WARNING',
    'error': 'ERROR', 'critical': 'CRITICAL'
}
CRASH = re.compile(r'FATAL EXCEPTION|Fatal signal\s+\d+|\bFatal exception in\b', re.I)
ANR = re.compile(r'\bANR in\b|Application Not Responding', re.I)
DEEPLINK = re.compile(r'ACTION_VIEW|android\.intent\.action\.VIEW|\bdat=(?:https?://|[a-zA-Z][\w+.-]*://)', re.I)
ACTIVITY = re.compile(r'ActivityTaskManager|ActivityManager.*START|START u\d+\s*\{', re.I)
WEBVIEW = re.compile(r'chromium|WebView|AwContents|\bcr_\w+', re.I)
NETWORK = re.compile(r'ConnectivityService|NetworkAgent|OkHttp|Retrofit|HTTP/[12]|response code|status code', re.I)
PERMISSION = re.compile(r'Permission Denial|SecurityException|\bpermission\b', re.I)
ERROR_WORD = re.compile(r'\b(error|exception|failed|failure)\b', re.I)


def parse_threadtime(line):
    m = THREADTIME.match(line.rstrip('\r\n'))
    if not m:
        return None
    d = m.groupdict()
    d['pid'] = int(d['pid'])
    d['tid'] = int(d['tid'])
    d['tag'] = d['tag'].strip()
    return d


def log_time(d, now=None):
    """Choose year closest to current host date; timezone/device skew remains possible."""
    now = now or datetime.now()
    year = now.year
    candidates = []
    for y in (year - 1, year, year + 1):
        try:
            t = datetime.strptime(f'{y}-{d["date"]} {d["clock"]}', '%Y-%m-%d %H:%M:%S.%f')
            candidates.append(t)
        except ValueError:
            pass
    if not candidates:
        return None
    return min(candidates, key=lambda t: abs((t - now).total_seconds()))


def parse_ps(output):
    """Supports both `ps -A -o PID,NAME` and Android `ps -A` layouts."""
    lines = [line.split() for line in output.splitlines() if line.strip()]
    if not lines:
        return {}
    head = [x.upper() for x in lines[0]]
    if 'PID' not in head or 'NAME' not in head:
        return {}
    pid_idx, name_idx = head.index('PID'), head.index('NAME')
    result = {}
    for row in lines[1:]:
        if len(row) <= max(pid_idx, name_idx) or not row[pid_idx].isdigit():
            continue
        result[int(row[pid_idx])] = row[name_idx]
    return result


def source_role(name, target_package=''):
    if not name:
        return 'unknown'
    if target_package and (name == target_package or name.startswith(target_package + ':')):
        return 'target'
    if name == 'system_server' or name in ('surfaceflinger', 'init', 'zygote', 'zygote64') or name.startswith(('android.', 'com.android.')):
        return 'android'
    if name.startswith('com.google.android.'):
        return 'google'
    return 'other'


def classify(line, process_map=None, target_package='', captured=None):
    """Return selected diagnostic event or None; severity is not from keywords."""
    d = parse_threadtime(line)
    if d is None:
        return None
    msg = d['message']
    body = f'{d["tag"]}: {msg}'
    level = d['level']
    severity = LEVEL_SEVERITY[level]
    if CRASH.search(body):
        typ, category = 'CRASH', 'error'
        # Unambiguous fatal events can elevate importance, without falsifying log_level.
        severity = 'critical'
    elif ANR.search(body):
        typ, category = 'ANR', 'error'
        severity = 'critical'
    elif DEEPLINK.search(body):
        typ, category = 'DEEPLINK', 'deeplink'
    elif PERMISSION.search(body):
        typ, category = 'PERMISSION', 'warning' if severity in ('warning', 'info', 'debug') else 'error'
    elif ACTIVITY.search(body):
        typ, category = 'ACTIVITY', 'activity'
    elif WEBVIEW.search(body):
        typ, category = 'WEBVIEW', 'webview'
    elif NETWORK.search(body):
        typ, category = 'NETWORK', 'network'
    elif ERROR_WORD.search(body) or severity in ('error', 'critical'):
        # INFO NetworkScheduler: "Error inserting" stays INFO rather than ERROR.
        typ, category = CATEGORY_SEVERITY[severity], severity if severity in ('info','warning','error') else 'system'
    else:
        return None

    process = (process_map or {}).get(d['pid'])
    timestamp = log_time(d, captured)
    summary = line.strip()
    if len(summary) > 360:
        summary = summary[:357] + '...'
    return {
        'type': typ, 'category': category, 'summary': summary, 'raw': line.rstrip('\r\n'),
        'ts': d['clock'][:12], 'date': d['date'], 'log_level': level,
        'severity': severity, 'pid': d['pid'], 'tid': d['tid'], 'tag': d['tag'],
        'process': process, 'source_role': source_role(process, target_package),
        'timestamp_source': 'device_logcat',
        'log_datetime': timestamp.isoformat(timespec='milliseconds') if timestamp else None,
        'captured_at': (captured or datetime.now()).isoformat(timespec='milliseconds'),
    }
