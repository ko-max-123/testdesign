@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === Android Live Inspector Environment Check ===
echo.
where python >nul 2>&1
if errorlevel 1 (echo [NG] Python not found) else (echo [OK] Python & python --version)
if exist tools\adb.exe (
  set ADB=tools\adb.exe
) else (
  set ADB=adb
)
%ADB% version >nul 2>&1
if errorlevel 1 (
  echo [NG] ADB not found. Put adb.exe and its DLLs in tools\ or add adb to PATH.
) else (
  echo [OK] ADB
  %ADB% version
  echo.
  echo === Devices ===
  %ADB% devices -l
)
echo.
pause
