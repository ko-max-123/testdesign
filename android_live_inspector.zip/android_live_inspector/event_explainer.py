"""Conservative, deterministic explanations of observed Android log events.

This is not a causal inference engine. Every observation must be grounded in the
single input event. Other apps/steps are never invented when missing from logs.
"""
import re


def _extract(pattern, value):
    match = re.search(pattern, value, re.IGNORECASE)
    return match.group(1).strip() if match else None


def _step(label, detail='', status='observed'):
    return {'label': label, 'detail': detail, 'status': status}


def explain(event):
    kind = str(event.get('type', '')).upper()
    raw = str(event.get('raw') or event.get('summary') or '')
    message = raw.split(': ', 1)[-1]
    tag = str(event.get('tag') or '')
    process = str(event.get('process') or '')
    severity = str(event.get('severity') or 'info')
    role = event.get('source_role', 'unknown')
    info = {
        'title': 'ログの解析',
        'description': '記録されたログの種類と発生元を表示しています。',
        'steps': [], 'facts': [], 'unknowns': [],
        'notice': '観測したログだけでは、操作間の因果関係は確定できません。',
        'classification': 'generic',
    }

    if kind in ('DEEPLINK', 'DEEPLINK_TEST'):
        info['classification'] = 'deeplink'
        action = _extract(r'\bact=([^\s}\]]+)', raw)
        uri = _extract(r'\bdat=(\[[^\]]*\]|[^\s}\]]+)', raw)
        if uri:
            uri = uri.strip('[]')
        comp = _extract(r'\bcmp=([^\s}\]]+)', raw)
        pkg = _extract(r'\bpkg=([^\s}\]]+)', raw)
        origin = _extract(r'\bfrom uid\s+\d+\s+\(([^)]+)\)', raw)
        result = _extract(r'\bresult code=([^\s]+)', raw)
        is_dynamic = bool(re.search(r'firebase\.dynamiclinks|page\.link|dynamiclinks\.appinvite', raw, re.I))
        info['title'] = 'Firebase Dynamic Link' if is_dynamic else 'Deep Link / Intent'
        info['description'] = 'Androidのリンク起動要求が記録されました。起動要求と最終画面の表示は別です。'
        if origin:
            info['steps'].append(_step('呼び出し元', origin))
            info['facts'].append(f'呼び出し元として {origin} が記録されています。')
        if uri:
            info['steps'].append(_step('リンクURI', uri))
            info['facts'].append('リンクURI（ログに記録された範囲）を確認できます。')
        if action:
            info['facts'].append(f'Intent action: {action}')
        if pkg or comp:
            destination = comp or pkg
            info['steps'].append(_step('起動要求先', destination))
            info['facts'].append(f'要求先: {destination}')
        if not info['steps']:
            info['steps'].append(_step('リンク起動操作', raw[:180] or '詳細未記録'))
        if result:
            info['facts'].append(f'Activity起動要求の結果コード: {result}（画面遷移全体の成功を意味しません）')
        if kind == 'DEEPLINK_TEST':
            info['description'] = 'ツールのDeep Link Labから起動を要求しました。応答は下のRaw Logで確認してください。'
        info['unknowns'].append('最終的なアプリ起動と目的画面の表示は、このログ単体では確認できません。')
        if is_dynamic:
            info['unknowns'].append('リンク解決の成否、アプリ本体への引き渡しは別のイベントで確認が必要です。')
        info['notice'] = '矢印はログ内に記録された情報の整理です。未記録の中継や成功は補完していません。'

    elif kind == 'FOCUS_CHANGE':
        info['classification'] = 'activity'
        before, after = event.get('from'), event.get('to')
        info['title'] = 'フォアグラウンド画面の変化'
        info['description'] = 'Androidが報告する前面ウィンドウの変化です。'
        if before:
            info['steps'].append(_step('変更前', str(before)))
        if after:
            info['steps'].append(_step('変更後', str(after)))
        info['facts'] = ['前面ウィンドウの変化が観測されました。']
        info['unknowns'] = ['画面内のWebView遷移やリンク処理の成否は、この情報だけでは確認できません。']

    elif kind == 'ACTIVITY':
        info['classification'] = 'activity'
        info['title'] = 'Activityの起動・遷移'
        info['description'] = 'AndroidのActivity管理ログに記録されたイベントです。'
        component = _extract(r'\bcmp=([^\s}\]]+)', raw)
        action = _extract(r'\bact=([^\s}\]]+)', raw)
        info['steps'].append(_step('Activity管理', tag or 'ActivityTaskManager'))
        if component:
            info['steps'].append(_step('起動要求先', component))
            info['facts'].append(f'要求先コンポーネント: {component}')
        if action:
            info['facts'].append(f'Intent action: {action}')
        info['unknowns'] = ['対象画面が正常に描画されたかは、この行だけでは確認できません。']

    elif kind == 'WEBVIEW':
        info['classification'] = 'webview'
        info['title'] = 'WebView / Chromium関連'
        info['description'] = 'WebViewやChromiumのログを検出しました。'
        info['steps'].append(_step('ログ発生元', process or tag or '未特定'))
        info['steps'].append(_step('WebView関連ログ', tag or kind))
        info['facts'] = [f'タグ: {tag or "未記録"}']
        info['unknowns'] = ['表示URLやWebView内部のリンク遷移は、ログに情報がなければ特定できません。']

    elif kind in ('ERROR', 'CRASH', 'ANR', 'PERMISSION', 'WARNING') or severity in ('error', 'critical'):
        info['classification'] = 'error'
        info['title'] = ('クラッシュ検出' if kind == 'CRASH' else '応答なし（ANR）検出' if kind == 'ANR'
                         else 'Androidログの異常・警告')
        info['description'] = '発生元と原本の重要度を確認し、前後のイベントから影響を調べます。'
        info['steps'].append(_step('発生元', process or f'PID {event.get("pid")}' if event.get('pid') else '未特定'))
        info['steps'].append(_step('ログのタグ', tag or '不明'))
        info['steps'].append(_step('原本のレベル', str(event.get('log_level') or '未記録')))
        info['facts'] = [f'ログレベル: {event.get("log_level") or "未記録"} / 解析分類: {kind}']
        if tag == 'BatteryStatsService' and 'Invalid uid for waking network packet' in raw:
            info['description'] = 'Androidの電力・ネットワーク統計でUIDを特定できなかった旨のログです。'
            info['unknowns'] = ['これだけで対象アプリの通信障害とは判断できません。']
        else:
            info['unknowns'] = ['このログだけでは根本原因と対象アプリへの影響は確定できません。']
        info['notice'] = '時刻が近い関連イベントは、原因の証明ではありません。下の関連イベントで確認してください。'

    elif kind == 'NETWORK':
        info['classification'] = 'network'
        info['title'] = 'ネットワーク関連ログ'
        info['description'] = 'ネットワーク管理・通信ライブラリに関連するログを検出しました。'
        info['steps'] = [_step('発生元', process or '未特定'), _step('ログのタグ', tag or '未記録')]
        info['facts'] = [f'ログレベル: {event.get("log_level") or "未記録"}']
        info['unknowns'] = ['APIのリクエスト・レスポンス内容は、アプリが出力していなければADBだけでは確認できません。']

    else:
        info['steps'] = [_step('発生元', process or '未特定'), _step('ログのタグ', tag or kind or '不明')]
        info['facts'] = [f'原本ログレベル: {event.get("log_level") or "未記録"}']
        info['unknowns'] = ['他の画面・操作との関係は未確認です。']

    # Keep severity of original log and interpretation separately, even for OS logs.
    info['source_label'] = {'target': '対象アプリ', 'android': 'Androidシステム', 'google': 'Google関連',
                            'other': 'その他', 'unknown': '未特定'}.get(role, '未特定')
    return info
