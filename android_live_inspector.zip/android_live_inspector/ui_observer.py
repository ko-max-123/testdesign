"""Privacy-preserving UI hierarchy metadata observer (ADB only).

Observes structural changes, NOT taps, internal navigation functions, or page content.
No text, content-description, bounds, screenshots, or raw XML are persisted.
"""
import collections
import hashlib
import re
import xml.etree.ElementTree as ET

HIERARCHY = re.compile(r'<hierarchy\b[\s\S]*?</hierarchy>')
ID_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_.]*:id/[A-Za-z0-9_]+$')
SHORT_ID_RE = re.compile(r'^id/[A-Za-z0-9_]+$')


def safe_id(value):
    """Only ordinary Android resource-id syntax, never displayed text or descriptions."""
    value = (value or '').strip()
    if ID_RE.fullmatch(value) or SHORT_ID_RE.fullmatch(value):
        return value[-110:]
    return ''


def parse_ui_dump(stdout, expected_package=None):
    """Return limited, non-sensitive structural metadata, or raise ValueError.

    app package from UI hierarchy can differ from top activity while dialogs are open.
    """
    if not isinstance(stdout, str) or len(stdout) > 3_000_000:
        raise ValueError('UIダンプが大きすぎるか不正です')
    found = HIERARCHY.search(stdout)
    if not found:
        raise ValueError('UI階層を取得できません（WebView/端末制限/画面ロック等）')
    try:
        root = ET.fromstring(found.group(0))
    except ET.ParseError as exc:
        raise ValueError('UI階層XMLの解析に失敗') from exc
    nodes = root.findall('.//node')
    if len(nodes) > 4000:
        raise ValueError('UI要素が多すぎます')
    packages = collections.Counter()
    components = collections.Counter()
    clickable = set()
    signatures = collections.Counter()
    for node in nodes:
        attr = node.attrib
        pkg = attr.get('package', '')
        if re.fullmatch(r'[A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)+', pkg):
            packages[pkg] += 1
        cls = attr.get('class', '')
        cls = cls.rsplit('.', 1)[-1] if cls.startswith(('android.', 'androidx.', 'com.google.')) else 'CustomView'
        res = safe_id(attr.get('resource-id'))
        if cls in ('WebView', 'RecyclerView', 'ScrollView', 'ViewPager', 'FragmentContainerView'):
            components[cls] += 1
        if attr.get('clickable') == 'true' and res:
            clickable.add(res)
        # Deliberately omit text, content-description, bounds and scrolling offsets.
        signatures[(cls, res, attr.get('clickable') == 'true')] += 1
    digest = hashlib.sha256(repr(sorted(signatures.items())).encode()).hexdigest()[:20]
    primary = packages.most_common(1)[0][0] if packages else (expected_package or '')
    return {'package': primary, 'fingerprint': digest,
            'node_count': len(nodes), 'component_types': dict(components),
            'clickable_ids': sorted(clickable)[:8],
            'privacy': '構造情報のみ。画面文字・入力値・スクリーンショット・XMLは保存しません。'}


def structural_event(previous, current, focus):
    """UI structure changed. Never claim a specific tap/page transition was confirmed."""
    if previous and previous['fingerprint'] == current['fingerprint'] and previous['package'] == current['package']:
        return None
    pkg = current.get('package', '')
    components = current.get('component_types') or {}
    hints = '、'.join(f'{key}×{value}' for key, value in sorted(components.items())) or 'ネイティブUI要素'
    label = ('UI構造を初回確認' if previous is None else 'UI構造に変化を検出')
    return {'type': 'UI_CHANGE', 'category': 'activity', 'severity': 'info',
            'source': 'adb_ui', 'tag': 'UIAutomator', 'process': pkg,
            'package': pkg, 'focus': focus, 'ui_meta': current,
            'summary': f'{label}: {pkg} / {hints} / {current["node_count"]}要素',
            'raw': f'ADB UI階層の構造差分（画面文言・入力値は取得・保存していません）\nActivity: {focus}\nFingerprint: {current["fingerprint"]}\nResource IDs: {", ".join(current["clickable_ids"])}',
            'interpretation_limit': 'アプリ内部の処理・タップ対象・画面名は、この差分だけでは断定できません。'}
