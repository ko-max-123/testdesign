"""Incident evidence collector for ordinary, non-root ADB monitoring.

It NEVER equates leaving an app with a crash. Raw Android exit reasons are
preserved separately from conservative inference. No APK/root is needed.
"""
from __future__ import annotations

from collections import deque
from datetime import datetime
from html import escape
from pathlib import Path
import json
import re
import threading
import time

PRE_SECONDS = 60
POST_SECONDS = 30
MAX_PRE_LINES = 5000
MAX_POST_LINES = 5000
MAX_LINE_LENGTH = 2500

LAUNCHERS = (
    'com.google.android.apps.nexuslauncher', 'com.android.launcher',
    'com.sec.android.app.launcher', 'com.miui.home', 'com.huawei.android.launcher',
    'com.oppo.launcher', 'com.vivo.launcher', 'com.microsoft.launcher',
    'com.motorola.launcher', 'com.android.launcher3',
)

LOG_PROCESS = re.compile(r'AndroidRuntime:\s*Process:\s*([^,\s]+),\s*PID:\s*(\d+)')
FATAL = re.compile(r'FATAL EXCEPTION|Fatal signal\s+\d+|FATAL SIGNAL\b', re.I)
ANR = re.compile(r'\bANR in\s+([\w.]+)', re.I)
NATIVE_NAME = re.compile(r'\bpid\s+\d+\s+\(([^)]+)\)', re.I)
REASON = re.compile(r'\breason\s*[=:]\s*(?:\d+\s*\()?([A-Z_]+)', re.I)
# Format of `dumpsys activity exit-info` differs by Android build; extract only
# clearly labelled fields, and retain raw output if the parser cannot interpret it.
EXIT_REASON_KEYWORDS = ('REASON_CRASH_NATIVE', 'REASON_CRASH', 'REASON_ANR', 'REASON_LOW_MEMORY',
                        'REASON_USER_REQUESTED', 'REASON_USER_STOPPED', 'REASON_EXCESSIVE_RESOURCE_USAGE',
                        'REASON_SIGNALED', 'REASON_OTHER')


def is_target(name: str | None, target: str) -> bool:
    return bool(name and target and (name == target or name.startswith(target + ':')))


def is_launcher(name: str | None) -> bool:
    return bool(name and any(name == p or name.startswith(p + '.') for p in LAUNCHERS))


def classify_exit_info(output: str, target: str, incident_epoch: float | None = None) -> dict:
    """Conservative summary: the output may include OLD exits; do not assign causality."""
    result = {'supported': bool(output.strip()) and not output.lstrip().startswith(('ERROR:', 'Error:', 'Unknown command')),
              'reason': None, 'recent_verified': False, 'note': '終了履歴の取得は端末に依存します。',
              'raw': output[:20000]}
    if not result['supported']:
        result['note'] = '終了履歴を取得できませんでした。Androidバージョンや端末の制限をご確認ください。'
        return result
    # Only choose a reason when one is in a target-associated block. Different
    # Android versions have different formatting and history ordering.
    for segment in re.split(r'(?=ApplicationExitInfo\b|ApplicationExitInfo\{|Historical Process Exit|\*\*\* Exit)', output, flags=re.I):
        if target not in segment:
            continue
        for reason in EXIT_REASON_KEYWORDS:
            if re.search(r'(?<![A-Z_])'+re.escape(reason)+r'(?![A-Z_])', segment):
                result['reason'] = reason
                break
        if result['reason']:
            break
    if result['reason']:
        result['note'] = '同一パッケージの終了履歴に理由が記録されています。ただし今回の異常との時刻照合は未確認です。'
    else:
        result['note'] = '出力は保存しましたが、対象アプリの終了理由は安全に特定できませんでした。'
    # Never set recent_verified based only on log text without a reliable
    # timestamp AND package/pid correspondence.
    return result


class IncidentRecorder:
    def __init__(self, session: Path, target: str, run_adb, redact, emit, events_snapshot, start_epoch=None):
        self.session = Path(session)
        self.target = target
        self.run_adb = run_adb
        self.redact = redact
        self.emit = emit
        self.events_snapshot = events_snapshot
        self.started_at = start_epoch if start_epoch is not None else time.time()
        self.lock = threading.RLock()
        self.ring = deque(maxlen=MAX_PRE_LINES)  # (host time, sanitized line)
        self.incidents = {}
        self.seq = 0
        self.last_candidate = 0
        self.last_trigger = {}
        self.fatal_by_pid = {}  # PID -> (host epoch, sanitized header)
        self.last_target_foreground = 0
        self.target_pid = None
        self.pending_home = None
        self.stopped = False
        self.workers = []
        (self.session/'incidents').mkdir(exist_ok=True, parents=True)

    def set_target(self, target):
        with self.lock:
            self.target = target
            self.pending_home = None
            self.target_pid = None

    def observe_focus(self, old_pkg, new_pkg, processes):
        """Leaving the target for launcher is ONLY a possible incident."""
        now = time.time()
        with self.lock:
            if is_target(new_pkg, self.target):
                self.last_target_foreground = now
                pids = [pid for pid, name in processes.items() if is_target(name,self.target)]
                if pids:
                    self.target_pid = pids[0]
                self.pending_home = None
            elif is_target(old_pkg, self.target) and is_launcher(new_pkg):
                self.pending_home = {'at':now, 'from':old_pkg, 'to':new_pkg,
                                     'pid':self.target_pid}
            else:
                self.pending_home = None

    def observe_processes(self, processes):
        with self.lock:
            if self.pending_home is None:
                return
            pending = self.pending_home
            if time.time()-pending['at'] > 15:
                self.pending_home = None
                return
            # PID disappearance alone cannot prove a crash (normal OS kill).
            pid = pending['pid']
            if pid and pid not in processes:
                self.pending_home = None
                self._start_locked('process_disappeared', '調査候補',
                   'ホームへ移動した直後に対象プロセスPIDが見つからなくなりました。クラッシュとは未確定。',
                   {'pid':pid, 'previous_foreground':pending['from'],
                    'next_foreground':pending['to']})

    def observe_log(self, line, ev=None, process_map=None):
        """Called for EVERY logcat line, even those hidden from normal timeline."""
        now = time.time()
        clean = self.redact(line.rstrip('\r\n'))[:MAX_LINE_LENGTH]
        if not clean:
            return
        process_map = process_map or {}
        with self.lock:
            self.ring.append((now, clean))
            while self.ring and self.ring[0][0] < now-PRE_SECONDS:
                self.ring.popleft()
            for incident in self.incidents.values():
                if incident['state']=='collecting' and now <= incident['collect_until'] and len(incident['after']) < MAX_POST_LINES:
                    incident['after'].append(clean)
            if not self.target:
                return
            pid = (ev or {}).get('pid')
            if pid is None:
                m=re.search(r'^\s*\d{2}-\d{2}\s+\S+\s+(\d+)\s+',clean)
                if m: pid=int(m.group(1))
            name = process_map.get(pid)
            m=LOG_PROCESS.search(clean)
            if m:
                pkg, recorded_pid = m.group(1), int(m.group(2))
                pending=self.fatal_by_pid.get(recorded_pid)
                if is_target(pkg,self.target) and pending and now-pending[0]<=8:
                    self._start_locked('fatal_exception', 'クラッシュログ',
                          '対象アプリのFATAL EXCEPTIONとProcess行を確認しました。',
                          {'pid':recorded_pid, 'log':pending[1]})
                    self.fatal_by_pid.pop(recorded_pid,None)
            anr = ANR.search(clean)
            if anr and is_target(anr.group(1),self.target):
                self._start_locked('anr', 'ANRログ', '対象アプリのANRが報告されました。',
                                   {'pid':pid, 'log':clean})
            if FATAL.search(clean):
                native = NATIVE_NAME.search(clean)
                explicit_target = bool(native and is_target(native.group(1),self.target))
                if pid is not None:
                    self.fatal_by_pid[pid] = (now,clean)
                if is_target(name,self.target) or explicit_target:
                    self._start_locked('fatal_exception', 'クラッシュログ',
                                       '対象プロセスと一致する致命的ログを観測しました。',
                                       {'pid':pid, 'log':clean})
            self.fatal_by_pid = {p:item for p,item in self.fatal_by_pid.items() if now-item[0]<8}

    def manually_mark(self):
        with self.lock:
            return self._start_locked('manual_home', '手動報告',
                '利用者が「突然ホームへ戻った」と記録しました。クラッシュかどうかは未確認です。',
                {'target':self.target}, dedupe=False)

    def _start_locked(self, kind, confidence, explanation, details, dedupe=True):
        now = time.time()
        if dedupe and now-self.last_trigger.get(kind,0)<45:
            return None
        if kind=='process_disappeared' and now-self.last_candidate<60:
            return None
        self.last_trigger[kind]=now
        if kind=='process_disappeared': self.last_candidate=now
        self.seq+=1
        incident_id=f'{datetime.fromtimestamp(now):%Y%m%d_%H%M%S}_{self.seq:03d}'
        incident={
            'id':incident_id, 'target':self.target,'trigger':kind,'confidence':confidence,
            'summary':explanation,'detected_at':datetime.fromtimestamp(now).isoformat(timespec='milliseconds'),
            'detected_epoch':now,'state':'collecting','details':details,
            'before':[line for t,line in self.ring if t>=now-PRE_SECONDS],
            'after':[],'collect_until':now+POST_SECONDS,
            'exit_info':{'supported':False,'reason':None,'recent_verified':False,
                         'note':'終了履歴を問い合わせ中','raw':''},
            'report_path':None,
        }
        self.incidents[incident_id]=incident
        self._save_locked(incident, is_final=False)
        # Never hold logcat up for ADB queries or event callback.
        for fn,args in ((self._exit_info_worker,(incident_id,)),(self._notify,(incident,))):
            worker=threading.Thread(target=fn,args=args,daemon=True)
            self.workers.append(worker)
            worker.start()
        return incident_id

    def _notify(self, incident):
        self.emit({'type':'INCIDENT','category':'error','severity':'critical' if incident['trigger'] in ('anr','fatal_exception') else 'warning',
                   'source':'diagnostic','summary':incident['summary'],
                   'raw':f"検知方式: {incident['trigger']} / 判定: {incident['confidence']}",
                   'incident_id':incident['id'],'process':incident['target']})

    def _exit_info_worker(self, incident_id):
        with self.lock:
            inc=self.incidents.get(incident_id)
            if not inc: return
            target=inc['target']
        # Do not assume adb command succeeds. Return code may be hidden by caller.
        try: result=self.run_adb(['shell','dumpsys','activity','exit-info',target], timeout=12)
        except Exception as exc: result=f'ERROR: {exc}'
        result=self.redact(str(result))[:20000]
        parsed=classify_exit_info(result,target)
        with self.lock:
            inc=self.incidents.get(incident_id)
            if inc:
                inc['exit_info']=parsed
                self._save_locked(inc,is_final=inc['state'] in ('completed','partial'))

    def tick(self):
        now=time.time()
        with self.lock:
            for inc in self.incidents.values():
                if inc['state']=='collecting' and now>=inc['collect_until']:
                    inc['state']='completed'
                    self._save_locked(inc,is_final=True)

    def close(self):
        with self.lock:
            self.stopped=True
            for inc in self.incidents.values():
                if inc['state']=='collecting':
                    inc['state']='partial'
                    self._save_locked(inc,is_final=True)
            workers=list(self.workers)
        for worker in workers:
            if worker is not threading.current_thread(): worker.join(timeout=13)

    def listing(self):
        with self.lock:
            return [{k:v for k,v in inc.items() if k not in ('before','after','exit_info') and k!='collect_until'} |
                    {'before_count':len(inc['before']),'after_count':len(inc['after']),
                     'exit_reason':inc['exit_info'].get('reason'),'exit_info_note':inc['exit_info'].get('note')}
                    for inc in reversed(list(self.incidents.values()))]

    def get(self, incident_id):
        with self.lock:
            inc=self.incidents.get(incident_id)
            if inc is None: return None
            return ({k:v for k,v in inc.items() if k not in ('before','after','collect_until')} |
                    {'before_count':len(inc['before']),'after_count':len(inc['after'])})

    def report(self, incident_id):
        with self.lock:
            inc=self.incidents.get(incident_id)
            if not inc: return None
            return self._html(inc)

    def _save_locked(self, inc, is_final=False):
        folder=self.session/'incidents'/inc['id']
        folder.mkdir(parents=True,exist_ok=True)
        if is_final: inc['report_path']=str(folder/'report.html')
        public={k:v for k,v in inc.items() if k not in ('before','after','collect_until')}
        public['before_count']=len(inc['before'])
        public['after_count']=len(inc['after'])
        (folder/'incident.json').write_text(json.dumps(public,indent=2,ensure_ascii=False),encoding='utf-8')
        if is_final:
            lines=['--- 直前60秒・最大5000行 ---',*inc['before'],
                   '--- 異常発生後30秒・最大5000行 ---',*inc['after']]
            (folder/'context_logcat.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
            (folder/'exit_info.txt').write_text(inc['exit_info'].get('raw',''),encoding='utf-8')
            try:
                events=[e for e in self.events_snapshot() if abs(e.get('epoch',0)-inc['detected_epoch']) <= PRE_SECONDS+POST_SECONDS and
                        inc['detected_epoch']-PRE_SECONDS<=e.get('epoch',0)<=inc['detected_epoch']+POST_SECONDS]
            except Exception: events=[]
            (folder/'related_events.json').write_text(json.dumps(events,indent=2,ensure_ascii=False),encoding='utf-8')
            (folder/'report.html').write_text(self._html(inc),encoding='utf-8')
            inc['report_path']=str(folder/'report.html')

    def _html(self,inc):
        h=lambda x: escape(str(x),quote=True)
        notes='''<li>ホームへの移動だけではクラッシュと確定できません。</li>
<li>終了履歴の理由があっても、時刻・PIDが照合できるまでは今回の事象と断定できません。</li>
<li>前後ログには個人情報が含まれ得ます。外部共有前に必ず確認してください。</li>'''
        return f'''<!doctype html><html lang="ja"><head><meta charset="utf-8"><title>Incident {h(inc['id'])}</title>
<style>body{{font:14px system-ui;background:#101820;color:#dce8f1;max-width:1080px;margin:auto;padding:32px;line-height:1.6}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#08111a;padding:16px;border:1px solid #344653;border-radius:8px;max-height:560px;overflow:auto}}small{{color:#9eb3c1}}h2{{margin-top:32px}}.flag{{border:1px solid #b08744;padding:5px 9px;border-radius:7px}}</style></head><body>
<h1>Android Live Inspector — 異常調査レポート</h1>
<p><span class="flag">{h(inc['confidence'])}</span> &nbsp; {h(inc['detected_at'])}</p>
<p><b>対象：</b>{h(inc['target'])} ／ <b>検出：</b>{h(inc['trigger'])} ／ <b>状態：</b>{h(inc['state'])}</p>
<p>{h(inc['summary'])}</p><h2>判定上の注意</h2><ul>{notes}</ul>
<h2>終了履歴（ADB）</h2><p>{h(inc['exit_info'].get('note'))}</p><p>終了理由候補：{h(inc['exit_info'].get('reason') or '特定できず')}</p>
<pre>{h(inc['exit_info'].get('raw') or '未取得')}</pre>
<h2>検出時の追加情報</h2><pre>{h(json.dumps(inc['details'],ensure_ascii=False,indent=2))}</pre>
<h2>異常前のLogcat（最大60秒）</h2><pre>{h(chr(10).join(inc['before']) or '記録なし')}</pre>
<h2>異常後のLogcat（最大30秒）</h2><pre>{h(chr(10).join(inc['after']) or '記録なし')}</pre>
<small>このレポートは観測事実と調査候補をまとめたものです。原因の自動確定ではありません。</small></body></html>'''
