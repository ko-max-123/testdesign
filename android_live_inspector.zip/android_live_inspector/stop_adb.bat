@echo off
cd /d "%~dp0"
if exist tools\adb.exe (tools\adb.exe kill-server) else (adb kill-server)
pause
