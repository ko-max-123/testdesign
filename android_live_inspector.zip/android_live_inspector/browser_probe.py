"""Best-effort PC-only Chrome/WebView observer over Android's existing CDP sockets.

No APK, root, proxy, certificate change, JavaScript injection or response-body reads.
Only debugging-enabled targets can be observed. Everything stays on the PC.
"""
import base64
import hashlib
import json
import os
import re
import socket
import struct
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime

SOCKET_RX = re.compile(r'(?<![\w.])(?:chrome_devtools_remote|webview_devtools_remote_\d+)(?!\w)')
SECRET_WORDS = re.compile(r'(?i)(authorization|bearer\s+\S+|password|access[_-]?token|refresh[_-]?token|id[_-]?token|api[_-]?key|cookie|session[_-]?id|secret)')
SAFE_SEGMENT = re.compile(r'^[A-Za-z_][A-Za-z_\-]{0,35}$')
MAX_TARGETS = 6


def safe_url(value):
    """Omit all query/fragment/userinfo; anonymize potentially identifying path IDs."""
    try:
        u = urllib.parse.urlsplit(str(value))
        if u.scheme not in ('http', 'https') or not u.hostname:
            return '(URL未公開・未取得)'
        port = ':'+str(u.port) if u.port else ''
        host = u.hostname.lower().encode('idna').decode('ascii')
        if ':' in host: host = '['+host+']'
        clean=[]
        for segment in u.path.split('/')[1:9]:
            decoded=urllib.parse.unquote(segment)
            clean.append(decoded if SAFE_SEGMENT.fullmatch(decoded) and not SECRET_WORDS.search(decoded) else ('{id}' if decoded else ''))
        path = '/' + '/'.join(clean) if clean else '/'
        if len(u.path.split('/'))>9: path+='/{…}'
        return f'{u.scheme}://{host}{port}{path}'[:300]
    except (ValueError, UnicodeError):
        return '(URLを安全に表示できません)'


def safe_message(value):
    """Do not persist unconstrained logs or console messages which may contain secrets."""
    s = str(value or '')[:350]
    s = re.sub(r'https?://[^\s<>"\']+', lambda m: safe_url(m.group(0)), s)
    s = re.sub(r'(?i)\b(?:Bearer\s+|access_token\s*[=:]|password\s*[=:]|api_key\s*[=:])\S+', '[REDACTED]', s)
    return s[:220]


def discover_sockets(unix_data):
    """Only sockets publicly visible via adb shell; no access-control bypass."""
    found=set(SOCKET_RX.findall(unix_data or ''))
    return sorted(found, key=lambda v:(v!='chrome_devtools_remote',v))[:MAX_TARGETS]


def cdp_event(method, params, origin, process, requests):
    """Turn one CDP event into zero or one privacy-minimized timeline observations."""
    params=params if isinstance(params,dict) else {}
    base={'source':'cdp','origin':origin, 'process':process, 'timestamp_source':'host',
          'source_role':'other','tag':'CDP', 'severity':'info'}
    if method in ('Page.frameNavigated','Page.navigatedWithinDocument'):
        frame=params.get('frame') or params
        if method=='Page.frameNavigated' and frame.get('parentId'): return None
        url=safe_url(frame.get('url',''))
        if url.startswith('('): return None
        return dict(base,type='BROWSER_NAV' if origin=='chrome' else 'WEBVIEW_NAV',category='browser',
                    summary=f'ページ遷移を観測: {url}',url=url,raw=f'{method}: {url}')
    if method=='Network.requestWillBeSent':
        request=params.get('request') or {}
        url=safe_url(request.get('url',''))
        if url.startswith('('):return None
        ident=str(params.get('requestId',''))
        if ident:
            requests[ident]={'url':url,'method':str(request.get('method','GET'))[:12],
                            'resource_type':str(params.get('type',''))[:24]}
            if len(requests)>400: requests.pop(next(iter(requests)))
        # Limit volume: network request event is useful for API calls, not images/fonts.
        resource_type=str(params.get('type',''))
        if resource_type not in ('XHR','Fetch','Document'): return None
        http_method=str(request.get('method','GET'))[:12]
        return dict(base,type='HTTP_REQUEST',category='network',
                    summary=f'{http_method} {url} ({resource_type})',url=url,http_method=http_method,
                    resource_type=resource_type,raw=f'CDP Network.requestWillBeSent: {http_method} {url} ({resource_type})')
    if method=='Network.responseReceived':
        response=params.get('response') or {}
        resource_type=str(params.get('type',''))
        if resource_type not in ('XHR','Fetch','Document'):return None
        prior=requests.get(str(params.get('requestId','')), {})
        url=prior.get('url') or safe_url(response.get('url',''))
        code=response.get('status')
        if not isinstance(code,(int,float)):return None
        status=int(code)
        severity='error' if status>=500 else 'warning' if status>=400 else 'info'
        verb=prior.get('method','HTTP')
        return dict(base,type='HTTP_RESPONSE',category='network',severity=severity,
                    summary=f'HTTP {status} · {verb} {url}',url=url,http_status=status,
                    raw=f'CDP Network.responseReceived: HTTP {status} · {verb} {url} (本文・ヘッダー非取得)')
    if method=='Network.loadingFailed':
        prior=requests.get(str(params.get('requestId','')), {})
        if not prior or prior.get('resource_type') not in ('XHR','Fetch','Document'):return None
        reason=safe_message(params.get('errorText','読み込み失敗'))
        return dict(base,type='NETWORK_FAILURE',category='network',severity='warning',
                    summary=f'通信の読み込み失敗: {prior["url"]} / {reason}',url=prior['url'],
                    raw=f'CDP Network.loadingFailed: {reason} (HTTPステータスとは異なります)')
    if method=='Runtime.exceptionThrown':
        details=params.get('exceptionDetails') or {}
        summary=safe_message(details.get('text','JavaScript exception'))
        return dict(base,type='JS_ERROR',category='error',severity='error',
                    summary=f'JavaScript例外: {summary}',raw=f'CDP Runtime.exceptionThrown: {summary}')
    if method=='Log.entryAdded':
        entry=params.get('entry') or {}
        level=entry.get('level','')
        if level not in ('error','warning'): return None
        summary=safe_message(entry.get('text',''))
        return dict(base,type='BROWSER_CONSOLE',category='error' if level=='error' else 'warning',
                    severity='error' if level=='error' else 'warning',summary=f'コンソール: {summary}',
                    raw=f'CDP Log.entryAdded: {summary}')
    return None


class WebSocketReader:
    """Small stdlib-only, read-oriented RFC6455 client for local CDP endpoints."""
    def __init__(self,url):
        u=urllib.parse.urlsplit(url)
        if u.scheme!='ws' or u.hostname not in ('127.0.0.1','localhost') or not u.port:
            raise ValueError('CDP websocket must be local')
        self.s=socket.create_connection(('127.0.0.1',u.port),timeout=4)
        self.s.settimeout(5)
        key=base64.b64encode(os.urandom(16)).decode()
        path=u.path or '/'
        if u.query:path+='?'+u.query
        self.s.sendall((f'GET {path} HTTP/1.1\r\nHost: 127.0.0.1:{u.port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n').encode('ascii'))
        header=b''
        while b'\r\n\r\n' not in header and len(header)<10000:
            header+=self.s.recv(1)
        if not header.startswith(b'HTTP/1.1 101') and not header.startswith(b'HTTP/1.0 101'):
            self.close();raise OSError('CDP websocket handshake rejected')
        expected=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode()
        if ('sec-websocket-accept: '+expected).lower() not in header.decode('latin1').lower():
            self.close();raise OSError('CDP websocket handshake invalid')
    def close(self):
        try:self.s.close()
        except OSError:pass
    def send(self, data, opcode=1):
        payload=(json.dumps(data,separators=(',',':')).encode() if isinstance(data,dict) else bytes(data))
        if len(payload)>65535:raise ValueError('message too long')
        mask=os.urandom(4)
        head=bytes([0x80|opcode])+(bytes([0x80|len(payload)]) if len(payload)<126 else b'\xfe'+struct.pack('!H',len(payload)))
        self.s.sendall(head+mask+bytes(v^mask[i%4] for i,v in enumerate(payload)))
    def _read_exact(self,n):
        data=bytearray()
        while len(data)<n:
            part=self.s.recv(n-len(data))
            if not part:raise EOFError('CDP websocket closed')
            data.extend(part)
        return bytes(data)
    def recv(self):
        head=self._read_exact(2)
        opcode=head[0]&0x0f
        size=head[1]&0x7f
        if size==126:size=struct.unpack('!H',self._read_exact(2))[0]
        elif size==127:size=struct.unpack('!Q',self._read_exact(8))[0]
        if size>4*1024*1024:raise ValueError('CDP frame too large')
        mask=self._read_exact(4) if head[1]&0x80 else None
        data=self._read_exact(size)
        if mask:data=bytes(v^mask[i%4] for i,v in enumerate(data))
        if opcode==8:raise EOFError('CDP websocket closing')
        if opcode==9:self.send(data,opcode=10);return None
        if opcode==1:return json.loads(data.decode('utf-8'))
        return None


class BrowserProbe:
    def __init__(self,adb,serial,emit,process_lookup):
        self.adb=adb; self.serial=serial;self.emit=emit;self.process_lookup=process_lookup
        self.closed=threading.Event();self.sockets={};self.status={'state':'starting','chrome':'未接続','webview':'未接続','targets':0,'last_error':'','body_capture':False}
        self.mu=threading.Lock();self.watchers={}
    def run_adb(self,args,timeout=5):
        p=subprocess.run([self.adb,'-s',self.serial]+args,capture_output=True,encoding='utf-8',errors='replace',timeout=timeout)
        if p.returncode:raise OSError('ADB command unavailable')
        return p.stdout.strip()
    def stop(self):
        self.closed.set()
        with self.mu: sockets=list(self.sockets.values())
        for port in sockets:
            try:self.run_adb(['forward','--remove',f'tcp:{port}'],timeout=2)
            except Exception:pass
    def _fetch_targets(self,port):
        req=urllib.request.Request(f'http://127.0.0.1:{port}/json/list',headers={'User-Agent':'AndroidLiveInspector/1.3'})
        with urllib.request.urlopen(req,timeout=3) as response:
            if response.status!=200:raise OSError('CDP endpoint unavailable')
            raw=response.read(200000)
        obj=json.loads(raw)
        return obj if isinstance(obj,list) else []
    def _watch(self,sockname,target,port):
        key=sockname+':'+str(target.get('id',''))
        try:
            wsurl=str(target.get('webSocketDebuggerUrl',''))
            u=urllib.parse.urlsplit(wsurl)
            if u.scheme!='ws' or not u.path: return
            # Never connect to an address advertised by the remote endpoint.
            wsurl=f'ws://127.0.0.1:{port}{u.path}'+(('?'+u.query) if u.query else '')
            origin='chrome' if sockname=='chrome_devtools_remote' else 'webview'
            pid=int(sockname.rsplit('_',1)[-1]) if origin=='webview' else None
            process=self.process_lookup(pid) if pid else 'com.android.chrome'
            if not process: process='unknown-webview-process'
            connection=WebSocketReader(wsurl)
            requests={}
            for i,domain in enumerate(('Network.enable','Page.enable','Runtime.enable','Log.enable'),start=1):
                connection.send({'id':i,'method':domain})
            while not self.closed.is_set():
                try:message=connection.recv()
                except socket.timeout:continue
                if not isinstance(message,dict) or 'method' not in message:continue
                event=cdp_event(message['method'],message.get('params',{}),origin,process,requests)
                if event:
                    # The field is for attribution, not claiming native app internals.
                    event['source_role']='other'
                    self.emit(event)
        except (OSError,ValueError,EOFError,json.JSONDecodeError) as exc:
            with self.mu:self.status['last_error']=str(exc)[:110]
        finally:
            try:connection.close()
            except (NameError,OSError):pass
            with self.mu:self.watchers.pop(key,None)
    def run(self):
        """Auto attach when debugging is allowed; failure is a capability limit."""
        try:
            while not self.closed.is_set():
                try: discovered=discover_sockets(self.run_adb(['shell','cat','/proc/net/unix'],timeout=5))
                except (OSError,subprocess.TimeoutExpired):discovered=[]
                # Chrome may not show in /proc/net/unix on some devices. Probe harmlessly.
                if 'chrome_devtools_remote' not in discovered:discovered.insert(0,'chrome_devtools_remote')
                for name in discovered[:MAX_TARGETS]:
                    if self.closed.is_set():break
                    try:
                        with self.mu:port=self.sockets.get(name)
                        if not port:
                            value=self.run_adb(['forward','tcp:0','localabstract:'+name],timeout=4)
                            port=int(value.strip())
                            if not 1<=port<=65535:raise OSError('invalid forwarded port')
                            with self.mu:self.sockets[name]=port
                        targets=self._fetch_targets(port)
                        page_targets=[t for t in targets if t.get('type') in ('page','webview') and t.get('webSocketDebuggerUrl')]
                        with self.mu:
                            self.status['state']='connected'
                            self.status['chrome' if name=='chrome_devtools_remote' else 'webview']='接続可能'
                            self.status['targets']=sum(x.is_alive() for x in self.watchers.values())
                        for target in page_targets[:10]:
                            key=name+':'+str(target.get('id',''))
                            with self.mu:
                                current=self.watchers.get(key)
                                if current and current.is_alive():continue
                                t=threading.Thread(target=self._watch,args=(name,target,port),daemon=True)
                                self.watchers[key]=t
                            t.start()
                    except (OSError,ValueError,subprocess.TimeoutExpired,urllib.error.URLError,json.JSONDecodeError):
                        # Normal when Chrome is closed or WebView debugging is disabled.
                        pass
                with self.mu:
                    self.status['targets']=sum(w.is_alive() for w in self.watchers.values())
                    if not self.status['targets']:
                        self.status['state']='unavailable'
                        self.status['chrome']='未接続 / デバッグ不可'
                        self.status['webview']='未接続 / デバッグ不可'
                self.closed.wait(5)
        finally:self.stop()
    def get_status(self):
        with self.mu:return dict(self.status)
