import collections, asyncio, json, os, re, subprocess, sys, threading, time, webbrowser, shutil, urllib.parse
from datetime import datetime, timedelta
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from log_analysis import classify as classify_log, parse_ps, source_role
from event_explainer import explain
from app_activity import package_from_focus, activity_observation, related_packages, new_app_record
from flow_analysis import build_flow

ROOT=Path(__file__).resolve().parent
UI=ROOT/'ui'; SESS=ROOT/'sessions'
PORT=8765
VERSION="1.2.7"
MAX_RAW_BYTES=8*1024*1024
MAX_RAW_PARTS=12
MAX_SESSION_DAYS=14
MAX_SESSIONS=30
CONTEXT_BEFORE=12
CONTEXT_AFTER_SECONDS=8
ADB_CANDIDATES=[ROOT/'tools'/'adb.exe', ROOT/'tools'/'adb', Path('adb')]

def adb_cmd():
    for p in ADB_CANDIDATES:
        if str(p)=='adb': return 'adb'
        if p.exists(): return str(p)
    return 'adb'
ADB=adb_cmd()

def run(args, timeout=8):
    try:
        return subprocess.run([ADB]+args, capture_output=True, text=True, errors='replace', timeout=timeout).stdout.strip()
    except Exception as e: return f'ERROR: {e}'

def devices():
    out=run(['devices','-l'])
    ds=[]
    for line in out.splitlines():
        parts=line.strip().split()
        if len(parts)<2 or parts[1]!='device':
            continue
        serial=parts[0]
        m=re.search(r'\bmodel:([^ ]+)',line)
        ds.append({'serial':serial,'model':m.group(1) if m else serial})
    return ds

class State:
    def __init__(self):
        self.lock=threading.Lock(); self.events=[]; self.clients=[]; self.proc=None; self.serial=None
        self.session=None; self.raw=None; self.running=False; self.max_events=2000; self.worker=None; self.generation=0; self.last_error=None; self.auto_reconnect=True; self.next_id=0; self.pending=[]; self.focus_name=None; self.processes={}; self.target_package=""; self.pid_refresh_at=0; self.apps={}; self.last_front_package=None
    def emit(self, ev):
        ev.setdefault('ts',datetime.now().strftime('%H:%M:%S.%f')[:-3])
        ev.setdefault('captured_at',datetime.now().isoformat(timespec='milliseconds'))
        ev.setdefault('epoch',time.time())
        ev.setdefault('severity','error' if ev.get('category')=='error' else 'info')
        ev.setdefault('timestamp_source','host')
        ev['related_packages'] = related_packages(ev)
        ev['analysis'] = explain(ev)
        with self.lock:
            obs=activity_observation(ev)
            if obs:
                self.note_app_locked(obs['destination'], 'launch', ev.get('captured_at'), ev.get('summary',''))
            self.next_id+=1; ev['id']=self.next_id
            if ev.get('severity') in ('critical', 'error'):
                ev['context_before']=[x['id'] for x in self.events[-CONTEXT_BEFORE:]]
                ev['context_after']=[]
                self.pending.append((ev,time.time()+CONTEXT_AFTER_SECONDS))
            else:
                now=time.time(); self.pending=[(e,until) for e,until in self.pending if until>now]
                for error,until in self.pending: error['context_after'].append(ev['id'])
            self.events.append(ev); self.events=self.events[-self.max_events:]
        if self.session:
            with open(self.session/'events.jsonl','a',encoding='utf-8') as f: f.write(json.dumps(ev,ensure_ascii=False)+'\n')
    def note_app_locked(self, package, action, when=None, activity=''):
        if not package: return
        record=self.apps.setdefault(package,new_app_record(package,when))
        record['last_seen']=when or datetime.now().isoformat(timespec='seconds')
        if action=='foreground': record['foreground_count']+=1
        if action=='launch': record['launch_request_count']+=1
        record['last_action']=action
        if activity: record['last_activity']=activity[:200]

STATE=State()

def refresh_processes(serial, force=False):
    """Best-effort PID->process snapshot; never blocks the logcat stream."""
    now=time.monotonic()
    if not force and now<STATE.pid_refresh_at: return
    STATE.pid_refresh_at=now+8
    out=run(['-s',serial,'shell','ps','-A','-o','PID,NAME'],timeout=6)
    result=parse_ps(out)
    if not result:
        result=parse_ps(run(['-s',serial,'shell','ps','-A'],timeout=6))
    if result:
        with STATE.lock: STATE.processes=result

def process_refresher(serial,generation):
    while STATE.generation==generation and STATE.running:
        try: refresh_processes(serial)
        except Exception: pass
        time.sleep(2)

SECRET_RX=[re.compile(r"(?i)(authorization\s*[:=]\s*bearer\s+)\S+"),re.compile(r"(?i)((?:access_token|refresh_token|id_token|password|api_key|cookie|set-cookie)\s*[:=]\s*)[^\s,;]+") ]
def redact(line):
    for rx in SECRET_RX: line=rx.sub(r"\1[REDACTED]",line)
    return line

def cleanup_sessions():
    SESS.mkdir(exist_ok=True)
    folders=sorted((x for x in SESS.iterdir() if x.is_dir()),key=lambda x:x.stat().st_mtime,reverse=True)
    cutoff=time.time()-MAX_SESSION_DAYS*86400
    for i,folder in enumerate(folders):
        if folder==STATE.session: continue
        if i>=MAX_SESSIONS or folder.stat().st_mtime<cutoff:
            shutil.rmtree(folder,ignore_errors=True)

def rotate_raw():
    if STATE.raw and STATE.raw.tell()>=MAX_RAW_BYTES:
        STATE.raw.close()
        for i in range(MAX_RAW_PARTS-1,0,-1):
            old=STATE.session/f'logcat.{i:02d}.txt'
            new=STATE.session/f'logcat.{i+1:02d}.txt'
            if old.exists():
                if i+1>MAX_RAW_PARTS: old.unlink()
                else: old.replace(new)
        base=STATE.session/'logcat.txt'
        if base.exists(): base.replace(STATE.session/'logcat.01.txt')
        STATE.raw=open(base,'w',encoding='utf-8',errors='replace')

def monitor(serial, generation):
    STATE.running=True; STATE.serial=serial
    stamp=datetime.now().strftime('%Y-%m-%d_%H%M%S'); STATE.session=SESS/stamp; STATE.session.mkdir(parents=True,exist_ok=True)
    STATE.raw=open(STATE.session/'logcat.txt','a',encoding='utf-8',errors='replace')
    cleanup_sessions()
    with STATE.lock:
        STATE.apps={}; STATE.last_front_package=None; STATE.focus_name=None
    STATE.emit({'type':'SYSTEM','category':'system','summary':f'Monitoring started: {serial}'})
    with STATE.lock: STATE.processes={}
    STATE.pid_refresh_at=0
    threading.Thread(target=process_refresher,args=(serial,generation),daemon=True).start()
    threading.Thread(target=focus_tracker,args=(serial,generation),daemon=True).start()
    # Never clear the device-wide log buffer. -T starts at the current host-time boundary.
    cmd=[ADB,'-s',serial,'logcat','-v','threadtime','-T','1']
    try:
        STATE.proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace',bufsize=1)
        for line in STATE.proc.stdout:
            if not STATE.running or STATE.generation != generation: break
            line=redact(line)
            STATE.raw.write(line); STATE.raw.flush(); rotate_raw()
            # The process map is replaced atomically, never mutated in place.
            ev=classify_log(line,STATE.processes,STATE.target_package)
            if ev: STATE.emit(ev)
    except Exception as e:
        STATE.last_error=str(e)
        STATE.emit({'type':'SYSTEM','category':'error','summary':str(e)})
    finally:
        if STATE.raw: STATE.raw.close()
        if STATE.generation == generation: STATE.running=False

def start_monitor(serial):
    if not serial or serial not in [d["serial"] for d in devices()]: return False
    if STATE.running and STATE.serial == serial: return True
    stop_monitor()
    STATE.auto_reconnect=True
    STATE.generation += 1
    generation=STATE.generation
    STATE.running=True
    STATE.worker=threading.Thread(target=monitor,args=(serial,generation),daemon=True)
    STATE.worker.start()
    return True

def stop_monitor():
    STATE.running=False
    STATE.generation+=1
    if STATE.proc:
        try: STATE.proc.terminate()
        except: pass

FOCUS_CAPTURE = re.compile(r'((?:[A-Za-z_][\w]*\.)+[A-Za-z_][\w]*(?:/[\w.$]+)?)')
def parse_focus_output(output):
    """Handle recent Android window and activity dumps; avoid random unrelated lines."""
    # Window focus beats activity resume. Component name has optional /Activity.
    for prefix in ('mCurrentFocus=', 'mFocusedApp=', 'topResumedActivity=', 'mResumedActivity:', 'mResumedActivity=', 'ResumedActivity:'):
        for line in output.splitlines():
            if prefix not in line:
                continue
            found=FOCUS_CAPTURE.findall(line.split(prefix,1)[1])
            if found:
                return next((x for x in found if '/' in x),found[0])
    return None

def snapshot(serial):
    focus=run(['-s',serial,'shell','dumpsys','window','windows'],timeout=7)
    found=parse_focus_output(focus)
    if found: return found
    # Modern Android devices sometimes hide current window but expose resumed Activity.
    focus=run(['-s',serial,'shell','dumpsys','activity','activities'],timeout=7)
    return parse_focus_output(focus) or 'unknown'

def focus_tracker(serial,generation):
    """Collect foreground changes in background, independently of open browser tabs."""
    while STATE.generation == generation and STATE.running:
        try:
            focus=snapshot(serial)
            pkg=package_from_focus(focus)
            if pkg:
                with STATE.lock:
                    prev=STATE.focus_name
                    if pkg != STATE.last_front_package or (focus != prev):
                        STATE.focus_name=focus
                        if pkg != STATE.last_front_package:
                            STATE.note_app_locked(pkg,'foreground',activity=focus)
                        STATE.last_front_package=pkg
                        changed = prev is not None and focus != prev
                    else:
                        changed=False
                if changed:
                    STATE.emit({'type':'FOCUS_CHANGE','category':'activity','summary':f'{prev} → {focus}', 'from':prev,'to':focus})
        except Exception as e:
            STATE.last_error=f'foreground polling: {e}'
        time.sleep(2)


def deeplink(serial, uri):
    if not serial or serial not in [d['serial'] for d in devices()]: return 'ERROR: device not connected'
    if not isinstance(uri,str) or len(uri)>2048 or not re.match(r'^(https?://|[a-zA-Z][\w+.-]*://)',uri): return 'ERROR: invalid URI'
    try:
        p=subprocess.run([ADB,'-s',serial,'shell','am','start','-W','-a','android.intent.action.VIEW','-d',uri],capture_output=True,text=True,errors='replace',timeout=15)
        out=(p.stdout+'\n'+p.stderr).strip()
        STATE.emit({'type':'DEEPLINK_TEST','category':'deeplink','summary':f'Launch: {redact(uri)}','raw':redact(out)})
        return out
    except Exception as e: return str(e)

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        rel=path.split('?',1)[0].lstrip('/') or 'index.html'; return str(UI/rel)
    def log_message(self,*a): pass
    def json(self,obj,status=200):
        b=json.dumps(obj,ensure_ascii=False).encode(); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.startswith('/api/version'): return self.json({'version':VERSION, 'port':self.server.server_port})
        if self.path.startswith('/api/devices'): return self.json({'devices':devices(),'running':STATE.running,'serial':STATE.serial,'target_package':STATE.target_package})
        if self.path.startswith('/api/apps'):
            with STATE.lock: apps=[dict(x) for x in STATE.apps.values()]
            return self.json({'apps':sorted(apps,key=lambda x:x['last_seen'],reverse=True),'serial':STATE.serial,'running':STATE.running})
        if self.path.startswith('/api/events'):
            with STATE.lock: ev=list(STATE.events)
            return self.json({'events':ev,'running':STATE.running,'serial':STATE.serial,'session':str(STATE.session) if STATE.session else None,'last_error':STATE.last_error})
        if self.path.startswith('/api/focus'):
            return self.json({'focus':STATE.focus_name or 'unknown'})
        if self.path.startswith('/api/flow'):
            with STATE.lock:
                items=build_flow(STATE.events)
            return self.json({'flow':items})
        return super().do_GET()
    def end_headers(self):
        # No stale HTML/JS/CSS when upgrading from an older extracted folder.
        if not self.path.startswith('/api/'):
            self.send_header('Cache-Control','no-store, max-age=0')
        super().end_headers()
    def do_POST(self):
        if self.headers.get("Origin") not in (None,f"http://127.0.0.1:{self.server.server_port}",f"http://localhost:{self.server.server_port}"): return self.json({"error":"forbidden origin"},403)
        try:
            n=int(self.headers.get("Content-Length","0"))
            if n>8192: return self.json({"error":"payload too large"},413)
            data=json.loads(self.rfile.read(n) or b"{}")
        except (ValueError,TypeError): return self.json({"error":"invalid JSON"},400)
        if self.path=='/api/target':
            package=str(data.get('package','')).strip()
            if package and (len(package)>200 or not re.fullmatch(r'[A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)+',package)):
                return self.json({'error':'invalid package name'},400)
            with STATE.lock:
                STATE.target_package=package
                for e in STATE.events:
                    if e.get('process') is not None:
                        e['source_role']=source_role(e['process'],package)
                        e['analysis']=explain(e)
            return self.json({'ok':True,'target_package':package})
        if self.path=='/api/start':
            serial=data.get('serial'); ok=start_monitor(serial); return self.json({'ok':ok},200 if ok else 400)
        if self.path=='/api/stop':
            STATE.auto_reconnect=False
            stop_monitor()
            return self.json({'ok':True})
        if self.path=='/api/clear':
            with STATE.lock: STATE.events.clear()
            return self.json({'ok':True})
        if self.path=='/api/deeplink': return self.json({'result':deeplink(data.get('serial') or STATE.serial,data.get('uri',''))})
        return self.json({'error':'not found'},404)

def bind_server():
    # Never start a second monitor against an already occupied port, and never
    # quietly open an older tool instance in the browser.
    try:
        return ThreadingHTTPServer(('127.0.0.1',PORT), Handler)
    except OSError as exc:
        print('\n[起動中止] localhost:'+str(PORT)+' は既に使用中です。')
        print('以前のAndroid Live Inspectorのstart.batウィンドウを終了してください。')
        print('その後、v'+VERSION+' のstart.batを再実行してください。')
        print('原因: '+str(exc)+'\n')
        return None

def main():
    # Check port *before* touching the devices or starting any worker thread.
    server=bind_server()
    if server is None: return 1
    SESS.mkdir(exist_ok=True)
    cleanup_sessions()
    ds=devices()
    if ds: start_monitor(ds[0]['serial'])
    def reconnect():
        while True:
            time.sleep(4)
            if not STATE.running and STATE.auto_reconnect:
                available=devices()
                if available: start_monitor(available[0]['serial'])
    threading.Thread(target=reconnect,daemon=True).start()
    threading.Timer(0.8,lambda:webbrowser.open(f'http://127.0.0.1:{PORT}/?v={VERSION}')).start()
    print(f'Android Live Inspector v{VERSION}: http://127.0.0.1:{PORT}')
    print('Ctrl+C to stop')
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: stop_monitor(); server.server_close()
    return 0
if __name__=='__main__': sys.exit(main())
