"""Extract Android app observations without mistaking log authors for foreground apps."""
import re
from datetime import datetime

PKG = r'[A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)+'
COMPONENT = re.compile(r'\b(?:cmp|component)=(' + PKG + r')/[^\s}\]]+')
FROM_UID = re.compile(r'\bfrom uid \d+ \((' + PKG + r')\)')
PACKAGE_ARG = re.compile(r'\bpkg=(' + PKG + r')\b')
START_ACTIVITY = re.compile(r'\bSTART\s+u\d+\s*\{|\bSTART_ACTIVITY\b', re.I)
FOCUS_COMPONENT = re.compile(r'(' + PKG + r')/([\w.$]+)')
KNOWN_NAMES = {
    'com.android.chrome': 'Chrome',
    'com.google.android.gms': 'Google Play開発者サービス',
    'com.android.settings': '設定',
    'com.android.systemui': 'Android System UI',
}

def package_from_focus(focus):
    match = FOCUS_COMPONENT.search(focus or '')
    if match: return match.group(1)
    if re.fullmatch(PKG, (focus or '').strip()): return focus.strip()
    return None


def activity_observation(event):
    """Return launch destination+origin from an observed START log, or None.

    START is a request, not proof that the Activity became visible.
    """
    if event.get('tag') != 'ActivityTaskManager':
        return None
    raw = event.get('raw', '')
    if not START_ACTIVITY.search(raw):
        return None
    component = COMPONENT.search(raw)
    if not component:
        return None
    source = FROM_UID.search(raw)
    pkg = PACKAGE_ARG.search(raw)
    return {'destination': component.group(1),
            'source': source.group(1) if source else None,
            'requested_package': pkg.group(1) if pkg else None}


def related_packages(event):
    """Explicit log associations only. OS errors are NOT attributed to an app by time."""
    found = set()
    process = event.get('process')
    if process and re.fullmatch(PKG + r'(?::[\w.]+)?', process):
        found.add(process.split(':', 1)[0])
    for key in ('from', 'to'):
        pkg = package_from_focus(event.get(key, ''))
        if pkg:
            found.add(pkg)
    obs = activity_observation(event)
    if obs:
        found.add(obs['destination'])
        if obs['source']:
            found.add(obs['source'])
        if obs['requested_package']:
            found.add(obs['requested_package'])
    return sorted(found)


def new_app_record(package, when=None):
    return {'package': package, 'label': KNOWN_NAMES.get(package, package),
            'first_seen': when or datetime.now().isoformat(timespec='seconds'),
            'last_seen': when or datetime.now().isoformat(timespec='seconds'),
            'foreground_count': 0, 'launch_request_count': 0,
            'last_activity': '', 'last_action': ''}
