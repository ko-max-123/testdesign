@echo off
setlocal
cd /d "%~dp0"
if not exist "tools" mkdir "tools"
set "SOURCE="
if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "SOURCE=%LOCALAPPDATA%\Android\Sdk\platform-tools"
if not defined SOURCE (
  for /f "delims=" %%F in ('where adb.exe 2^>nul') do if not defined SOURCE set "SOURCE=%%~dpF"
)
if not defined SOURCE (
  echo [INFO] Could not find local ADB. Download Platform Tools and copy adb.exe and DLLs to tools.
  echo https://developer.android.com/tools/releases/platform-tools
  pause
  exit /b 1
)
for %%F in (adb.exe AdbWinApi.dll AdbWinUsbApi.dll) do (
  if exist "%SOURCE%\%%F" copy /y "%SOURCE%\%%F" "tools\%%F" >nul
)
if not exist "tools\adb.exe" (
  echo [ERROR] ADB copy failed.
  pause
  exit /b 1
)
echo [OK] ADB copied to tools folder.
call environment_check.bat
