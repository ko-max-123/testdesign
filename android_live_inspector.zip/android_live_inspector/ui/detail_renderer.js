// Shared view for the main panel and independent EVENT DETAIL window.
// Escape all values obtained from ADB and logcat before inserting into markup.
(function(){
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const logLevels={V:'VERBOSE',D:'DEBUG',I:'INFO',W:'WARNING',E:'ERROR',F:'FATAL',A:'ASSERT',S:'SILENT'};
const roleLabel={target:'対象アプリ',android:'Androidシステム',google:'Google関連',other:'その他のプロセス',unknown:'未特定'};
function analysisCard(e){
  const a=e.analysis;
  if(!a)return `<div class="analysis-placeholder">解析情報はありません。新しいログで確認してください。</div>`;
  const steps=(a.steps||[]).map((step,i)=>`<li class="analysis-step"><div class="step-marker">${esc(['↗','◉','▣','◇'][i%4])}</div><div class="step-body"><strong>${esc(step.label)}</strong><div>${esc(step.detail||'')}</div></div></li>`).join('');
  const facts=(a.facts||[]).map(t=>`<li>${esc(t)}</li>`).join('');
  const unknowns=(a.unknowns||[]).map(t=>`<li>${esc(t)}</li>`).join('');
  return `<section class="analysis-section" aria-label="ログの解析"><h3>ログの解析</h3><div class="analysis-card">
    <div class="analysis-head"><strong>${esc(a.title||'ログの解析')}</strong><span class="level level-${esc(e.severity||'info')}">${esc((e.severity||'info').toUpperCase())}</span></div>
    <div class="analysis-time">${esc(e.log_datetime||e.ts)} · ${esc(a.source_label||'発生元未特定')}</div>
    <p class="analysis-lead">${esc(a.description||'')}</p>
    <ol class="analysis-path">${steps}</ol>
    <div class="analysis-subtitle"><span class="observed-dot"></span>ログで確認できた内容</div>
    <ul class="analysis-facts">${facts||'<li>個別の確認情報なし</li>'}</ul>
    <div class="analysis-subtitle"><span class="unknown-dot"></span>未確認・追加調査が必要</div>
    <ul class="analysis-unknowns">${unknowns||'<li>なし</li>'}</ul>
    <p class="analysis-notice">${esc(a.notice||'')}</p>
  </div></section>`;
}

function renderDetail(e){
  let related=[...(e.context_before||[]),...(e.context_after||[])];
  let context=related.length?`<div class="kv"><div class="k">RELATED EVENTS (時間的近接・因果関係未確定)</div><div class="v">${related.map(id=>`<button class="ctx" data-id="${Number(id)}">#${esc(id)}</button>`).join(' ')}</div></div>`:'';
  let level=e.log_level?`${esc(e.log_level)} (${esc(logLevels[e.log_level]||'未定義')})`:'ツール内部イベント';
  return analysisCard(e)+`<h3 class="raw-heading">技術詳細 / RAW LOG</h3><div class="kv"><div class="k">LOGCAT TIME</div><div class="v">${esc(e.log_datetime||e.ts)} <small>${e.timestamp_source==='device_logcat'?'端末ログ時刻':'PC取得時刻'}</small></div></div>`+
    `<div class="kv"><div class="k">RECEIVED AT (PC)</div><div class="v">${esc(e.captured_at||'未記録（旧イベント）')}</div></div>`+
    `<div class="kv"><div class="k">TYPE / IMPORTANCE</div><div class="v">${esc(e.type)} / <span class="level level-${esc(e.severity||'info')}">${esc((e.severity||'info').toUpperCase())}</span></div></div>`+
    `<div class="kv"><div class="k">LOG LEVEL</div><div class="v">${level}</div></div>`+
    `<div class="kv"><div class="k">ORIGIN / PROCESS</div><div class="v">${esc(e.process||'未特定')} ${e.source_role==='target'?'<i class="target-flag">TARGET</i>':''}</div><div class="v muted">PID: ${esc(e.pid??'-')} / TID: ${esc(e.tid??'-')} / ${esc(roleLabel[e.source_role]||roleLabel.unknown)}（PID照合は参考情報）</div></div>`+
    `<div class="kv"><div class="k">TAG</div><div class="v">${esc(e.tag||'-')}</div></div>`+
    `<div class="kv"><div class="k">SUMMARY</div><div class="v">${esc(e.summary)}</div></div>`+
    `<div class="kv"><div class="k">RAW LOG</div><pre>${esc(e.raw||e.summary)}</pre></div>${context}`;
}
window.ALI_DETAIL={renderDetail};
})();
