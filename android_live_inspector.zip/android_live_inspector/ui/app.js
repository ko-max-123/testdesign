const cats=['error','info','deeplink','activity','webview','network','warning','system'];let enabled=new Set(cats),lastKey='',allEvents=[],selectedId=null,selectedApp='',observedApps=[];
const severityRank={debug:0,info:1,warning:2,error:3,critical:4};
const roleLabel={target:'対象アプリ',android:'Androidシステム',google:'Google関連',other:'その他のプロセス',unknown:'未特定'};
const logLevels={V:'VERBOSE',D:'DEBUG',I:'INFO',W:'WARNING',E:'ERROR',F:'FATAL',A:'ASSERT',S:'SILENT'};
const $=s=>document.querySelector(s);const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
$('#filters').innerHTML=cats.map(c=>`<label><input type="checkbox" data-cat="${c}" checked>${c.toUpperCase()}</label>`).join('');
document.querySelectorAll('[data-cat]').forEach(x=>x.onchange=()=>{x.checked?enabled.add(x.dataset.cat):enabled.delete(x.dataset.cat);lastKey=''});
async function api(url,opt){return (await fetch(url,opt)).json()}async function post(url,data={}){return api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)})}
async function refreshDevices(){let d=await api('/api/devices');let old=$('#device').value;$('#device').innerHTML=d.devices.map(x=>`<option value="${esc(x.serial)}">${esc(x.model)} · ${esc(x.serial)}</option>`).join('');if(old)$('#device').value=old;if(d.serial)$('#device').value=d.serial;if(document.activeElement!==$('#target'))$('#target').value=d.target_package||'';$('#status').textContent=d.running?'● MONITORING':'○ STOPPED';$('#status').className='pill '+(d.running?'ok':'')}
async function refreshEvents(){
  let d=await api('/api/events');allEvents=d.events;
  let q=($('#search').value||'').toLowerCase(), minimum=$('#severity').value;
  let list=d.events.filter(e=>(!selectedApp || (e.related_packages||[]).includes(selectedApp))&&enabled.has(e.category)&&
    (minimum==='all'||(severityRank[e.severity||'info']||0)>=severityRank[minimum])&&
    (!q||[e.summary,e.raw,e.process,e.tag,String(e.pid||'')].join(' ').toLowerCase().includes(q)));
  let key=[list.length,list[0]?.id,list.at(-1)?.id,q,minimum,selectedApp,[...enabled].sort().join(',')].join('|');
  if(key===lastKey)return;
  lastKey=key;
  let t=$('#timeline');
  t.innerHTML=list.map(e=>`<div class="event ${esc(e.category)} ${e.id===selectedId?'selected':''}" data-id="${e.id}"><span class="time">${esc(e.ts)}</span><span class="type"><span class="level level-${esc(e.severity||'info')}">${esc((e.severity||'info').toUpperCase())}</span> ${esc(e.type)}</span><span class="summary"><strong>${esc(e.process|| (e.pid?'PID '+e.pid+' · 未特定':'TOOL'))}</strong>${e.source_role==='target'?'<i class="target-flag">TARGET</i>':''}<small>${esc(e.tag||'')}</small> ${esc(e.summary)}</span></div>`).join('');
  t.querySelectorAll('.event').forEach(el=>el.onclick=()=>{let event=allEvents.find(e=>e.id===Number(el.dataset.id));if(event)show(event)});
  if($('#follow').checked)t.scrollTop=t.scrollHeight;
}
// Explanation cards: render only server-derived observations; never treat sequence as proof of success.
function analysisCard(e){
  const a=e.analysis;
  if(!a)return `<div class="analysis-placeholder">解析情報はありません。新しいログで確認してください。</div>`;
  const steps=(a.steps||[]).map((step,i)=>`<li class="analysis-step"><div class="step-marker">${esc(['↗','◉','▣','◇'][i%4])}</div><div class="step-body"><strong>${esc(step.label)}</strong><div>${esc(step.detail||'')}</div></div></li>`).join('');
  const facts=(a.facts||[]).map(t=>`<li>${esc(t)}</li>`).join('');
  const unknowns=(a.unknowns||[]).map(t=>`<li>${esc(t)}</li>`).join('');
  return `<section class="analysis-section" aria-label="ログの解析"><h3>ログの解析</h3><div class="analysis-card">
    <div class="analysis-head"><strong>${esc(a.title||'ログの解析')}</strong><span class="level level-${esc(e.severity||'info')}">${esc((e.severity||'info').toUpperCase())}</span></div>
    <div class="analysis-time">${esc(e.log_datetime||e.ts)} · ${esc(a.source_label||'発生元未特定')}</div>
    <p class="analysis-lead">${esc(a.description||'')}</p>
    <ol class="analysis-path">${steps}</ol>
    <div class="analysis-subtitle"><span class="observed-dot"></span>ログで確認できた内容</div>
    <ul class="analysis-facts">${facts||'<li>個別の確認情報なし</li>'}</ul>
    <div class="analysis-subtitle"><span class="unknown-dot"></span>未確認・追加調査が必要</div>
    <ul class="analysis-unknowns">${unknowns||'<li>なし</li>'}</ul>
    <p class="analysis-notice">${esc(a.notice||'')}</p>
  </div></section>`;
}
function show(e){
  selectedId=e.id;
  document.querySelectorAll('.event').forEach(el=>el.classList.toggle('selected',Number(el.dataset.id)===e.id));
  let related=[...(e.context_before||[]),...(e.context_after||[])];
  let context=related.length?`<div class="kv"><div class="k">RELATED EVENTS (時間的近接・因果関係未確定)</div><div class="v">${related.map(id=>`<button class="ctx" data-id="${id}">#${id}</button>`).join(' ')}</div></div>`:'';
  let level=e.log_level?`${esc(e.log_level)} (${esc(logLevels[e.log_level]||'未定義')})`:'ツール内部イベント';
  $('#detail').innerHTML=analysisCard(e)+`<h3 class="raw-heading">技術詳細 / RAW LOG</h3><div class="kv"><div class="k">LOGCAT TIME</div><div class="v">${esc(e.log_datetime||e.ts)} <small>${e.timestamp_source==='device_logcat'?'端末ログ時刻':'PC取得時刻'}</small></div></div>`+
    `<div class="kv"><div class="k">RECEIVED AT (PC)</div><div class="v">${esc(e.captured_at||'未記録（旧イベント）')}</div></div>`+
    `<div class="kv"><div class="k">TYPE / IMPORTANCE</div><div class="v">${esc(e.type)} / <span class="level level-${esc(e.severity||'info')}">${esc((e.severity||'info').toUpperCase())}</span></div></div>`+
    `<div class="kv"><div class="k">LOG LEVEL</div><div class="v">${level}</div></div>`+
    `<div class="kv"><div class="k">ORIGIN / PROCESS</div><div class="v">${esc(e.process||'未特定')} ${e.source_role==='target'?'<i class="target-flag">TARGET</i>':''}</div><div class="v muted">PID: ${esc(e.pid??'-')} / TID: ${esc(e.tid??'-')} / ${esc(roleLabel[e.source_role]||roleLabel.unknown)}（PID照合は参考情報）</div></div>`+
    `<div class="kv"><div class="k">TAG</div><div class="v">${esc(e.tag||'-')}</div></div>`+
    `<div class="kv"><div class="k">SUMMARY</div><div class="v">${esc(e.summary)}</div></div>`+
    `<div class="kv"><div class="k">RAW LOG</div><pre>${esc(e.raw||e.summary)}</pre></div>${context}`;
  $('#detail-scroll').scrollTop=0;
  document.querySelectorAll('.ctx').forEach(b=>b.onclick=()=>{let target=allEvents.find(x=>x.id===Number(b.dataset.id));if(target)show(target)});
}
async function focus(){try{let d=await api('/api/focus');$('#focus').textContent='Foreground: '+d.focus}catch{}}
function displayTime(iso){if(!iso)return '-';let d=new Date(iso);return Number.isNaN(d.getTime())?iso:d.toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit',second:'2-digit'});}
async function refreshApps(){
  try{
    const d=await api('/api/apps');observedApps=d.apps||[];
    const q=($('#app-search').value||'').trim().toLowerCase();
    const filtered=observedApps.filter(a=>[a.label,a.package].join(' ').toLowerCase().includes(q));
    $('#app-count').textContent=observedApps.length+'件';
    $('#app-all').classList.toggle('selected-app',!selectedApp);
    $('#observed-apps').innerHTML=filtered.map(a=>{
      const hasFocus=a.foreground_count>0, mode=hasFocus?'画面表示を確認':'起動要求のみ';
      return `<button class="app-entry ${selectedApp===a.package?'selected-app':''}" data-package="${esc(a.package)}" title="${esc(a.package)}">
        <span class="app-title">${esc(a.label)}</span><span class="app-mode ${hasFocus?'observed':'requested'}">${esc(mode)}</span>
        <span class="app-package">${esc(a.package)}</span>
        <span class="app-meta">最終観測 ${esc(displayTime(a.last_seen))} · 表示 ${esc(a.foreground_count)}回 · 起動要求 ${esc(a.launch_request_count)}回</span>
      </button>`;
    }).join('')||'<div class="muted">'+(q?'一致するアプリはありません。':'監視開始後、アプリの起動・表示を待っています。')+'</div>';
    $('#observed-apps').querySelectorAll('[data-package]').forEach(b=>b.onclick=()=>{selectedApp=b.dataset.package;lastKey='';refreshApps();refreshEvents()});
  }catch(err){$('#observed-apps').textContent='アプリ一覧の取得に失敗しました: '+String(err)}
}
$('#app-all').onclick=()=>{selectedApp='';lastKey='';refreshApps();refreshEvents()};
$('#app-search').oninput=refreshApps;
$('#start').onclick=async()=>{await post('/api/start',{serial:$('#device').value});lastKey='';refreshDevices()};$('#stop').onclick=async()=>{await post('/api/stop');refreshDevices()};$('#clear').onclick=async()=>{await post('/api/clear');lastKey='';refreshEvents()};$('#set-target').onclick=async()=>{let r=await post('/api/target',{package:$('#target').value.trim()});if(!r.ok)alert(r.error||'設定できませんでした');else{lastKey='';refreshEvents()}};$('#severity').onchange=()=>{lastKey='';refreshEvents()};$('#launch').onclick=async()=>{$('#result').textContent='running...';let d=await post('/api/deeplink',{serial:$('#device').value,uri:$('#uri').value});$('#result').textContent=d.result;lastKey=''};
$("#search").oninput=()=>{lastKey='';refreshEvents()};refreshDevices();refreshEvents();refreshApps();focus();setInterval(refreshApps,2000);setInterval(refreshEvents,700);setInterval(focus,2500);setInterval(refreshDevices,5000);

async function refreshFlow(){
  try{
    let d=await api('/api/flow');let el=$('#flow');
    el.innerHTML=(d.flow||[]).map(e=>`<div class="flow-node ${e.verified?'verified':'request'}" data-event-id="${Number(e.id)||0}" tabindex="0"><small>${esc(e.ts)} · ${esc(e.kind)}</small><strong>${esc(e.headline)}</strong><span>${esc(e.detail)}</span></div>`).join('<div class="flow-arrow">→</div>')||'<span class="muted">画面切替・Activity起動要求などの重要イベントを待機中（一般のWebView内部ログは除外）</span>';
    el.querySelectorAll('[data-event-id]').forEach(node=>{
      const open=()=>{let ev=allEvents.find(e=>e.id===Number(node.dataset.eventId));if(ev)show(ev)};
      node.onclick=open;node.onkeydown=evt=>{if(evt.key==='Enter')open()};
    });
  }catch(err){$('#flow').textContent='フロー情報を取得できません: '+String(err)}
}
async function verifyVersion(){
  try{
    const info=await api('/api/version');
    if(info.version!=='1.2.7'){
      const warn=document.createElement('div');warn.className='version-warning';
      warn.textContent='画面とサーバーのバージョンが一致しません。起動中の旧ツールを終了してv1.2.7を起動してください。（サーバー: '+info.version+'）';
      document.body.prepend(warn);
    }
  }catch(err){console.warn('Server version not available',err)}
}
verifyVersion();
refreshFlow();setInterval(refreshFlow,2500);
