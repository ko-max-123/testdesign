let activeSession=null;
const WINDOW_CHANNEL='ali-panel-sync-v1';
let panelChannel=null;
try{if('BroadcastChannel' in window)panelChannel=new BroadcastChannel(WINDOW_CHANNEL)}catch(_){}
function sendCrossWindow(message){
  try{panelChannel?.postMessage(message)}catch(_){}
  try{if(message.type==='select-app')localStorage.setItem('ali-selected-app',JSON.stringify({package:message.package}))}
  catch(_){}
  try{if(message.type==='select-event')localStorage.setItem('ali-selected-event',JSON.stringify({id:message.id,session:message.session}))}
  catch(_){}
}
function receivedCrossWindow(message){
  if(!message)return;
  if(message.type==='select-event'&&Number.isInteger(Number(message.id))){
    if(message.session&&activeSession&&message.session!==activeSession)return;
    const event=allEvents.find(e=>e.id===Number(message.id));
    if(event&&selectedId!==event.id)show(event);
    return;
  }
  if(message.type!=='select-app'||typeof message.package!=='string')return;
  if(message.package.length>255)return;
  if(selectedApp===message.package)return;
  selectObservedApp(message.package,false);
}
if(panelChannel)panelChannel.onmessage=e=>receivedCrossWindow(e.data);
window.addEventListener('storage',e=>{if(e.key==='ali-selected-app'&&e.newValue){try{receivedCrossWindow({type:'select-app',package:JSON.parse(e.newValue).package})}catch(_){}}if(e.key==='ali-selected-event'&&e.newValue){try{receivedCrossWindow({type:'select-event',...JSON.parse(e.newValue)})}catch(_){}}});
const cats=['error','info','deeplink','activity','webview','browser','network','warning','system'];let enabled=new Set(cats),lastKey='',allEvents=[],selectedId=null,selectedApp='',observedApps=[];
const severityRank={debug:0,info:1,warning:2,error:3,critical:4};
const roleLabel={target:'対象アプリ',android:'Androidシステム',google:'Google関連',other:'その他のプロセス',unknown:'未特定'};
const logLevels={V:'VERBOSE',D:'DEBUG',I:'INFO',W:'WARNING',E:'ERROR',F:'FATAL',A:'ASSERT',S:'SILENT'};
const $=s=>document.querySelector(s);const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
$('#filters').innerHTML=cats.map(c=>`<label><input type="checkbox" data-cat="${c}" checked>${c.toUpperCase()}</label>`).join('');
document.querySelectorAll('[data-cat]').forEach(x=>x.onchange=()=>{x.checked?enabled.add(x.dataset.cat):enabled.delete(x.dataset.cat);lastKey=''});
async function api(url,opt){return (await fetch(url,opt)).json()}async function post(url,data={}){return api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)})}
async function refreshDevices(){let d=await api('/api/devices');let old=$('#device').value;$('#device').innerHTML=d.devices.map(x=>`<option value="${esc(x.serial)}">${esc(x.model)} · ${esc(x.serial)}</option>`).join('');if(old)$('#device').value=old;if(d.serial)$('#device').value=d.serial;if(document.activeElement!==$('#target'))$('#target').value=d.target_package||'';$('#status').textContent=d.running?'● MONITORING':'○ STOPPED';$('#status').className='pill '+(d.running?'ok':'')}
async function refreshEvents(){
  let d=await api('/api/events');allEvents=d.events;activeSession=d.session||null;
  let q=($('#search').value||'').toLowerCase(), minimum=$('#severity').value;
  let list=d.events.filter(e=>(!selectedApp || e.type==='MARKER' || (e.related_packages||[]).includes(selectedApp))&&enabled.has(e.category)&&
    (minimum==='all'||(severityRank[e.severity||'info']||0)>=severityRank[minimum])&&
    (!q||[e.summary,e.raw,e.process,e.tag,String(e.pid||'')].join(' ').toLowerCase().includes(q)));
  let key=[list.length,list[0]?.id,list.at(-1)?.id,q,minimum,selectedApp,[...enabled].sort().join(',')].join('|');
  if(key===lastKey)return;
  lastKey=key;
  let t=$('#timeline');
  t.innerHTML=list.map(e=>`<div class="event ${esc(e.category)} ${e.id===selectedId?'selected':''}" data-id="${e.id}"><span class="time">${esc(e.ts)}</span><span class="type"><span class="level level-${esc(e.severity||'info')}">${esc((e.severity||'info').toUpperCase())}</span> ${esc(e.type)}</span><span class="summary"><strong>${esc(e.process|| (e.pid?'PID '+e.pid+' · 未特定':'TOOL'))}</strong>${e.source_role==='target'?'<i class="target-flag">TARGET</i>':''}<small>${esc(e.tag||'')}</small> ${esc(e.summary)}</span></div>`).join('');
  t.querySelectorAll('.event').forEach(el=>el.onclick=()=>{let event=allEvents.find(e=>e.id===Number(el.dataset.id));if(event)show(event)});
  if($('#follow').checked)t.scrollTop=t.scrollHeight;
}
// Explanation cards: render only server-derived observations; never treat sequence as proof of success.
function show(e){
  selectedId=e.id;
  document.querySelectorAll('.event').forEach(el=>el.classList.toggle('selected',Number(el.dataset.id)===e.id));
  $('#detail').innerHTML=window.ALI_DETAIL.renderDetail(e);
  $('#detail-scroll').scrollTop=0;
  document.querySelectorAll('#detail .ctx').forEach(b=>b.onclick=()=>{let target=allEvents.find(x=>x.id===Number(b.dataset.id));if(target)show(target)});
  sendCrossWindow({type:'select-event',id:Number(e.id),session:activeSession});
}
async function focus(){try{let d=await api('/api/focus');$('#focus').textContent='Foreground: '+d.focus}catch{}}
function displayTime(iso){if(!iso)return '-';let d=new Date(iso);return Number.isNaN(d.getTime())?iso:d.toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit',second:'2-digit'});}
async function refreshApps(){
  try{
    const d=await api('/api/apps');observedApps=d.apps||[];
    const q=($('#app-search').value||'').trim().toLowerCase();
    const filtered=observedApps.filter(a=>[a.label,a.package].join(' ').toLowerCase().includes(q));
    $('#app-count').textContent=observedApps.length+'件';
    $('#app-all').classList.toggle('selected-app',!selectedApp);
    const chosen=observedApps.find(a=>a.package===selectedApp);
    $('#selected-app-hint').textContent='表示対象：'+(selectedApp ? (chosen?.label||selectedApp)+' ('+selectedApp+')' : '全アプリ');
    $('#observed-apps').innerHTML=filtered.map(a=>{
      const hasFocus=a.foreground_count>0, mode=hasFocus?'画面表示を確認':'起動要求のみ';
      return `<button class="app-entry ${selectedApp===a.package?'selected-app':''}" data-package="${esc(a.package)}" title="${esc(a.package)}">
        <span class="app-title">${esc(a.label)}</span><span class="app-mode ${hasFocus?'observed':'requested'}">${esc(mode)}</span>
        <span class="app-package">${esc(a.package)}</span>
        <span class="app-meta">最終観測 ${esc(displayTime(a.last_seen))} · 表示 ${esc(a.foreground_count)}回 · 起動要求 ${esc(a.launch_request_count)}回</span>
      </button>`;
    }).join('')||'<div class="muted">'+(q?'一致するアプリはありません。':'監視開始後、アプリの起動・表示を待っています。')+'</div>';
    $('#observed-apps').querySelectorAll('[data-package]').forEach(b=>b.onclick=()=>selectObservedApp(b.dataset.package));
    if($('#app-picker').open)renderAppPicker();
  }catch(err){$('#observed-apps').textContent='アプリ一覧の取得に失敗しました: '+String(err)}
}
function selectObservedApp(pkg,broadcast=true){selectedApp=pkg;lastKey='';$('#app-picker').close();if(broadcast)sendCrossWindow({type:'select-app',package:pkg});refreshApps();refreshEvents()}
$('#app-all').onclick=()=>selectObservedApp('');
$('#app-search').oninput=refreshApps;
$('#start').onclick=async()=>{await post('/api/start',{serial:$('#device').value});lastKey='';refreshDevices()};$('#stop').onclick=async()=>{await post('/api/stop');refreshDevices()};$('#clear').onclick=async()=>{await post('/api/clear');lastKey='';refreshEvents()};$('#set-target').onclick=async()=>{let r=await post('/api/target',{package:$('#target').value.trim()});if(!r.ok)alert(r.error||'設定できませんでした');else{lastKey='';refreshEvents()}};$('#severity').onchange=()=>{lastKey='';refreshEvents()};$('#launch').onclick=async()=>{$('#result').textContent='running...';let d=await post('/api/deeplink',{serial:$('#device').value,uri:$('#uri').value});$('#result').textContent=d.result;lastKey=''};
$("#search").oninput=()=>{lastKey='';refreshEvents()};refreshDevices();refreshEvents();refreshApps();focus();setInterval(refreshApps,2000);setInterval(refreshEvents,700);setInterval(focus,2500);setInterval(refreshDevices,5000);

async function refreshFlow(){
  try{
    let d=await api('/api/flow');let el=$('#flow');
    el.innerHTML=(d.flow||[]).map(e=>`<div class="flow-node ${e.verified?'verified':'request'}" data-event-id="${Number(e.id)||0}" tabindex="0"><small>${esc(e.ts)} · ${esc(e.kind)}</small><strong>${esc(e.headline)}</strong><span>${esc(e.detail)}</span></div>`).join('<div class="flow-arrow">→</div>')||'<span class="muted">画面切替・Activity起動要求などの重要イベントを待機中（一般のWebView内部ログは除外）</span>';
    el.querySelectorAll('[data-event-id]').forEach(node=>{
      const open=()=>{let ev=allEvents.find(e=>e.id===Number(node.dataset.eventId));if(ev)show(ev)};
      node.onclick=open;node.onkeydown=evt=>{if(evt.key==='Enter')open()};
    });
  }catch(err){$('#flow').textContent='フロー情報を取得できません: '+String(err)}
}
async function verifyVersion(){
  try{
    const info=await api('/api/version');
    if(info.version!=='1.3.3'){
      const warn=document.createElement('div');warn.className='version-warning';
      warn.textContent='画面とサーバーのバージョンが一致しません。起動中の旧ツールを終了してv1.3.3を起動してください。（サーバー: '+info.version+'）';
      document.body.prepend(warn);
    }
  }catch(err){console.warn('Server version not available',err)}
}
verifyVersion();
refreshFlow();setInterval(refreshFlow,2500);

// PC-only CDP capability panel. No browser JS injection and no response bodies.
async function refreshBrowserProbe(){
  try{
    const r=await api('/api/browser');const d=r.capability||{};
    const lines=[['Chrome',d.chrome],['WebView',d.webview],['監視中のページ',String(d.targets||0)+'件'],['レスポンス本文','取得OFF（固定）']];
    $('#probe-status').innerHTML=lines.map(([k,v])=>`<div class="probe-line"><span>${esc(k)}</span><strong>${esc(v||'未接続')}</strong></div>`).join('');
  }catch(e){$('#probe-status').textContent='CDP状態を取得できません';}
}
refreshBrowserProbe();setInterval(refreshBrowserProbe,4000);

$('#add-marker').onclick=async()=>{const r=await post('/api/mark',{label:$('#marker').value});if(!r.ok)alert(r.error||'マーカーを追加できませんでした');else{lastKey='';refreshEvents();refreshFlow()}};

// v1.3.1: sudden home-return investigation. Treat all unverified events as candidates.
let lastIncidentsKey='';
async function refreshIncidents(){
  try{
    const data=await api('/api/incidents');const incidents=data.incidents||[];
    const key=incidents.map(x=>[x.id,x.state,x.exit_reason,x.before_count,x.after_count].join(':')).join('|');
    if(key===lastIncidentsKey)return;
    lastIncidentsKey=key;
    $('#incident-list').innerHTML=incidents.map(x=>{
      const status=x.state==='collecting'?'収集中（終了後30秒まで）':x.state==='completed'?'保存完了':'一部保存';
      return `<article class="incident-item"><div class="incident-top"><strong>${esc(x.confidence)}</strong><small>${esc(x.detected_at)}</small></div>
        <div class="incident-summary">${esc(x.summary)}</div>
        <div class="incident-sub">${esc(status)} · 前 ${Number(x.before_count)||0}行 / 後 ${Number(x.after_count)||0}行</div>
        <div class="incident-sub">終了履歴：${esc(x.exit_reason||'原因未特定')}</div>
        <a target="_blank" rel="noopener" href="/api/incidents/report?id=${encodeURIComponent(x.id)}">調査レポートを開く ↗</a></article>`;
    }).join('')||'<div class="muted">まだ異常記録はありません。発生時は上のボタンを押してください。</div>';
  }catch(e){$('#incident-list').textContent='異常記録の取得に失敗しました: '+String(e)}
}
$('#incident-mark').onclick=async()=>{
  const btn=$('#incident-mark');btn.disabled=true;
  try{const r=await post('/api/incident/mark');
    if(!r.ok)alert(r.error||'証跡保存を開始できませんでした');
    else {await refreshIncidents();lastKey='';await refreshEvents()}
  }catch(e){alert('接続失敗: '+String(e))}
  finally{btn.disabled=false}
};
refreshIncidents();setInterval(refreshIncidents,2000);


// v1.3.3 compact-laptop app picker: search in a wide, scrollable dialog.
function renderAppPicker(){
  const q=($('#picker-search').value||'').trim().toLowerCase();
  const matches=observedApps.filter(a=>[a.package,a.label].join(' ').toLowerCase().includes(q));
  $('#picker-count').textContent=matches.length+'件 / '+observedApps.length+'件';
  $('#picker-apps').innerHTML=`<button type="button" class="picker-row ${!selectedApp?'selected-app':''}" data-pick=""><span class="picker-name">全アプリのログを表示</span><span class="picker-meta">絞り込み解除</span></button>`+
    matches.map(a=>`<button type="button" class="picker-row ${a.package===selectedApp?'selected-app':''}" data-pick="${esc(a.package)}">
      <span class="picker-name">${esc(a.label)}</span><span class="picker-package">${esc(a.package)}</span>
      <span class="picker-meta">${a.foreground_count>0?'前面表示を確認':'起動要求のみ'} · 最終観測 ${esc(displayTime(a.last_seen))}</span></button>`).join('');
  $('#picker-apps').querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>selectObservedApp(b.dataset.pick));
}
$('#expand-apps').onclick=()=>{$('#picker-search').value=$('#app-search').value||'';renderAppPicker();$('#app-picker').showModal();$('#picker-search').focus()};
$('#close-app-picker').onclick=()=>$('#app-picker').close();
$('#picker-search').oninput=renderAppPicker;
$('#app-picker').onclick=e=>{if(e.target===$('#app-picker'))$('#app-picker').close()};

// Passive ADB UI hierarchy sampler; cannot see app-internal functions or tap history.
let lastUiKey='';
async function refreshUiTrace(){
  try{
    const d=await api('/api/ui-trace');
    if(document.activeElement!==$('#ui-enabled'))$('#ui-enabled').checked=!!d.enabled;
    const status=d.status||{};
    $('#ui-status').textContent=({active:'監視中',waiting:'準備中',paused:'停止中',unavailable:'取得不可'}[status.state]||status.state||'不明')+'：'+(status.detail||'');
    const trace=d.trace||[];
    $('#ui-trace-count').textContent=trace.length+'件';
    const key=trace.map(t=>t.id).join(',');
    if(lastUiKey===key)return;
    lastUiKey=key;
    const visible=trace.slice(-16);
    $('#ui-trace').innerHTML=visible.map(t=>`<button class="screen-chip" data-ui-id="${Number(t.id)}" title="${esc(t.focus)}"><small>${esc(t.ts)} · UI構造変化</small><strong>${esc(t.package||'不明')}</strong><small>${esc(t.focus||'Activity不明')}</small><small>${Number(t.node_count)||0}要素 · ${esc(Object.keys(t.components||{}).join(', ')||'Native UI')}</small></button>`).join('')||'<span class="muted">変化はまだ観測されていません。ADB UI階層が取得できないアプリもあります。</span>';
    $('#ui-trace').querySelectorAll('[data-ui-id]').forEach(b=>b.onclick=()=>{
      const event=allEvents.find(e=>e.id===Number(b.dataset.uiId));
      if(event)show(event);
    });
  }catch(e){$('#ui-status').textContent='UI構造監視状態の取得失敗: '+String(e)}
}
$('#ui-enabled').onchange=async e=>{
  const d=await post('/api/ui-monitor',{enabled:e.target.checked});
  if(!d.ok)alert(d.error||'変更に失敗しました');
  refreshUiTrace();
};
refreshUiTrace();setInterval(refreshUiTrace,2300);

// v1.3.3 detachable panels. Separate windows use the same local-only HTTP server.
function openDetached(view){
  if(!['apps','detail','trace'].includes(view))return;
  const sizes={apps:[860,720],detail:[980,790],trace:[980,640]};
  const [w,h]=sizes[view];
  const win=window.open(`/detached.html?view=${view}`,'ali_detached_'+view,`width=${w},height=${h},resizable=yes,scrollbars=yes`);
  if(win)win.focus();
  else alert('別ウィンドウが開けません。ブラウザのポップアップ設定を確認してください。');
}
document.querySelectorAll('[data-window]').forEach(b=>b.onclick=()=>openDetached(b.dataset.window));
const leftToggle=$('#toggle-left'),rightToggle=$('#toggle-right');
function setCollapsed(side,collapsed){
  document.body.classList.toggle('collapse-'+side,collapsed);
  if(side==='left'){leftToggle.textContent=collapsed?'設定を表示':'設定を隠す';leftToggle.setAttribute('aria-expanded',String(!collapsed));}
  else {rightToggle.textContent=collapsed?'右側を表示':'右側を隠す';rightToggle.setAttribute('aria-expanded',String(!collapsed));}
  try{localStorage.setItem('ali-collapse-'+side,collapsed?'1':'0')}catch(_){}
}
for(const side of ['left','right']){
  let saved=false;try{saved=localStorage.getItem('ali-collapse-'+side)==='1'}catch(_){}
  setCollapsed(side,saved);
}
leftToggle.onclick=()=>setCollapsed('left',!document.body.classList.contains('collapse-left'));
rightToggle.onclick=()=>setCollapsed('right',!document.body.classList.contains('collapse-right'));
