// Independently refreshes apps, event detail or UI structure over the existing local API.
// Never accesses private app storage or adds anything to the Android device.
(function(){
'use strict';
const params=new URLSearchParams(window.location.search);
const view=['apps','detail','trace'].includes(params.get('view'))?params.get('view'):'apps';
const el=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtTime=iso=>{if(!iso)return '-';const d=new Date(iso);return Number.isNaN(d.valueOf())?iso:d.toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit',second:'2-digit'});};
const channelName='ali-panel-sync-v1';
let channel=null;
try{if('BroadcastChannel' in window)channel=new BroadcastChannel(channelName)}catch(_){}
function save(key,obj){try{localStorage.setItem(key,JSON.stringify(obj))}catch(_){}}
function load(key){try{return JSON.parse(localStorage.getItem(key)||'null')}catch(_){return null}}
function publish(msg){try{channel?.postMessage(msg)}catch(_){};if(msg.type==='select-app')save('ali-selected-app',{package:msg.package});if(msg.type==='select-event')save('ali-selected-event',{id:msg.id,session:msg.session});}
async function api(path){const response=await fetch(path,{cache:'no-store'});if(!response.ok)throw Error('HTTP '+response.status);return response.json();}
for(const kind of ['apps','detail','trace']){
  el(kind+'-view').hidden=kind!==view;
  document.querySelector(`[data-tab="${kind}"]`).classList.toggle('active',kind===view);
}
const titles={apps:'アプリ一覧',detail:'イベント詳細',trace:'画面構造履歴'};
document.title='Android Live Inspector - '+titles[view];
el('window-caption').textContent=titles[view]+'（別ウィンドウ）';

let selectedPackage=load('ali-selected-app')?.package||'', selection=load('ali-selected-event'), events=[], activeSession=null;
function receive(msg){
 if(!msg||typeof msg!=='object')return;
 if(msg.type==='select-app'&&typeof msg.package==='string'){
   selectedPackage=msg.package;save('ali-selected-app',{package:selectedPackage});if(view==='apps')refreshApps();
 }
 if(msg.type==='select-event'&&Number.isInteger(Number(msg.id))){
   selection={id:Number(msg.id),session:msg.session||null};save('ali-selected-event',selection);if(view==='detail')refreshDetail();
 }
}
if(channel)channel.onmessage=e=>receive(e.data);
window.addEventListener('storage',e=>{if(e.key==='ali-selected-app'&&e.newValue){const data=load('ali-selected-app');if(data)receive({type:'select-app',package:data.package});}if(e.key==='ali-selected-event'&&e.newValue){const data=load('ali-selected-event');if(data)receive({type:'select-event',id:data.id,session:data.session});}});
function reportError(id,err){el(id).textContent='データを取得できません。監視ツールが起動しているか確認してください。 '+String(err);el('detached-status').textContent='接続待ち';}

let lastAppsSignature='';
async function refreshApps(){
 try{
  const result=await api('/api/apps'),apps=result.apps||[],q=el('detached-app-search').value.trim().toLowerCase();
  const matching=apps.filter(a=>(String(a.label||'')+' '+String(a.package||'')).toLowerCase().includes(q));
  const signature=JSON.stringify(matching.map(a=>[a.package,a.label,a.last_seen,a.foreground_count,a.launch_request_count]))+q+'|'+selectedPackage;
  el('detached-app-count').textContent=matching.length+'件 / 全'+apps.length+'件';
  el('detached-status').textContent=result.running?'● 監視中':'○ 停止中';
  if(signature===lastAppsSignature)return;
  lastAppsSignature=signature;
  el('detached-apps').innerHTML=`<button class="detached-row ${!selectedPackage?'selected-app':''}" data-package=""><span class="title">全アプリのログを表示</span><span class="meta">絞り込みを解除</span></button>`+
    matching.map(a=>`<button class="detached-row ${selectedPackage===a.package?'selected-app':''}" data-package="${esc(a.package)}">
    <span class="title">${esc(a.label)}</span><span class="package">${esc(a.package)}</span>
    <span class="meta">${a.foreground_count>0?'画面表示を確認':'起動要求のみ'} · 最終観測 ${esc(fmtTime(a.last_seen))} · 画面表示 ${Number(a.foreground_count)||0}回 · 起動要求 ${Number(a.launch_request_count)||0}回</span></button>`).join('');
  el('detached-apps').querySelectorAll('[data-package]').forEach(b=>b.onclick=()=>{selectedPackage=b.dataset.package;publish({type:'select-app',package:selectedPackage});lastAppsSignature='';refreshApps();});
 }catch(err){reportError('detached-apps',err)}
}

let lastDetailKey='';
function displayDetail(id){
 const chosen=events.find(e=>Number(e.id)===Number(id));
 if(!chosen){el('detached-detail').textContent='対象イベントが現在の保持範囲にありません。メイン画面からイベントを選び直してください。';return;}
 selection={id:Number(chosen.id),session:activeSession};publish({type:'select-event',id:selection.id,session:activeSession});
 lastDetailKey=String(activeSession)+'|'+chosen.id;
 el('detached-detail-key').textContent='#'+chosen.id+' · '+(chosen.log_datetime||chosen.ts||'');
 el('detached-detail').innerHTML=window.ALI_DETAIL.renderDetail(chosen);
 el('detached-detail').scrollTop=0;
 el('detached-detail').querySelectorAll('.ctx').forEach(b=>b.onclick=()=>displayDetail(Number(b.dataset.id)));
}
async function refreshDetail(){
 try{
  const result=await api('/api/events');events=result.events||[];activeSession=result.session||null;
  el('detached-status').textContent=result.running?'● 監視中':'○ 停止中';
  if(!selection){el('detached-detail').textContent='メイン画面のLIVE TIMELINEでイベントを選択してください。';return;}
  if(selection.session && activeSession && selection.session!==activeSession){el('detached-detail').textContent='監視セッションが切り替わりました。新しいイベントを選択してください。';el('detached-detail-key').textContent='以前のセッション';return;}
  const key=String(activeSession)+'|'+selection.id;
  if(key!==lastDetailKey)displayDetail(selection.id);
 }catch(err){reportError('detached-detail',err)}
}

let lastTraceSignature='';
async function refreshTrace(){
 try{
  const result=await api('/api/ui-trace'),trace=result.trace||[];
  const signature=trace.map(t=>t.id).join(',');
  el('detached-status').textContent=result.enabled?'● UI監視ON':'○ UI監視OFF';
  el('detached-trace-count').textContent=trace.length+'件 · '+(result.status?.state||'不明');
  if(signature===lastTraceSignature)return;
  lastTraceSignature=signature;
  el('detached-trace').innerHTML=trace.slice().reverse().map(t=>`<button class="detached-row" data-event-id="${Number(t.id)}">
  <span class="title">${esc(t.package||'不明なアプリ')}</span><span class="package">${esc(t.focus||'Activity不明')}</span>
  <span class="meta">${esc(t.ts)} · UI構造の変化 · ${Number(t.node_count)||0}要素 · ${esc(Object.keys(t.components||{}).join(', ')||'Native UI')}</span></button>`).join('')||'<span class="muted">まだ変化は観測されていません。WebView内部や短時間の表示は検出できない場合があります。</span>';
  el('detached-trace').querySelectorAll('[data-event-id]').forEach(b=>b.onclick=async()=>{
    const id=Number(b.dataset.eventId);
    let session=null;try{const result=await api('/api/events');session=result.session||null}catch(_){}
    publish({type:'select-event',id,session});
    window.location.assign('detached.html?view=detail');
  });
 }catch(err){reportError('detached-trace',err)}
}

if(view==='apps'){
 el('detached-app-search').oninput=()=>{lastAppsSignature='';refreshApps()};
 refreshApps();setInterval(refreshApps,2000);
}else if(view==='detail'){
 refreshDetail();setInterval(refreshDetail,800);
}else{
 refreshTrace();setInterval(refreshTrace,2400);
}
})();
