Android Live Inspector - ADB executable folder

This folder is deliberately included in the ZIP.
ADB binaries are NOT bundled.

Use one of the following:
1. If `adb` is on your Windows PATH, nothing needs to be copied here.
2. Otherwise, copy these files from Android SDK platform-tools:
   adb.exe
   AdbWinApi.dll
   AdbWinUsbApi.dll
3. Run environment_check.bat to verify ADB and device.

Official platform-tools download:
https://developer.android.com/tools/releases/platform-tools

Do not place any Android application credentials or secret files here.
