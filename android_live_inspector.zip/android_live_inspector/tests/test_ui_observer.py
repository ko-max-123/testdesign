import unittest
from ui_observer import parse_ui_dump, structural_event
from event_explainer import explain


def dump(button='home', password='SECRET-DO-NOT-STORE', text='BANK-ACCOUNT-123'):
    return f'''UI hierchary dumped to: /dev/tty\n<?xml version="1.0" encoding="UTF-8"?>
<hierarchy rotation="0"><node index="0" text="{text}" class="android.widget.FrameLayout" package="jp.co.family.familymart_app" content-desc="SECRET-A11Y" resource-id="" clickable="false"><node index="1" class="android.widget.Button" resource-id="jp.co.family.familymart_app:id/{button}" text="{password}" password="true" package="jp.co.family.familymart_app" clickable="true" bounds="[0,0][300,100]"/></node></hierarchy>''' 

class UiObserverTests(unittest.TestCase):
    def test_sensitive_ui_information_not_persisted(self):
        result=parse_ui_dump(dump())
        event=structural_event(None,result,'jp.co.family.familymart_app/.MainActivity')
        output=str(result)+str(event)+str(explain(event))
        for forbidden in ('BANK-ACCOUNT-123','SECRET-DO-NOT-STORE','SECRET-A11Y','[0,0][300,100]'):
            self.assertNotIn(forbidden,output)
        self.assertEqual(result['package'],'jp.co.family.familymart_app')
        self.assertIn('jp.co.family.familymart_app:id/home',result['clickable_ids'])
        self.assertEqual(event['type'],'UI_CHANGE')
        self.assertEqual(explain(event)['classification'],'ui_structure')

    def test_ui_text_only_changes_do_not_create_events(self):
        a=parse_ui_dump(dump(text='PHONE-111',password='1234'))
        b=parse_ui_dump(dump(text='PHONE-222',password='9999'))
        self.assertIsNone(structural_event(a,b,'com.example/.Main'))

    def test_structure_difference_detected(self):
        a=parse_ui_dump(dump(button='home'))
        b=parse_ui_dump(dump(button='account'))
        self.assertIsNotNone(structural_event(a,b,'com.example/.Main'))

    def test_invalid_no_xml(self):
        with self.assertRaises(ValueError): parse_ui_dump('ERROR dump failed')

    def test_unusual_id_removed(self):
        result=parse_ui_dump(dump(button='home').replace('id/home','id/SECRET?password=1'))
        self.assertEqual(result['clickable_ids'],[])

    def test_junk_oversize_rejected(self):
        with self.assertRaises(ValueError): parse_ui_dump('Z'*3_000_001)

if __name__=='__main__': unittest.main()
