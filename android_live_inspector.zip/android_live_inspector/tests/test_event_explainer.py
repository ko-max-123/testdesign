import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from log_analysis import classify
from event_explainer import explain
from app import State


DYNAMIC = ('10-08 21:39:23.077  1741  2979 I ActivityTaskManager: START u0 '
           '{act=com.google.firebase.dynamiclinks.VIEW_DYNAMIC_LINK '
           'cat=[android.intent.category.BROWSABLE] dat=https://famima.page.link/test '
           'flg=0x14000000 pkg=com.google.android.gms '
           'cmp=com.google.android.gms/.dynamiclinks.appinvite.AppInviteAcceptInvitationActivity '
           '(has extras)} with LAUNCH_MULTIPLE from uid 10165 (com.android.chrome) '
           '(BAL_ALLOW_VISIBLE_WINDOW) result code=0')

class ExplainTests(unittest.TestCase):
    def test_dynamic_link_flow_and_unverified_success(self):
        e=classify(DYNAMIC,{1741:'system_server'})
        self.assertEqual(e['type'],'DEEPLINK')
        a=explain(e)
        self.assertEqual(a['title'],'Firebase Dynamic Link')
        self.assertEqual([x['label'] for x in a['steps']],['呼び出し元','リンクURI','起動要求先'])
        self.assertEqual(a['steps'][0]['detail'],'com.android.chrome')
        self.assertEqual(a['steps'][1]['detail'],'https://famima.page.link/test')
        self.assertIn('com.google.android.gms/',a['steps'][2]['detail'])
        self.assertIn('最終的なアプリ起動',a['unknowns'][0])
        self.assertNotIn('FamiPayアプリ起動成功',str(a))

    def test_unknown_origin_does_not_invent_chrome(self):
        e=classify('10-08 21:39:23.077  1741  2979 I ActivityTaskManager: START u0 {act=android.intent.action.VIEW dat=demo://open cmp=jp.example/.Activity}',{1741:'system_server'})
        a=explain(e)
        self.assertFalse(any('Chrome' in s['detail'] for s in a['steps']))
        self.assertEqual(a['classification'],'deeplink')

    def test_focus_steps(self):
        a=explain({'type':'FOCUS_CHANGE','from':'com.android.chrome/.Main','to':'jp.app/.Main'})
        self.assertEqual([s['label'] for s in a['steps']],['変更前','変更後'])
        self.assertTrue(a['unknowns'])

    def test_webview_limits(self):
        a=explain({'type':'WEBVIEW','tag':'chromium','process':'jp.app','log_level':'I'})
        self.assertEqual(a['classification'],'webview')
        self.assertIn('特定できません',a['unknowns'][0])

    def test_error_source(self):
        e=classify('10-08 21:37:05.339  1741  2979 E BatteryStatsService: Invalid uid for waking network packet: -1',{1741:'system_server'})
        a=explain(e)
        self.assertEqual(a['classification'],'error')
        self.assertIn('対象アプリの通信障害',a['unknowns'][0])

    def test_saved_event_includes_analysis(self):
        state=State()
        state.emit({'type':'FOCUS_CHANGE','category':'activity','from':'A','to':'B','summary':'A to B'})
        self.assertEqual(state.events[0]['analysis']['classification'],'activity')
        self.assertEqual(len(state.events[0]['analysis']['steps']),2)

if __name__=='__main__': unittest.main()
