"""Static contract for popout windows (no device or external browser needed)."""
from pathlib import Path
import unittest
import app

UI=Path(app.ROOT)/'ui'

class DetachedWindowTests(unittest.TestCase):
    def test_version_and_script_dependencies(self):
        self.assertEqual(app.VERSION,'1.3.3')
        html=(UI/'index.html').read_text(encoding='utf-8')
        self.assertIn('detail_renderer.js?v=1.3.3',html)
        self.assertIn('app.js?v=1.3.3',html)
        self.assertIn('style.css?v=1.3.3',html)
        self.assertLess(html.index('detail_renderer.js'),html.index('app.js'))

    def test_popout_buttons_and_collapsible_panels(self):
        html=(UI/'index.html').read_text(encoding='utf-8')
        script=(UI/'app.js').read_text(encoding='utf-8')
        css=(UI/'style.css').read_text(encoding='utf-8')
        for view in ('apps','detail','trace'):
            self.assertIn('data-window="'+view+'"',html)
            self.assertIn("['apps','detail','trace']",script)
        self.assertIn('id="toggle-left"',html)
        self.assertIn('id="toggle-right"',html)
        self.assertIn('body.collapse-left.collapse-right main',css)
        self.assertIn('window.open(',script)
        self.assertIn('selectObservedApp(message.package,false)',script)
        self.assertIn("sendCrossWindow({type:'select-event'",script)

    def test_detached_views_access_same_local_apis(self):
        html=(UI/'detached.html').read_text(encoding='utf-8')
        js=(UI/'detached.js').read_text(encoding='utf-8')
        self.assertLess(html.index('detail_renderer.js'),html.index('detached.js'))
        for view in ('apps','detail','trace'):
            self.assertIn('id="'+view+'-view"',html)
        for endpoint in ('/api/apps','/api/events','/api/ui-trace'):
            self.assertIn(endpoint,js)
        self.assertIn('BroadcastChannel',js)
        self.assertIn('localStorage',js)
        self.assertIn('ALI_DETAIL.renderDetail',js)
        self.assertIn('const result=await api',js)

    def test_renderer_is_shared_and_escapes_untrusted_logs(self):
        main=(UI/'app.js').read_text(encoding='utf-8')
        common=(UI/'detail_renderer.js').read_text(encoding='utf-8')
        self.assertIn('ALI_DETAIL.renderDetail',main)
        self.assertIn("'&lt;'",common)
        self.assertIn('function renderDetail(e)',common)

if __name__=='__main__':
    unittest.main()
