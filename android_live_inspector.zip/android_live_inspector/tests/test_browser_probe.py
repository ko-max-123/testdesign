import base64
import hashlib
import json
import socket
import struct
import threading
import unittest
from browser_probe import WebSocketReader,cdp_event,discover_sockets,safe_url,safe_message
from event_explainer import explain
from flow_analysis import flow_item

class CDPTests(unittest.TestCase):
    def test_safe_url_no_secrets(self):
        input_url='https://alice:secret@example.com/customer/12345/profile?access_token=abc#cookie'
        result=safe_url(input_url)
        self.assertEqual(result,'https://example.com/customer/{id}/profile')
        for secret in ('alice','secret','12345','access_token','abc','cookie'):
            self.assertNotIn(secret,result)
    def test_safe_url_unavailable(self):
        self.assertTrue(safe_url('file:///data/private').startswith('('))
        self.assertTrue(safe_url('intent://x').startswith('('))
    def test_socket_discovery(self):
        data='@webview_devtools_remote_11660\n@chrome_devtools_remote\n@webview_devtools_remote_123\n@fake_devtools_remote_222'
        self.assertEqual(discover_sockets(data),['chrome_devtools_remote','webview_devtools_remote_11660','webview_devtools_remote_123'])
    def test_network_request_response_and_body_not_saved(self):
        r={}
        req=cdp_event('Network.requestWillBeSent',{'requestId':'3','type':'Fetch',
            'request':{'method':'POST','url':'https://example.com/api/user/12345?token=secret',
                       'postData':'PRIVATE BODY','headers':{'Authorization':'Bearer secret'}}},'chrome','com.android.chrome',r)
        self.assertEqual(req['category'],'network')
        self.assertEqual(req['type'],'HTTP_REQUEST')
        self.assertNotIn('secret',str(req));self.assertNotIn('PRIVATE',str(req))
        resp=cdp_event('Network.responseReceived',{'requestId':'3','type':'Fetch',
            'response':{'status':403,'url':'https://example.com/api/user/12345?token=secret',
            'headers':{'Set-Cookie':'private'}}},'chrome','com.android.chrome',r)
        self.assertEqual(resp['http_status'],403)
        self.assertEqual(resp['severity'],'warning')
        self.assertNotIn('secret',str(resp));self.assertNotIn('private',str(resp))
        detail=explain(resp)
        self.assertEqual(detail['classification'],'browser')
        self.assertIn('HTTP',detail['title'])
    def test_navigation_flow(self):
        ev=cdp_event('Page.frameNavigated',{'frame':{'url':'https://example.com/login?auth=TOKEN'}},'webview','jp.co.family.familymart_app',{})
        self.assertEqual(ev['type'],'WEBVIEW_NAV')
        self.assertNotIn('TOKEN',str(ev))
        item=flow_item(ev)
        self.assertEqual(item['kind'],'WebViewページ遷移')
        self.assertTrue(item['verified'])
    def test_subframe_excluded(self):
        self.assertIsNone(cdp_event('Page.frameNavigated',{'frame':{'parentId':'2','url':'https://x.y/'}},'chrome','com.android.chrome',{}))
    def test_js_error_sanitized(self):
        ev=cdp_event('Runtime.exceptionThrown',{'exceptionDetails':{'text':'Bad request https://example.com/pay?password=bad'}},'chrome','com.android.chrome',{})
        self.assertNotIn('password=bad',ev['summary'].lower())
        self.assertEqual(ev['severity'],'error')
    def test_websocket_read(self):
        server=socket.socket();server.bind(('127.0.0.1',0));server.listen(1)
        port=server.getsockname()[1];errors=[]
        def fake_server():
            try:
                conn,_=server.accept();conn.settimeout(3)
                req=b''
                while b'\r\n\r\n' not in req:req+=conn.recv(2048)
                key=[x.split(':',1)[1].strip() for x in req.decode().split('\r\n') if x.lower().startswith('sec-websocket-key:')][0]
                accept=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode()
                conn.sendall(('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n').encode())
                head=conn.recv(2)
                self.assertEqual(head[0]&0x0f,1)
                self.assertTrue(head[1]&0x80)
                length=head[1]&127
                mask=conn.recv(4)
                payload=b''
                while len(payload)<length:payload+=conn.recv(length-len(payload))
                decoded=bytes(v^mask[i%4] for i,v in enumerate(payload))
                self.assertEqual(json.loads(decoded)['method'],'Network.enable')
                frame=json.dumps({'method':'Page.navigatedWithinDocument','params':{'url':'https://example.com'}}).encode()
                conn.sendall(bytes([0x81, len(frame)])+frame)
                conn.close()
            except Exception as e:errors.append(str(e))
            finally:server.close()
        t=threading.Thread(target=fake_server);t.start()
        ws=WebSocketReader(f'ws://127.0.0.1:{port}/devtools/page/x')
        ws.send({'id':1,'method':'Network.enable'})
        got=ws.recv()
        self.assertEqual(got['method'],'Page.navigatedWithinDocument')
        ws.close();t.join(4)
        self.assertFalse(errors, errors)

if __name__=='__main__':unittest.main()
