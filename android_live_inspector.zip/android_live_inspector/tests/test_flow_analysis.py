import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from flow_analysis import build_flow, flow_item
from app import parse_focus_output

class FlowTests(unittest.TestCase):
    def test_webview_internal_storage_excluded(self):
        e={'id':1,'type':'WEBVIEW','raw':'FullBackup_native: /data/data/jp.example/app_webview/Default/Local Storage','ts':'22:18:11'}
        self.assertIsNone(flow_item(e))
    def test_general_error_excluded(self):
        self.assertIsNone(flow_item({'type':'ERROR','summary':'BatteryStatsService Invalid uid'}))
    def test_focus_change_compact(self):
        flow=flow_item({'id':7,'type':'FOCUS_CHANGE','from':'com.android.chrome/.Main','to':'jp.co.example/.Home','ts':'22:19:00'})
        self.assertTrue(flow['verified']);self.assertEqual(flow['kind'],'画面切替')
    def test_start_is_unverified(self):
        event={'type':'DEEPLINK','tag':'ActivityTaskManager','raw':'ActivityTaskManager: START u0 {act=android.intent.action.VIEW cmp=com.google.android.gms/.Example} from uid 10 (com.android.chrome)', 'id':2}
        self.assertFalse(flow_item(event)['verified'])
    def test_deduplicate(self):
        e={'type':'FOCUS_CHANGE','from':'com.android.chrome/.Main','to':'jp.example/.Home'}
        self.assertEqual(len(build_flow([dict(e,id=1),dict(e,id=2)])),1)
    def test_window_component(self):
        self.assertEqual(parse_focus_output('mCurrentFocus=Window{ab12 u0 jp.co.family.familymart/.MainActivity}'),'jp.co.family.familymart/.MainActivity')
    def test_resumed_fallback(self):
        self.assertEqual(parse_focus_output('topResumedActivity=ActivityRecord{ab u0 jp.co.family.familymart/.Home t33}'),'jp.co.family.familymart/.Home')
    def test_focus_with_pkg_only(self):
        self.assertEqual(parse_focus_output('mCurrentFocus=Window{ab12 u0 com.android.chrome}'),'com.android.chrome')

if __name__=='__main__': unittest.main()
