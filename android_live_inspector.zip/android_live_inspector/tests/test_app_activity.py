import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app_activity import package_from_focus, activity_observation, related_packages
from log_analysis import classify

class AppActivityTests(unittest.TestCase):
    def test_focus_component(self):
        self.assertEqual(package_from_focus('com.android.chrome/com.google.android.apps.chrome.Main'),'com.android.chrome')
        self.assertIsNone(package_from_focus('unknown'))

    def test_firebase_launch_tracks_target_and_chrome(self):
        raw=('10-08 21:39:23.077 1741 2979 I ActivityTaskManager: START u0 '
             '{act=com.google.firebase.dynamiclinks.VIEW_DYNAMIC_LINK cat=[android.intent.category.BROWSABLE] '
             'dat=https://famima.page.link/... pkg=com.google.android.gms '
             'cmp=com.google.android.gms/.dynamiclinks.appinvite.AppInviteAcceptInvitationActivity} '
             'with LAUNCH_MULTIPLE from uid 10165 (com.android.chrome) result code=0')
        e=classify(raw,{1741:'system_server'})
        observation=activity_observation(e)
        self.assertEqual(observation['destination'],'com.google.android.gms')
        self.assertEqual(observation['source'],'com.android.chrome')
        self.assertEqual(related_packages(e),['com.android.chrome','com.google.android.gms'])

    def test_system_server_error_unattributed(self):
        raw='10-08 21:37:05.339 1741 2979 E BatteryStatsService: Invalid uid for waking network packet: -1'
        e=classify(raw,{1741:'system_server'})
        self.assertEqual(related_packages(e),[])

    def test_process_and_focus_related(self):
        e={'process':'jp.famipay.app:remote','to':'jp.famipay.app/.MainActivity','type':'FOCUS_CHANGE'}
        self.assertEqual(related_packages(e),['jp.famipay.app'])

    def test_generic_activity_tag_without_start_not_counted(self):
        e={'tag':'ActivityTaskManager','raw':'ActivityTaskManager: Displayed com.android.chrome/.Main'}
        self.assertIsNone(activity_observation(e))

if __name__=='__main__': unittest.main()
