import sys
import unittest
import json
import threading
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app

class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), app.Handler)
        cls.base = f'http://127.0.0.1:{cls.server.server_address[1]}'
        cls.worker = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.worker.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_configure_target_and_relabel_existing_events(self):
        with app.STATE.lock:
            app.STATE.events.clear()
            app.STATE.next_id = 0
            app.STATE.target_package = ''
        app.STATE.emit({'type':'INFO','category':'info','summary':'test','process':'jp.sample.app:service','source_role':'other'})
        payload=json.dumps({'package':'jp.sample.app'}).encode()
        req=urllib.request.Request(self.base+'/api/target',data=payload,headers={'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(req,timeout=3) as resp:
            self.assertTrue(json.load(resp)['ok'])
        with urllib.request.urlopen(self.base+'/api/events',timeout=3) as resp:
            ev=json.load(resp)['events']
        self.assertEqual(ev[-1]['source_role'],'target')
        self.assertEqual(ev[-1]['severity'],'info')
        self.assertTrue(ev[-1]['timestamp_source']=='host')

    def test_observed_app_api_and_system_error_not_associated(self):
        with app.STATE.lock:
            app.STATE.apps.clear()
            app.STATE.note_app_locked('com.android.chrome','foreground', '2026-10-08T21:39:00','Chrome/Main')
        with urllib.request.urlopen(self.base+'/api/apps',timeout=3) as resp:
            result=json.load(resp)
        self.assertEqual(result['apps'][0]['package'],'com.android.chrome')
        self.assertEqual(result['apps'][0]['foreground_count'],1)

    def test_static_ui_response(self):
        with urllib.request.urlopen(self.base+'/',timeout=3) as resp:
            html=resp.read().decode('utf-8')
        self.assertIn('TARGET APP',html)
        self.assertIn('IMPORTANCE',html)
        self.assertIn('OBSERVED APPS',html)

if __name__=='__main__': unittest.main()
