"""HTTP API coverage for Incident Watch, without device hardware."""
import json
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
from http.server import ThreadingHTTPServer
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
from incident_diagnostics import IncidentRecorder

class IncidentApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        cls.base=f'http://127.0.0.1:{cls.server.server_port}'
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close()
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.original=(app.STATE.incident,app.STATE.running,app.STATE.target_package)
        app.STATE.incident=IncidentRecorder(Path(self.temp.name),'jp.co.family.familymart_app',
               lambda *a,**k:'ERROR: unsupported',lambda s:s,lambda e:None,lambda:[])
        app.STATE.running=True
        app.STATE.target_package='jp.co.family.familymart_app'
    def tearDown(self):
        app.STATE.incident.close()
        app.STATE.incident,app.STATE.running,app.STATE.target_package=self.original
        self.temp.cleanup()
    def _post(self,path,payload=None):
        req=urllib.request.Request(self.base+path,data=json.dumps(payload or {}).encode(),
                     headers={'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(req,timeout=3) as f: return json.load(f)
    def test_manual_record_and_safe_report(self):
        r=self._post('/api/incident/mark')
        self.assertTrue(r['ok'])
        with urllib.request.urlopen(self.base+'/api/incidents',timeout=3) as f:
            incidents=json.load(f)['incidents']
        self.assertEqual(incidents[0]['id'],r['id'])
        with urllib.request.urlopen(self.base+'/api/incidents/report?id='+r['id'],timeout=3) as f:
            html=f.read().decode('utf-8')
            self.assertIn('異常調査レポート',html)
            self.assertIn('default-src',f.headers['Content-Security-Policy'])
    def test_report_path_traversal_rejected(self):
        try:
            urllib.request.urlopen(self.base+'/api/incidents/report?id=../../secret',timeout=3)
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code,400)
        else: self.fail('should reject invalid id')
    def test_manual_button_requires_monitoring_and_target(self):
        app.STATE.running=False
        with self.assertRaises(urllib.error.HTTPError) as c:
            self._post('/api/incident/mark')
        self.assertEqual(c.exception.code,409)
        app.STATE.running=True
        app.STATE.incident.set_target('')
        with self.assertRaises(urllib.error.HTTPError) as c:
            self._post('/api/incident/mark')
        self.assertEqual(c.exception.code,400)
    def test_ui_contains_incident_watch(self):
        with urllib.request.urlopen(self.base+'/',timeout=3) as f: content=f.read().decode()
        self.assertIn('INCIDENT WATCH',content)
        self.assertIn('incident-mark',content)
        self.assertIn('v1.3.1',content)

if __name__=='__main__': unittest.main()
