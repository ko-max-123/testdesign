import unittest
from pathlib import Path
from unittest.mock import patch
import app

class UiIntegrationTests(unittest.TestCase):
    def test_version_and_page_components(self):
        html=(Path(app.ROOT)/'ui/index.html').read_text(encoding='utf-8')
        script=(Path(app.ROOT)/'ui/app.js').read_text(encoding='utf-8')
        self.assertEqual(app.VERSION, '1.3.3')
        for element in ('id="expand-apps"','id="app-picker"','id="picker-search"','id="ui-trace"','id="ui-enabled"'):
            self.assertIn(element,html)
        for endpoint in ('/api/ui-trace','/api/ui-monitor'):
            self.assertIn(endpoint,script)
        self.assertIn('showModal()',script)
        self.assertIn('word-break:break-all',(Path(app.ROOT)/'ui/style.css').read_text(encoding='utf-8'))

    def test_famipay_friendly_name(self):
        from app_activity import new_app_record
        rec=new_app_record('jp.co.family.familymart_app')
        self.assertIn('ファミペイ',rec['label'])

    def test_capture_uses_device_shell_and_no_files(self):
        sample='<hierarchy><node class="android.widget.Button" resource-id="com.test:id/main" package="com.test" text="secret" clickable="true" /></hierarchy>'
        with patch('app.subprocess.run') as run:
            run.return_value.stdout=sample
            meta=app.capture_ui_structure('deviceX')
            args=run.call_args.args[0]
            self.assertEqual(args[1:5],['-s','deviceX','shell','uiautomator'])
            self.assertEqual(args[-1],'/dev/tty')
            self.assertNotIn('secret',str(meta))

if __name__=='__main__': unittest.main()
