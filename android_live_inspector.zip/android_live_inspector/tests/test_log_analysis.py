import sys
import unittest
from datetime import datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from log_analysis import classify, parse_ps, parse_threadtime, source_role

class LogAnalysisTests(unittest.TestCase):
    def setUp(self):
        self.clock=datetime(2026,10,8,21,26,20)

    def test_network_scheduler_info_not_error(self):
        raw='10-08 21:26:19.866 17784 13371 I NetworkScheduler: (REDACTED) Error inserting %s'
        e=classify(raw,{17784:'com.google.android.gms'},captured=self.clock)
        self.assertEqual((e['type'],e['category'],e['log_level'],e['severity']),('INFO','info','I','info'))
        self.assertEqual(e['ts'],'21:26:19.866')
        self.assertEqual(e['log_datetime'],'2026-10-08T21:26:19.866')
        self.assertEqual((e['pid'],e['tid'],e['tag'],e['process'],e['source_role']), (17784,13371,'NetworkScheduler','com.google.android.gms','google'))
        self.assertEqual(e['captured_at'],'2026-10-08T21:26:20.000')

    def test_other_levels_for_same_phrase(self):
        for level,sev,typ in [('W','warning','WARNING'),('E','error','ERROR'),('D','debug','DEBUG')]:
            with self.subTest(level=level):
                e=classify(f'10-08 21:26:19.866 17784 13371 {level} NetworkScheduler: Error inserting %s',captured=self.clock)
                self.assertEqual((e['severity'],e['type']),(sev,typ))

    def test_crash_and_anr_promotion_without_losing_raw_level(self):
        crash=classify('10-08 21:26:19.866 777 777 E AndroidRuntime: FATAL EXCEPTION: main',captured=self.clock)
        self.assertEqual((crash['type'],crash['severity'],crash['log_level']),('CRASH','critical','E'))
        anr=classify('10-08 21:26:19.866 777 777 I ActivityManager: ANR in com.example.app',captured=self.clock)
        self.assertEqual((anr['type'],anr['severity'],anr['log_level']),('ANR','critical','I'))

    def test_activity_deeplink_process_target(self):
        line='10-08 21:26:19.866 1020 1020 I ActivityTaskManager: START u0 {act=android.intent.action.VIEW dat=https://example.com/p}'
        e=classify(line,{1020:'com.android.systemui'},'com.example.app',captured=self.clock)
        self.assertEqual(e['type'],'DEEPLINK')
        self.assertEqual(e['source_role'],'android')
        self.assertEqual(source_role('com.example.app:remote','com.example.app'),'target')
        self.assertEqual(source_role(None,'com.example.app'),'unknown')

    def test_parse_ps_modern_and_legacy(self):
        modern='PID NAME\n17784 com.google.android.gms\n13371 com.example.app:remote\n'
        legacy='USER PID PPID VSZ RSS WCHAN ADDR S NAME\nu0_a1 17784 1 2 3 0 0 S com.google.android.gms\n'
        self.assertEqual(parse_ps(modern),{17784:'com.google.android.gms',13371:'com.example.app:remote'})
        self.assertEqual(parse_ps(legacy),{17784:'com.google.android.gms'})

    def test_ignore_nonmatching_and_headings(self):
        self.assertIsNone(classify('--------- beginning of main',captured=self.clock))
        self.assertIsNone(classify('10-08 21:26:19.866 17784 13371 I OtherTag: Everything is fine',captured=self.clock))
        self.assertIsNone(parse_threadtime('bad input'))

    def test_unknown_process_stays_unknown(self):
        e=classify('10-08 21:26:19.866 17784 13371 I NetworkScheduler: Error inserting %s',captured=self.clock)
        self.assertIsNone(e['process'])
        self.assertEqual(e['source_role'],'unknown')

if __name__=='__main__': unittest.main()
