"""Compact, evidence-bound events for the top transition strip.
Do NOT make chronological adjacency look like a proven causal sequence.
"""
import re
from urllib.parse import urlsplit
from app_activity import activity_observation, package_from_focus

WEB_NAV = re.compile(r'\b(?:onPageStarted|onPageFinished|shouldOverrideUrlLoading|WebViewClient.*loadUrl|Loading URL)\b', re.I)
URL = re.compile(r'\bhttps?://[^\s}\]"\']+', re.I)

def brief_component(value):
    text = (value or '').strip()
    if '/' in text:
        pkg, activity = text.split('/', 1)
        return pkg + '/' + activity.rsplit('.', 1)[-1]
    return text[:90]

def flow_item(ev):
    typ = ev.get('type')
    raw = ev.get('raw') or ev.get('summary') or ''
    if typ == 'FOCUS_CHANGE':
        origin, dest = ev.get('from', ''), ev.get('to', '')
        if not dest or origin == dest:
            return None
        return {'id':ev.get('id'), 'ts':ev.get('ts'), 'kind':'画面切替',
                'headline':brief_component(dest), 'detail':'表示: '+brief_component(origin)+' → '+brief_component(dest),
                'verified':True}
    if typ == 'DEEPLINK_TEST':
        return {'id':ev.get('id'), 'ts':ev.get('ts'), 'kind':'リンク試験',
                'headline':'ACTION_VIEW を送信', 'detail':'アプリでの表示成功は未確認', 'verified':False}
    obs = activity_observation(ev)
    if obs:
        source = obs.get('source')
        dest = obs['destination']
        kind = 'リンク起動要求' if typ == 'DEEPLINK' else 'Activity起動要求'
        return {'id':ev.get('id'), 'ts':ev.get('ts'), 'kind':kind,
                'headline':(source+' → ' if source else '')+dest,
                'detail':'起動要求（画面表示は未確認）', 'verified':False}
    if typ in ('CRASH','ANR'):
        return {'id':ev.get('id'), 'ts':ev.get('ts'), 'kind':typ,
                'headline':ev.get('process') or ev.get('tag') or '発生元不明',
                'detail':'重大イベント。詳細ログを確認', 'verified':True}
    if typ == 'WEBVIEW' and WEB_NAV.search(raw):
        match = URL.search(raw)
        if not match:
            return None
        try:
            parsed = urlsplit(match.group(0))
            destination = parsed.netloc or 'URL'
        except ValueError:
            destination = 'URL'
        return {'id':ev.get('id'), 'ts':ev.get('ts'), 'kind':'WebView URLログ',
                'headline':destination, 'detail':'URLはログ内で観測。表示成功は未確認', 'verified':False}
    return None

def build_flow(events, limit=30):
    items = []
    for ev in events:
        item = flow_item(ev)
        if item is None:
            continue
        # Repeated noisy startup messages should not flood the flow.
        if items and (item['kind'], item['headline']) == (items[-1]['kind'], items[-1]['headline']):
            items[-1] = item
        else:
            items.append(item)
    return items[-limit:]
