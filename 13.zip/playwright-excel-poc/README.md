# Playwright Excel PoC 基本実装

Excel/CAT由来のテストケースをPlaywrightのE2Eテストに変換し、検証環境で補助的に実行するための最小構成です。

## 目的

- ExcelテストケースをPlaywrightの雛形に変換する
- 環境情報を外部ファイルで切り替える
- ログイン情報を外部ファイル・環境変数で管理する
- ログイン状態をstorageStateで保存し、各テストで再利用する

## 初期設定

```bash
npm install
npm run install:browsers
cp .env.example .env
cp config/login-users.example.json config/login-users.local.json
```

`.env` にテスト用ユーザーを設定します。

```env
TEST_ENV=local
TEST_USER_EMAIL=test@example.com
TEST_USER_PASSWORD=Password123!
LOGIN_USERS_FILE=config/login-users.local.json
```

## 環境切り替え

`config/environments.json` の `local` / `stg` などを編集します。
実行時は `.env` の `TEST_ENV` を切り替えます。

## ログイン情報

`config/login-users.local.json` にログインパスやユーザー定義を書きます。
パスワード等の機密値は `${TEST_USER_PASSWORD}` のように環境変数参照にします。
このファイルは `.gitignore` 対象です。

## 実行

```bash
npm test
```

ログイン用setupが先に動き、`playwright/.auth/*.json` に認証状態を保存します。
各テストは保存済みの認証状態を使います。

## Excelから雛形生成

```bash
npm run gen:from-excel -- ./testcases.xlsx tests/generated/from-excel.generated.spec.ts
```

生成されるコードはあくまで雛形です。
操作手順と期待結果は、必ず人が確認してPlaywright操作・expectに変換してください。

## 推奨列

- TC_ID
- 画面
- URL
- 前提条件
- 手順
- 入力値
- 期待結果
- 自動化可否

## 注意

- 本番環境で登録・更新・削除系の自動実行をしない
- 認証情報、Cookie、storageStateをGitに入れない
- AI生成コードは必ずレビューする
- Excel/CATのテストケースIDをPlaywright側にも残す
