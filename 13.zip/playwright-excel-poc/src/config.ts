import fs from 'node:fs';
import path from 'node:path';
import dotenv from 'dotenv';

dotenv.config();

type EnvConfig = {
  baseUrl: string;
  headless: boolean;
  storageState: string;
  defaultTimeoutMs: number;
};

type LoginUser = {
  email: string;
  password: string;
  loginPath: string;
};

function readJson<T>(filePath: string): T {
  const absolutePath = path.resolve(process.cwd(), filePath);
  if (!fs.existsSync(absolutePath)) {
    throw new Error(`設定ファイルが見つかりません: ${absolutePath}`);
  }
  return JSON.parse(fs.readFileSync(absolutePath, 'utf-8')) as T;
}

function expandEnv(value: string): string {
  return value.replace(/\$\{([A-Z0-9_]+)\}/g, (_, name: string) => {
    const envValue = process.env[name];
    if (envValue === undefined) {
      throw new Error(`環境変数 ${name} が未設定です`);
    }
    return envValue;
  });
}

export function getEnvConfig(): EnvConfig {
  const envName = process.env.TEST_ENV || 'local';
  const all = readJson<Record<string, EnvConfig>>('config/environments.json');
  const config = all[envName];
  if (!config) {
    throw new Error(`TEST_ENV=${envName} に対応する設定が config/environments.json にありません`);
  }
  return config;
}

export function getLoginUser(userKey = 'default'): LoginUser {
  const loginUsersFile = process.env.LOGIN_USERS_FILE || 'config/login-users.local.json';
  const users = readJson<Record<string, LoginUser>>(loginUsersFile);
  const user = users[userKey];
  if (!user) {
    throw new Error(`ログインユーザー ${userKey} が ${loginUsersFile} にありません`);
  }
  return {
    email: expandEnv(user.email),
    password: expandEnv(user.password),
    loginPath: user.loginPath
  };
}
