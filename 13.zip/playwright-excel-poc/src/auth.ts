import { expect, type Page } from '@playwright/test';
import { getLoginUser } from './config';

/**
 * ログイン処理の共通化サンプル。
 * 実案件ではラベル名・ボタン名・ログイン後の確認文言を対象画面に合わせて変更してください。
 */
export async function login(page: Page, userKey = 'default') {
  const user = getLoginUser(userKey);

  await page.goto(user.loginPath);
  await page.getByLabel(/メール|email/i).fill(user.email);
  await page.getByLabel(/パスワード|password/i).fill(user.password);
  await page.getByRole('button', { name: /ログイン|sign in|login/i }).click();

  // ログイン成功の判定は、案件に合わせてURL・表示文言・APIレスポンスなどに変更する
  await expect(page).not.toHaveURL(/.*\/login/);
}
