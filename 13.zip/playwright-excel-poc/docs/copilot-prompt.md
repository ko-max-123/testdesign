# MS 365 Copilot / Copilot Chat 用プロンプト例

以下のExcelテストケースを、Playwright + TypeScript のE2Eテストに変換してください。

前提:
- @playwright/test を使う
- 1テストケース = 1つの test() にする
- テスト名の先頭にExcelのテストケースIDを入れる
- locator は getByRole / getByLabel / getByText / data-testid を優先する
- CSSセレクタや nth-child は極力使わない
- 期待結果は必ず expect() に変換する
- ログイン済み前提のテストでは、storageState を使うためログイン操作は書かない
- テストデータや認証情報はコードに直書きしない
- 不明点は TODO コメントにする

出力形式:
- TypeScriptコードのみ
- ファイル名: tests/generated/<機能名>.generated.spec.ts

Excel列の意味:
- TC_ID: テストケースID
- 画面: 対象画面
- URL: 開始URL
- 前提条件: テスト開始前の状態
- 手順: 操作手順
- 入力値: 入力データ
- 期待結果: 確認すべき結果
- 自動化可否: ○のみ生成、△はTODO付き、×は生成しない

以下が対象データです。
（ここにExcelの対象行を貼り付け）
