import fs from 'node:fs';
import path from 'node:path';
import * as XLSX from 'xlsx';

type Row = Record<string, string | number | boolean | undefined>;

function v(row: Row, keys: string[], fallback = ''): string {
  for (const key of keys) {
    const value = row[key];
    if (value !== undefined && value !== null && String(value).trim() !== '') {
      return String(value).trim();
    }
  }
  return fallback;
}

function safeTestName(value: string): string {
  return value.replace(/[\r\n]+/g, ' ').replace(/'/g, "\\'");
}

function toTestBlock(row: Row): string {
  const id = v(row, ['TC_ID', 'ケースID', 'No', 'ID'], 'NO_ID');
  const title = v(row, ['テストケース名', 'ケース名', '確認項目', '観点'], '名称未設定');
  const url = v(row, ['URL', '画面URL', 'パス'], '/');
  const steps = v(row, ['手順', '操作手順', '実施手順'], '');
  const expected = v(row, ['期待結果', '確認内容', '想定結果'], '');

  return `
  test('${safeTestName(id)} ${safeTestName(title)}', async ({ page }) => {
    await page.goto('${url}');

    /*
     * 元Excelの操作手順:
${steps.split(/\r?\n/).map(line => `     * - ${line}`).join('\n')}
     *
     * 元Excelの期待結果:
${expected.split(/\r?\n/).map(line => `     * - ${line}`).join('\n')}
     */

    // TODO: 操作手順をPlaywright操作に変換する
    // 例: await page.getByRole('button', { name: '検索' }).click();

    // TODO: 期待結果をexpectに変換する
    // 例: await expect(page.getByText('検索結果')).toBeVisible();
  });`;
}

function main() {
  const [, , input, output = 'tests/generated/from-excel.generated.spec.ts', sheetNameArg] = process.argv;
  if (!input) {
    console.error('Usage: npm run gen:from-excel -- <input.xlsx> [output.spec.ts] [sheetName]');
    process.exit(1);
  }

  const workbook = XLSX.readFile(input);
  const sheetName = sheetNameArg || workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) {
    throw new Error(`シートが見つかりません: ${sheetName}`);
  }

  const rows = XLSX.utils.sheet_to_json<Row>(sheet, { defval: '' });
  const targetRows = rows.filter(row => {
    const auto = v(row, ['自動化可否', '自動化対象', 'Playwright化'], '○');
    return !['×', 'x', 'X', 'NG', '対象外'].includes(auto);
  });

  const content = `import { test, expect } from '@playwright/test';

// このファイルは scripts/excel-to-playwright.ts により生成された雛形です。
// 生成後、操作と期待結果を人が確認・修正してください。

test.describe('Excelテストケース由来シナリオ', () => {${targetRows.map(toTestBlock).join('\n')}
});
`;

  const outputPath = path.resolve(process.cwd(), output);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, content, 'utf-8');
  console.log(`Generated: ${outputPath}`);
}

main();
