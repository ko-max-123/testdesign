import fs from 'node:fs';
import path from 'node:path';
import { test as setup } from '@playwright/test';
import { getEnvConfig } from '../../src/config';
import { login } from '../../src/auth';

setup('認証状態を保存する', async ({ page }) => {
  const env = getEnvConfig();
  await login(page, 'default');

  const authDir = path.dirname(env.storageState);
  fs.mkdirSync(authDir, { recursive: true });
  await page.context().storageState({ path: env.storageState });
});
