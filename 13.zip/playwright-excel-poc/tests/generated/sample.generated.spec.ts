import { test, expect } from '@playwright/test';

test.describe('サンプル: Excelテストケース由来', () => {
  test('TC_LOGIN_001 正常ログイン後にマイページが表示される', async ({ page }) => {
    // storageStateによりログイン済み状態から開始する想定
    await page.goto('/mypage');
    await expect(page.getByText(/マイページ|My Page/i)).toBeVisible();
  });
});
