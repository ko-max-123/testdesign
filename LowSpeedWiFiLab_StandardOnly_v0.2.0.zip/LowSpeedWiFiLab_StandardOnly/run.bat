@echo off
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python が見つかりません。
  echo Python 3.10 以上をインストールしてから再実行してください。
  pause
  exit /b 1
)

python "%~dp0app.py"
