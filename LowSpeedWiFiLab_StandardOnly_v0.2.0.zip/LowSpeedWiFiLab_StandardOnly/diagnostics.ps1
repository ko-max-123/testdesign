$ErrorActionPreference = "Continue"

Write-Host "=== LowSpeedWiFiLab Diagnostics ===" -ForegroundColor Cyan

Write-Host "`n[OS]"
Get-ComputerInfo |
    Select-Object WindowsProductName, WindowsVersion, OsBuildNumber

Write-Host "`n[IPv4]"
Get-NetIPAddress -AddressFamily IPv4 |
    Select-Object InterfaceAlias, IPAddress, PrefixLength |
    Sort-Object InterfaceAlias |
    Format-Table -AutoSize

Write-Host "`n[Neighbors]"
Get-NetNeighbor -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Select-Object IPAddress, InterfaceAlias, LinkLayerAddress, State |
    Format-Table -AutoSize

Write-Host "`n[LowSpeedWiFiLab QoS]"
Get-NetQosPolicy -PolicyStore ActiveStore -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like "LowSpeedWiFiLab*" } |
    Format-List *

Write-Host "`n[Network Adapters]"
Get-NetAdapter -IncludeHidden |
    Select-Object Name, InterfaceDescription, Status, MacAddress, ifIndex |
    Format-Table -AutoSize
