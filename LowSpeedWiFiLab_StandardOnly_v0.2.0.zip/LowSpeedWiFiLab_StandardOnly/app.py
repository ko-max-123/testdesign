from __future__ import annotations

import ctypes
import ipaddress
import json
import platform
import subprocess
import sys
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox

APP_NAME = "LowSpeedWiFiLab Standard"
POLICY_PREFIX = "LowSpeedWiFiLab"
BASE_DIR = Path(__file__).resolve().parent
PROFILE_DIR = BASE_DIR / "profiles"


def is_windows() -> bool:
    return platform.system().lower() == "windows"


def is_admin() -> bool:
    if not is_windows():
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin() -> bool:
    if not is_windows() or is_admin():
        return True
    try:
        script = str(Path(__file__).resolve())
        workdir = str(BASE_DIR)
        result = ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable, f'"{script}"', workdir, 1
        )
        return result > 32
    except Exception:
        return False


def run_ps(script: str, timeout: int = 30) -> subprocess.CompletedProcess:
    if not is_windows():
        raise RuntimeError("この機能はWindows専用です。")
    return subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )


def validate_ipv4(value: str) -> str:
    ip = ipaddress.ip_address(value.strip())
    if ip.version != 4:
        raise ValueError("IPv4アドレスを指定してください。")
    return str(ip)


def mbps_to_bps(value: float) -> int:
    if value < 0:
        raise ValueError("速度は0以上を指定してください。")
    return int(value * 1_000_000)


def discover_private_neighbors() -> list[tuple[str, str]]:
    script = r"""
$locals = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Select-Object -ExpandProperty IPAddress

Get-NetNeighbor -AddressFamily IPv4 -ErrorAction SilentlyContinue |
Where-Object {
    $_.State -in @('Reachable','Stale','Delay','Probe','Permanent') -and
    $_.IPAddress -notin $locals -and
    $_.IPAddress -notmatch '^(127\.|169\.254\.|224\.|239\.|255\.)'
} |
Select-Object IPAddress,InterfaceAlias,LinkLayerAddress |
ConvertTo-Json -Compress
"""
    cp = run_ps(script)
    if cp.returncode != 0 or not cp.stdout.strip():
        return []

    try:
        data = json.loads(cp.stdout)
        if isinstance(data, dict):
            data = [data]
    except json.JSONDecodeError:
        return []

    result = []
    for row in data:
        ip = str(row.get("IPAddress", "")).strip()
        if not ip:
            continue
        try:
            addr = ipaddress.ip_address(ip)
            if addr.version != 4 or not addr.is_private:
                continue
        except ValueError:
            continue

        alias = row.get("InterfaceAlias", "?")
        mac = row.get("LinkLayerAddress", "")
        result.append((ip, f"{ip}  [{alias}]  {mac}"))

    return sorted(set(result))


class QosEngine:
    def __init__(self, logger):
        self.log = logger

    @staticmethod
    def _names() -> tuple[str, str]:
        return f"{POLICY_PREFIX}-DOWNLOAD", f"{POLICY_PREFIX}-UPLOAD"

    def cleanup(self):
        down, up = self._names()
        script = f"""
$ErrorActionPreference='SilentlyContinue'
Get-NetQosPolicy -PolicyStore ActiveStore -Name '{down}' |
    Remove-NetQosPolicy -PolicyStore ActiveStore -Confirm:$false
Get-NetQosPolicy -PolicyStore ActiveStore -Name '{up}' |
    Remove-NetQosPolicy -PolicyStore ActiveStore -Confirm:$false
"""
        run_ps(script)

    def start(self, client_ip: str, download_bps: int, upload_bps: int):
        if not is_admin():
            raise PermissionError("管理者権限が必要です。")

        client_ip = validate_ipv4(client_ip)
        self.cleanup()

        down_name, up_name = self._names()
        commands = ["$ErrorActionPreference='Stop'"]

        if download_bps > 0:
            commands.append(
                f"New-NetQosPolicy -Name '{down_name}' "
                f"-PolicyStore ActiveStore "
                f"-NetworkProfile All "
                f"-IPProtocolMatchCondition Both "
                f"-IPDstPrefixMatchCondition '{client_ip}/32' "
                f"-ThrottleRateActionBitsPerSecond {download_bps} | Out-Null"
            )

        if upload_bps > 0:
            commands.append(
                f"New-NetQosPolicy -Name '{up_name}' "
                f"-PolicyStore ActiveStore "
                f"-NetworkProfile All "
                f"-IPProtocolMatchCondition Both "
                f"-IPSrcPrefixMatchCondition '{client_ip}/32' "
                f"-ThrottleRateActionBitsPerSecond {upload_bps} | Out-Null"
            )

        commands.append(
            f"Get-NetQosPolicy -PolicyStore ActiveStore | "
            f"Where-Object {{$_.Name -like '{POLICY_PREFIX}*'}} | "
            f"Select-Object Name,ThrottleRate,IPSrcPrefixMatchCondition,IPDstPrefixMatchCondition | "
            f"Format-Table -AutoSize"
        )

        cp = run_ps("\n".join(commands))
        if cp.returncode != 0:
            raise RuntimeError(cp.stderr.strip() or cp.stdout.strip() or "QoS設定に失敗しました。")

        self.log("QoSポリシーを適用しました。")
        if cp.stdout.strip():
            self.log(cp.stdout.strip())

    def stop(self):
        self.cleanup()
        self.log("QoSポリシーを解除しました。")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LowSpeedWiFiLab Standard")
        self.geometry("760x600")
        self.minsize(700, 560)
        self.qos = QosEngine(self.log)
        self.running = False
        self._neighbor_map = {}
        self._build()
        self._load_profiles()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build(self):
        pad = {"padx": 10, "pady": 5}

        top = ttk.Frame(self)
        top.pack(fill="x", padx=12, pady=(12, 4))
        ttk.Label(top, text="LowSpeedWiFiLab Standard", font=("", 18, "bold")).pack(side="left")
        ttk.Label(
            top,
            text="Python + Windows標準機能のみ",
            foreground="#555"
        ).pack(side="right")

        frm = ttk.LabelFrame(self, text="回線制限設定")
        frm.pack(fill="x", padx=12, pady=8)

        ttk.Label(frm, text="対象スマホ IPv4").grid(row=0, column=0, sticky="w", **pad)
        self.ip_var = tk.StringVar(value="192.168.137.2")
        self.ip_combo = ttk.Combobox(frm, textvariable=self.ip_var, width=42)
        self.ip_combo.grid(row=0, column=1, sticky="ew", **pad)
        ttk.Button(frm, text="端末候補を検出", command=self.detect_clients).grid(row=0, column=2, **pad)

        ttk.Label(frm, text="プリセット").grid(row=1, column=0, sticky="w", **pad)
        self.profile_var = tk.StringVar()
        self.profile_combo = ttk.Combobox(frm, textvariable=self.profile_var, state="readonly")
        self.profile_combo.grid(row=1, column=1, columnspan=2, sticky="ew", **pad)
        self.profile_combo.bind("<<ComboboxSelected>>", lambda _e: self.apply_profile())

        ttk.Label(frm, text="Download上限 (Mbps)").grid(row=2, column=0, sticky="w", **pad)
        self.down_var = tk.StringVar(value="1.0")
        ttk.Entry(frm, textvariable=self.down_var).grid(row=2, column=1, columnspan=2, sticky="ew", **pad)

        ttk.Label(frm, text="Upload上限 (Mbps)").grid(row=3, column=0, sticky="w", **pad)
        self.up_var = tk.StringVar(value="0.5")
        ttk.Entry(frm, textvariable=self.up_var).grid(row=3, column=1, columnspan=2, sticky="ew", **pad)

        ttk.Label(
            frm,
            text="※ 固定遅延・Jitter・Packet Lossは扱いません。Windows標準QoSによる帯域制限のみです。",
            foreground="#555",
        ).grid(row=4, column=0, columnspan=3, sticky="w", padx=10, pady=(2, 8))

        frm.columnconfigure(1, weight=1)

        buttons = ttk.Frame(self)
        buttons.pack(fill="x", padx=12, pady=4)
        self.start_btn = ttk.Button(buttons, text="START", command=self.start_limit)
        self.start_btn.pack(side="left", ipadx=25, ipady=5)
        self.stop_btn = ttk.Button(buttons, text="STOP", command=self.stop_limit, state="disabled")
        self.stop_btn.pack(side="left", padx=8, ipadx=25, ipady=5)
        ttk.Button(buttons, text="強制クリーンアップ", command=self.force_cleanup).pack(side="right")

        info = ttk.LabelFrame(self, text="使い方")
        info.pack(fill="x", padx=12, pady=8)
        ttk.Label(
            info,
            text=(
                "1. Windowsのモバイル ホットスポットをON\n"
                "2. スマホをPCのWi-Fiへ接続\n"
                "3. スマホのIPv4を指定\n"
                "4. プリセットまたは速度を設定\n"
                "5. START\n"
                "6. スマホ側で実際に速度が下がっていることを確認"
            ),
            justify="left"
        ).pack(anchor="w", padx=10, pady=8)

        logfrm = ttk.LabelFrame(self, text="ログ")
        logfrm.pack(fill="both", expand=True, padx=12, pady=(5, 12))
        self.log_text = tk.Text(logfrm, height=13, wrap="word")
        self.log_text.pack(fill="both", expand=True, padx=6, pady=6)

    def _load_profiles(self):
        self.profiles = {}
        for path in sorted(PROFILE_DIR.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                self.profiles[data["name"]] = data
            except Exception as exc:
                self.log(f"プリセット読込失敗: {path.name}: {exc}")

        self.profile_combo["values"] = list(self.profiles.keys())
        if self.profiles:
            default = "低速Wi-Fi"
            self.profile_var.set(default if default in self.profiles else next(iter(self.profiles)))
            self.apply_profile()

    def apply_profile(self):
        data = self.profiles.get(self.profile_var.get())
        if not data:
            return
        self.down_var.set(str(data["download_mbps"]))
        self.up_var.set(str(data["upload_mbps"]))

    def log(self, message: str):
        stamp = time.strftime("%H:%M:%S")
        try:
            self.log_text.insert("end", f"[{stamp}] {message}\n")
            self.log_text.see("end")
        except Exception:
            pass

    def detect_clients(self):
        try:
            rows = discover_private_neighbors()
        except Exception as exc:
            messagebox.showerror("検出エラー", str(exc))
            return

        self._neighbor_map = {label: ip for ip, label in rows}
        self.ip_combo["values"] = [label for _, label in rows]

        if rows:
            self.ip_var.set(rows[0][0])
            self.log(f"{len(rows)}件の候補を検出しました。")
        else:
            self.log("候補を検出できませんでした。スマホのWi-Fi詳細画面でIPv4を確認してください。")

    def _get_ip(self) -> str:
        raw = self.ip_var.get().strip()
        if raw in self._neighbor_map:
            raw = self._neighbor_map[raw]
        raw = raw.split()[0]
        return validate_ipv4(raw)

    def start_limit(self):
        if self.running:
            return

        try:
            ip = self._get_ip()
            down = mbps_to_bps(float(self.down_var.get()))
            up = mbps_to_bps(float(self.up_var.get()))

            self.qos.start(ip, down, up)
            self.running = True
            self.start_btn.config(state="disabled")
            self.stop_btn.config(state="normal")
            self.log(f"START target={ip} Download={down/1e6:.3g}Mbps Upload={up/1e6:.3g}Mbps")

        except Exception as exc:
            messagebox.showerror("開始できません", str(exc))
            self.log(f"開始失敗: {exc}")

    def stop_limit(self):
        try:
            self.qos.stop()
        except Exception as exc:
            self.log(f"停止時エラー: {exc}")

        self.running = False
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")

    def force_cleanup(self):
        try:
            self.qos.cleanup()
            self.log("強制クリーンアップ完了。")
        except Exception as exc:
            messagebox.showerror("クリーンアップ失敗", str(exc))

    def on_close(self):
        try:
            self.qos.cleanup()
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    if not is_windows():
        print("このツールはWindows 10/11専用です。")
        sys.exit(1)

    if not is_admin():
        if relaunch_as_admin():
            sys.exit(0)
        print("管理者権限で起動できませんでした。")
        sys.exit(2)

    App().mainloop()
