# LowSpeedWiFiLab Standard

## 概要

この版は **Python + Windows標準機能だけ** で構成しています。

追加インストールするもの:

```text
Python 3.10以上
```

のみです。

以下は不要です。

```text
WinDivert
pydivert
NetLimiter
Clumsy
Charles
Fiddler
追加ドライバ
追加pipパッケージ
```

Python標準ライブラリのみ使用します。

---

# 構成

```text
Internet
   |
Windows PC
   |
Windows Mobile Hotspot
   |
iPhone / Android
```

PC側でWindows標準のQoSポリシーを作成し、対象スマホの通信速度を制限します。

---

# 必要条件

- Windows 10 / 11
- Python 3.10以上
- 管理者権限
- Windows モバイル ホットスポット

PythonはMicrosoft Store版より、通常のWindows向け64bit版を推奨します。

---

# 使い方

## 1. PCをインターネットへ接続

できれば有線LAN推奨。

## 2. WindowsモバイルホットスポットをON

```text
設定
 > ネットワークとインターネット
 > モバイル ホットスポット
 > ON
```

## 3. iPhoneを接続

iPhoneからWindows PCのSSIDへ接続します。

## 4. 起動

```text
run.bat
```

アプリ側で必要に応じて管理者権限へ昇格します。

## 5. スマホIPを指定

iPhone:

```text
設定
 > Wi-Fi
 > 接続中SSID
 > IPアドレス
```

例:

```text
192.168.137.2
```

GUIの「端末候補を検出」でも候補を表示できます。

## 6. 回線速度を設定

例:

```text
Download : 1 Mbps
Upload   : 0.5 Mbps
```

## 7. START

START後、必ずスマホ側で実際の速度が落ちているか確認してください。

## 8. STOP

テスト終了後はSTOP。

---

# プリセット

```text
良好Wi-Fi
低速Wi-Fi
かなり低速
3G相当
極端に低速
```

---

# 異常終了した場合

管理者PowerShellで:

```powershell
.\cleanup.ps1
```

LowSpeedWiFiLabが作成したQoSポリシーだけを削除します。

---

# 動作確認

うまくいかない場合:

```powershell
.\diagnostics.ps1
```

を管理者PowerShellから実行してください。

---

# 重要な制約

この版はWindows標準のQoS機能だけを利用しています。

そのため制御対象は:

```text
Download上限
Upload上限
```

です。

以下は再現しません。

```text
固定遅延
Jitter
Packet Loss
```

また、Windows Mobile HotspotはICS/NATを使用します。
Windowsのビルドやネットワークドライバによっては、転送通信へのQoS適用が期待どおりにならない場合があります。

そのためテスト前に必ず:

```text
START
↓
iPhoneで速度確認
↓
目的の速度になっていることを確認
↓
本テスト開始
```

という流れにしてください。

---

# ファイル

```text
app.py
  GUIとQoS制御本体

run.bat
  起動

cleanup.ps1
  QoS強制解除

diagnostics.ps1
  ネットワーク診断

profiles/
  回線速度プリセット
```

追加ライブラリはありません。
