$ErrorActionPreference = "SilentlyContinue"

Get-NetQosPolicy -PolicyStore ActiveStore |
    Where-Object { $_.Name -like "LowSpeedWiFiLab*" } |
    Remove-NetQosPolicy -PolicyStore ActiveStore -Confirm:$false

Write-Host "LowSpeedWiFiLab の QoS ポリシーを削除しました。"
