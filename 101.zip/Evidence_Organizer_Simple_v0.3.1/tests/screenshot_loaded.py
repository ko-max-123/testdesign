import sys
from pathlib import Path
from PIL import ImageGrab
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import SimpleApp
from excel_catalog import WorkbookCatalog
from simple_engine import options_from_catalog
app=SimpleApp()
book=WorkbookCatalog.from_file(Path(__file__).resolve().parent/'仕様書_シナリオ型.xlsx')
app.book=book
app.scenarios=options_from_catalog(book)
app.book_path.set(book.spec)
app.feature_var.set(book.feature)
app.scenario_combo.configure(values=[x[0] for x in app.scenarios])
app.scenario_var.set(app.scenarios[0][0])
app._scenario_changed()
app._refresh()
app.update()
ImageGrab.grab().save('/mnt/data/Evidence_Organizer_Simple_v0.3/Evidence_Organizer_v0.3_preview.png')
app.destroy()
