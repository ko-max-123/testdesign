from pathlib import Path
import sys
import pytest
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from excel_catalog import WorkbookCatalog
from simple_engine import options_from_catalog, make_start, make_end, sort_folder, order_by_capture_sequence
from evidence_core import ImageItem, read_qr, Segment, load_sessions, id_folder_name, spec_folder_name

DEMO = Path(__file__).resolve().parent


def test_excel_two_styles_and_no_excel_ext():
    for name in ('仕様書_シナリオ型.xlsx', '仕様書_複数手順型.xlsx'):
        book = WorkbookCatalog.from_file(DEMO / name)
        assert book.spec == Path(name).stem
        options = options_from_catalog(book)
        assert options and all(row[3] for row in options)
    book = WorkbookCatalog.from_file(DEMO / '仕様書_シナリオ型.xlsx')
    assert options_from_catalog(book)[0][2] == 'P1-1'


@pytest.mark.parametrize(('raw','formatted'),[('1','ID1'),('03','ID03'),('ID7','ID7'),('id8','ID8'),('S1-3','IDS1-3')])
def test_id_folder_format(raw,formatted):
    assert id_folder_name(raw) == formatted


def test_spec_name_old_and_new():
    assert spec_folder_name('テスト仕様書.xlsx') == 'テスト仕様書'
    assert spec_folder_name('テスト仕様書.XLSM') == 'テスト仕様書'
    assert spec_folder_name('テスト仕様書') == 'テスト仕様書'


def test_marker_and_new_folder_structure(tmp_path):
    sess, start=make_start(tmp_path,'決済機能','テスト仕様書.xlsx','Sheet1','P1-1','3')
    end=make_end(tmp_path,sess)
    assert read_qr(start)[0] == (sess.sid,'START')
    assert read_qr(end)[0] == (sess.sid,'END')
    assert sess.folder(tmp_path,'And',output_root=tmp_path/'選択フォルダ') == tmp_path/'選択フォルダ'/'決済機能'/'テスト仕様書'/'P1-1'/'ID3'/'And'
    assert sess.folder(tmp_path,'iOS',output_root=tmp_path/'選択フォルダ') == tmp_path/'選択フォルダ'/'決済機能'/'テスト仕様書'/'P1-1'/'ID3'/'iOS'
    assert sess.expect_start == '3'


def test_old_marker_record_is_normalized():
    old=Segment.create('機能','既存.xlsx','P1-1',item_id='', expect_start='7', expect_end='7')
    assert (old.spec,old.item_id)==('既存','ID7')
    old2=Segment.create('機能','既存.xlsx','P1-1',item_id='7',expect_start='7')
    assert old2.item_id=='ID7'


def test_order_when_metadata_missing(tmp_path):
    rows = [ImageItem(tmp_path/f'IMG_{n:04}.JPG', 9999-float(n), 'mtime') for n in (1010,1009,1007,1008)]
    ordered, how=order_by_capture_sequence(rows)
    assert how=='IMG連番'
    assert [r.path.name for r in ordered]==[f'IMG_{n:04}.JPG' for n in (1007,1008,1009,1010)]


def setup_photos(tmp_path):
    input_dir=tmp_path/'写真としおり';input_dir.mkdir()
    work=tmp_path/'work'
    sess,start=make_start(work,'決済機能','テスト仕様書A.xlsx','Sheet1','P1-1','5')
    end=make_end(work,sess)
    with Image.open(start) as img: img.save(input_dir/'IMG_1001.JPG',quality=95)
    ios=Image.new('RGB',(700,1100),'#6699dd'); ios.save(input_dir/'IMG_1002.PNG')
    android=Image.new('RGB',(900,1400),'#448866'); android.save(input_dir/'IMG_1003.JPG')
    with Image.open(end) as img: img.save(input_dir/'IMG_1004.JPG',quality=95)
    return input_dir,work,sess


def test_end_to_end_selected_folder_auto_cases_id_and_no_rename(tmp_path):
    source,work,sess=setup_photos(tmp_path)
    result=sort_folder(source,work,output_root=source)
    assert (result.copied,result.markers,result.hold)==(2,2,0),result
    case_folder=source/'決済機能'/'テスト仕様書A'/'P1-1'/'ID5'
    assert (case_folder/'iOS'/'IMG_1002.PNG').read_bytes()==(source/'IMG_1002.PNG').read_bytes()
    assert (case_folder/'And'/'IMG_1003.JPG').read_bytes()==(source/'IMG_1003.JPG').read_bytes()
    assert set(f.name for f in source.iterdir())=={'IMG_1001.JPG','IMG_1002.PNG','IMG_1003.JPG','IMG_1004.JPG','決済機能'}
    assert not (work/'エビデンス').exists(), 'User HOME/working storage must not receive photos'
    second=sort_folder(source,work,output_root=source)
    assert second.copied==0 and second.hold==2
    # No nesting or reprocessing outputs on second run.
    assert not (case_folder/'And'/'決済機能').exists()
    assert second.total==4


def test_two_ids_same_case_separate_folders(tmp_path):
    source=tmp_path/'source';source.mkdir();work=tmp_path/'work'
    for i,n in [('5',1000),('6',1004)]:
        seg,start=make_start(work,'機能','仕様書.xlsx','Sheet','P1-2',i)
        end=make_end(work,seg)
        with Image.open(start) as im: im.save(source/f'IMG_{n+1}.JPG')
        Image.new('RGB',(700,700)).save(source/f'IMG_{n+2}.PNG')
        with Image.open(end) as im: im.save(source/f'IMG_{n+3}.JPG')
    result=sort_folder(source,work,output_root=source)
    assert (result.copied,result.markers,result.hold)==(2,4,0)
    for i,n in [('5',1002),('6',1006)]:
        assert (source/'機能'/'仕様書'/'P1-2'/f'ID{i}'/'iOS'/f'IMG_{n}.PNG').exists()


@pytest.mark.parametrize('missing',['START','END'])
def test_unpaired_bookmark_does_not_copy(tmp_path,missing):
    source=tmp_path/'source';source.mkdir();work=tmp_path/'work'
    seg,start=make_start(work,'機能','仕様書.xlsx','Sheet','P1-1','9')
    end=make_end(work,seg)
    if missing=='START':
        Image.new('RGB',(900,900)).save(source/'IMG_0001.PNG')
        with Image.open(end) as im: im.save(source/'IMG_0002.JPG')
    else:
        with Image.open(start) as im: im.save(source/'IMG_0001.JPG')
        Image.new('RGB',(900,900)).save(source/'IMG_0002.PNG')
    result=sort_folder(source,work,output_root=source)
    assert result.copied==0 and result.hold==1


def test_no_overwrite_if_same_name_exists(tmp_path):
    source,work,sess=setup_photos(tmp_path)
    dest=source/'決済機能'/'テスト仕様書A'/'P1-1'/'ID5'/'And'
    dest.mkdir(parents=True)
    (dest/'IMG_1003.JPG').write_bytes(b'KEEP')
    result=sort_folder(source,work,output_root=source)
    assert result.copied==1 and result.hold==1
    assert (dest/'IMG_1003.JPG').read_bytes()==b'KEEP'
