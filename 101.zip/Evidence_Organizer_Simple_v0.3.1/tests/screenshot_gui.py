import sys
from pathlib import Path
from PIL import ImageGrab
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import SimpleApp
app=SimpleApp()
app.update()
ImageGrab.grab().save('/mnt/data/Evidence_Organizer_Simple_v0.3/preview.png')
app.destroy()
