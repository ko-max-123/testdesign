"""Read only XLSX / XLSM workbook labels for marker selection.

Uses Python standard-library zipfile and XML. Does NOT edit Excel files,
assume uniform test specs, or infer how many evidence photographs are needed.
"""
from __future__ import annotations
import json
import re
import zipfile
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field, asdict
from pathlib import Path
from collections import Counter
from typing import Optional

MAIN = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG_REL = 'http://schemas.openxmlformats.org/package/2006/relationships'
NS = {'m': MAIN, 'r': REL}


def clean_text(value) -> str:
    return re.sub(r'\s+', ' ', str(value or '').strip())


def normalized(value) -> str:
    return re.sub(r'[\s\u3000【】\[\]（）()・_./\\:：\-*＊]+', '', str(value or '').casefold())


def col_number(address: str) -> int:
    letters = re.match(r'^[A-Za-z]+', address)
    if not letters:
        return 0
    result = 0
    for c in letters.group(0).upper():
        result = result * 26 + ord(c) - 64
    return result


def col_label(i: int) -> str:
    if not i:
        return ''
    s = ''
    while i:
        i, n = divmod(i - 1, 26)
        s = chr(n + 65) + s
    return s


def read_xml(archive, name):
    return ET.fromstring(archive.read(name))


def inline_value(cell, strings):
    typ = cell.get('t', '')
    if typ == 'inlineStr':
        return ''.join(t.text or '' for t in cell.findall('.//m:is/m:t', NS))
    v = cell.find('m:v', NS)
    raw = v.text if v is not None else ''
    if typ == 's' and raw:
        idx = int(raw)
        return strings[idx] if 0 <= idx < len(strings) else ''
    if typ == 'b':
        return 'TRUE' if raw == '1' else 'FALSE'
    if typ in ('e', 'str', 'd'):
        return raw or ''
    # Excel numeric IDs are often stored as 1.0, preserve natural representation.
    if raw and re.fullmatch(r'[+-]?\d+\.0+', raw):
        return raw.split('.')[0]
    return raw or ''


def read_xlsx(path: Path, max_rows=25000, max_columns=120) -> dict[str, list[dict[int,str]]]:
    path = Path(path)
    if path.suffix.lower() not in ('.xlsx', '.xlsm'):
        raise ValueError('対応するExcel形式は .xlsx / .xlsm です。旧 .xls は .xlsx で保存してから読み込んでください。')
    try:
        with zipfile.ZipFile(path) as z:
            book = read_xml(z, 'xl/workbook.xml')
            rels = read_xml(z, 'xl/_rels/workbook.xml.rels')
            refs = {r.get('Id'):r.get('Target') for r in rels.findall(f'{{{PKG_REL}}}Relationship')}
            strings = []
            if 'xl/sharedStrings.xml' in z.namelist():
                shared = read_xml(z, 'xl/sharedStrings.xml')
                for si in shared.findall('m:si', NS):
                    strings.append(''.join(t.text or '' for t in si.findall('.//m:t', NS)))
            result = {}
            for sh in book.findall('m:sheets/m:sheet', NS):
                name = sh.get('name')
                rel_id = sh.get(f'{{{REL}}}id')
                dest = refs.get(rel_id, '')
                if not dest:
                    continue
                dest = dest.lstrip('/')
                if not dest.startswith('xl/'):
                    dest = 'xl/' + dest
                if dest not in z.namelist():
                    continue
                root = read_xml(z, dest)
                cells = []
                for row in root.findall('m:sheetData/m:row', NS):
                    row_index = int(row.get('r') or len(cells)+1)
                    if row_index > max_rows:
                        break
                    mapped = {0:str(row_index)}
                    for cell in row.findall('m:c', NS):
                        index = col_number(cell.get('r', ''))
                        if 1 <= index <= max_columns:
                            mapped[index] = clean_text(inline_value(cell, strings))
                    cells.append(mapped)
                result[name] = cells
            if not result:
                raise ValueError('Excelに利用可能なシートがありません。')
            return result
    except (zipfile.BadZipFile, KeyError, ET.ParseError) as e:
        raise ValueError(f'Excelの内容を読み込めませんでした: {e}') from e


@dataclass
class SheetCatalog:
    name: str
    rows: list[dict[int,str]] = field(default_factory=list)
    header_row: int = 1
    scenario_col: int = 0
    expected_col: int = 0
    description_col: int = 0

    def header(self, col: int) -> str:
        if not col: return ''
        data = next((row for row in self.rows if int(row[0]) == self.header_row), {})
        return data.get(col,'')

    def column_options(self) -> list[tuple[int,str]]:
        cols = sorted(set(i for row in self.rows[:500] for i in row if i))
        return [(i,f'{col_label(i)}列 | {self.header(i) or "(見出しなし)"}') for i in cols]

    def records(self) -> dict[str, list[tuple[str,str,int]]]:
        """scenario -> list of (expected ID, description, worksheet row) in sheet order.
        Duplicate expected IDs inside same scenario are allowed but filtered for dropdown.
        For merged scenario cells, carry down last nonempty scenario until next scenario.
        """
        result: dict[str,list] = {}
        current_scenario = ''
        header_seen = False
        for row in self.rows:
            n = int(row[0])
            if n <= self.header_row:
                continue
            current = clean_text(row.get(self.scenario_col,'')) if self.scenario_col else ''
            if current:
                current_scenario = current
            if not current_scenario:
                current_scenario = self.name
            expected = clean_text(row.get(self.expected_col,'')) if self.expected_col else ''
            if not expected:
                continue
            if normalized(expected) in {'id', 'sid', '期待値id', 'no', '項目id'}:
                continue
            description = clean_text(row.get(self.description_col, ''))[:240] if self.description_col else ''
            result.setdefault(current_scenario, []).append((expected,description,n))
        return result

    def ids_for(self, scenario: str) -> list[str]:
        return list(dict.fromkeys(row[0] for row in self.records().get(scenario,[])))

    def short_preview(self, scenario: str, start: str, end: str) -> str:
        records = self.records().get(scenario,[])
        ids = self.ids_for(scenario)
        if not ids:
            return '選択したシナリオに期待値IDがありません。列の対応を確認してください。'
        start_idx = ids.index(start) if start in ids else 0
        end_idx = ids.index(end) if end in ids else start_idx
        if end_idx < start_idx:
            return '開始IDが終了IDより後にあります。範囲を確認してください。'
        chosen = ids[start_idx:end_idx+1]
        lines = []
        for expected, desc, rownum in records:
            if expected in chosen and len(lines) < 18:
                lines.append(f'{expected} （行{rownum}） {desc or ""}')
        if len(chosen) > 18:
            lines.append('…（以下省略）')
        return '\n'.join(lines)


def guess_mapping(sheet: SheetCatalog) -> SheetCatalog:
    candidates = []
    for row in sheet.rows[:25]:
        words = {i:normalized(v) for i,v in row.items() if i and v}
        def pick(phrases):
            for phrase in phrases:
                for i, value in words.items():
                    if value == normalized(phrase): return i
            return 0
        scenario = pick(('シナリオID','シナリオ番号','シナリオNo','シナリオ','ケースID','ケース番号','ケースNo', 'ケース', 'No'))
        expected = pick(('期待値ID','期待値項目ID','項目ID','検証ID','ID','SID','確認ID'))
        description = pick(('確認項目','期待値','手順','操作手順','テスト手順','テスト観点'))
        score = (10 if expected else 0) + (8 if scenario else 0) + (3 if description else 0)
        candidates.append((score, -int(row[0]), scenario, expected, description, int(row[0])))
    if not candidates:
        return sheet
    score, _, scenario, expected, description, header = max(candidates)
    sheet.header_row = header
    sheet.scenario_col = scenario
    sheet.expected_col = expected
    sheet.description_col = description
    return sheet


@dataclass
class WorkbookCatalog:
    source: str
    feature: str
    spec: str
    sheets: list[SheetCatalog]

    @classmethod
    def from_file(cls, path: Path):
        path = Path(path).resolve()
        sheets = [guess_mapping(SheetCatalog(name=name,rows=rows)) for name,rows in read_xlsx(path).items()]
        # Parent folder name is a usable provisional feature; user can edit if unrelated.
        return cls(str(path), path.parent.name, path.stem, sheets)

    def sheet(self, name: str) -> Optional[SheetCatalog]:
        return next((s for s in self.sheets if s.name == name), None)


def save_catalogs(root: Path, catalogs: list[WorkbookCatalog]) -> None:
    parent = Path(root) / '管理データ'
    parent.mkdir(parents=True,exist_ok=True)
    target = parent/'excel_catalogs.json'
    content = {'schema':1, 'catalogs':[asdict(c) for c in catalogs]}
    pending = target.with_name(target.name+'.writing')
    try:
        pending.write_text(json.dumps(content,ensure_ascii=False,indent=2),encoding='utf-8')
        pending.replace(target)
    finally:
        pending.unlink(missing_ok=True)


def load_catalogs(root: Path) -> list[WorkbookCatalog]:
    source = Path(root)/'管理データ'/'excel_catalogs.json'
    if not source.exists(): return []
    data = json.loads(source.read_text(encoding='utf-8'))
    catalogs = []
    for entry in data.get('catalogs',[]):
        sheets=[]
        for s in entry.get('sheets',[]):
            s['rows'] = [{int(k):v for k,v in row.items()} for row in s['rows']]
            sheets.append(SheetCatalog(**s))
        catalogs.append(WorkbookCatalog(entry['source'],entry['feature'],entry['spec'],sheets))
    return catalogs
