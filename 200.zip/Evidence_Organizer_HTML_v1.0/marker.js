/* Offline bookmark QR + photographic fallback code. */
(function(global){
 const N=18, QUIET=12;
 const codeRegex=/^EO1:([a-f0-9]{12}):(START|END)$/i;
 function checksum(a){let crc=0xffff;for(const b of a){crc^=b<<8;for(let k=0;k<8;k++)crc=((crc&0x8000)?((crc<<1)^0x1021):(crc<<1))&0xffff;}return crc;}
 function bytes(sid,tag){let a=[0xe0,0x04];for(let i=0;i<12;i+=2)a.push(parseInt(sid.slice(i,i+2),16));a.push(tag==='START'?0xa5:0x5a);const crc=checksum(a);a.push(crc>>8,crc&255);return a;}
 function bitsFrom(a){let bits=[];for(const b of a)for(let k=7;k>=0;k--)bits.push((b>>k)&1);return bits;}
 function buildGrid(sid,tag){const payload=bitsFrom(bytes(sid,tag));const g=Array.from({length:N},()=>Array(N).fill(1));for(let i=0;i<196;i++)g[2+(i/14|0)][2+i%14]=i<176?payload[i%88]:i%2;return g;}
 function matrixCanvas(m,pixel=9,margin=4){ const canvas=document.createElement('canvas');const n=m.length;canvas.width=canvas.height=(n+2*margin)*pixel;const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#101820';for(let y=0;y<n;y++)for(let x=0;x<n;x++)if(m[y][x])ctx.fillRect((x+margin)*pixel,(y+margin)*pixel,pixel,pixel);return canvas; }
 function qrCanvas(sid,tag){const qr=new QRMatrix(0,QRErrorCorrectLevel.H);qr.addData(`EO1:${sid}:${tag}`);qr.make();const n=qr.getModuleCount();const grid=Array.from({length:n},(_,y)=>Array.from({length:n},(_,x)=>qr.isDark(y,x)?1:0));return matrixCanvas(grid,9);}
 function fallbackCanvas(sid,tag){return matrixCanvas(buildGrid(sid,tag),16,2);}
 function parse(v){const m=String(v||'').trim().match(codeRegex);return m?{sid:m[1].toLowerCase(),tag:m[2].toUpperCase()}:null;}
 function rotateBits(g){const z=g.length;return Array.from({length:z},(_,y)=>Array.from({length:z},(_,x)=>g[z-1-x][y]));}
 function decodeGrid(g){
  for(let rotation=0;rotation<4;rotation++,g=rotateBits(g)){
   let edge=0,total=0;for(let y=0;y<N;y++)for(let x=0;x<N;x++)if(x<2||x>=N-2||y<2||y>=N-2){total++;edge+=g[y][x]?1:0;}
   if(edge/total<.85)continue;
   const bits=[];for(let y=2;y<N-2;y++)for(let x=2;x<N-2;x++)bits.push(g[y][x]);
   let mismatch=0;for(let i=0;i<88;i++)if(bits[i]!==bits[i+88])mismatch++;
   if(mismatch>22)continue;
   const candidates=[bits.slice(0,88),bits.slice(88,176),bits.slice(0,88).map((b,i)=>(b|bits[i+88]))];
   for(const candidate of candidates){
     const a=[];for(let i=0;i<11;i++){let n=0;for(let k=0;k<8;k++)n=(n<<1)|candidate[i*8+k];a.push(n);}
     if(a[0]!==0xe0||a[1]!==0x04||![0xa5,0x5a].includes(a[8]))continue;
     if(checksum(a.slice(0,9))!==((a[9]<<8)|a[10]))continue;
     return {sid:a.slice(2,8).map(x=>x.toString(16).padStart(2,'0')).join(''),tag:a[8]===0xa5?'START':'END'};
   }
  }return null;
 }
 function sampleCanvas(canvas,box,img){const {width:w,height:h}=canvas;
  const values=[];const {l1,r1,l2,r2,y1,y2}=box;
  for(let y=0;y<N;y++){const ty=(y+.5)/N;const L=l1+(l2-l1)*ty, R=r1+(r2-r1)*ty;
   for(let x=0;x<N;x++){const tx=(x+.5)/N;const px=Math.max(0,Math.min(w-1,Math.round(L+(R-L)*tx))),py=Math.max(0,Math.min(h-1,Math.round(y1+(y2-y1)*ty)));const i=(py*w+px)*4;values.push((img[i]*.299+img[i+1]*.587+img[i+2]*.114));}}
  const sorted=[...values].sort((a,b)=>a-b);const low=sorted[12],high=sorted[sorted.length-12];if(high-low<45)return null;
  for(const threshold of [Math.min(170,Math.max(90,(low+high)/2)),130,165]){
   const g=Array.from({length:N},(_,y)=>Array.from({length:N},(_,x)=>values[y*N+x]<threshold?1:0));const hit=decodeGrid(g);if(hit)return hit;
  }return null;
 }
 // Find the long black solid lines forming the custom code's top/bottom frame.
 function findByFrame(canvas){
  const ctx=canvas.getContext('2d',{willReadFrequently:true}),w=canvas.width,h=canvas.height;
  const buf=ctx.getImageData(0,0,w,h).data;const lines=[];const step=Math.max(2,Math.floor(h/280));
  for(let y=0;y<h;y+=step){let st=-1;const runs=[];
   for(let x=0;x<w;x+=2){const i=(y*w+x)*4;const dark=buf[i]*.299+buf[i+1]*.587+buf[i+2]*.114<105;
    if(dark&&st<0)st=x;else if(!dark&&st>=0){const len=x-st;if(len>=Math.max(70,w*.055))runs.push({y,l:st,r:x});st=-1;}}
   if(st>=0&&w-st>=Math.max(70,w*.055))runs.push({y,l:st,r:w-1});lines.push(...runs);
  }
  // Pair upper/lower solid frame bars; both should span a large near-square image area.
  const top=lines.sort((a,b)=>(b.r-b.l)-(a.r-a.l)).slice(0,110);
  const pairs=[];
  for(const a of top)for(const b of top){if(b.y<=a.y)continue;
   const wa=a.r-a.l,wb=b.r-b.l,hd=b.y-a.y;if(hd<wa*.55||hd>wa*1.65||Math.abs(wb-wa)>wa*.36)continue;
   if(Math.abs((a.l+a.r)-(b.l+b.r))>wa*.5)continue;
   pairs.push({score:Math.min(wa,wb),a,b});}
  pairs.sort((a,b)=>b.score-a.score);
  for(const {a,b} of pairs.slice(0,240)){
   // Expand from inner part of black bars toward actual rectangle edges.
   const ratio=(b.y-a.y)/(a.r-a.l);
   if(ratio<.55||ratio>1.65)continue;
   const pad=Math.max(3,Math.round((a.r-a.l)*.03));
   for(const j of [0, -pad, pad]){
    const box={l1:a.l,r1:a.r,l2:b.l,r2:b.r,y1:a.y+j,y2:b.y+j};
    const found=sampleCanvas(canvas,box,buf);if(found)return found;
   }
  }return null;
 }
 async function decodeImage(file, options={}){
  if(!/\.((png|jpe?g|webp|bmp|gif|heic|heif))$/i.test(file.name))return null;
  let bitmap, decoder;
  try {bitmap=await createImageBitmap(file,{imageOrientation:'from-image'});}
  catch(_){
   // Some browser/OS combinations expose HEIC through WebCodecs, even when
   // createImageBitmap does not decode it. It is still optional browser support.
   if(typeof ImageDecoder==='undefined')return null;
   try{decoder=new ImageDecoder({data:file.stream(),type:file.type||(/\.hei[cf]$/i.test(file.name)?'image/heic':'image/jpeg')});
      const decoded=await decoder.decode();bitmap=decoded.image;
   }catch(_){try{decoder?.close();}catch(_){}return null;}
  }
  try {
   const iw=bitmap.displayWidth||bitmap.width,ih=bitmap.displayHeight||bitmap.height;
   const max=1250,scale=Math.min(1,max/Math.max(iw,ih));const w=Math.max(1,Math.round(iw*scale)),h=Math.max(1,Math.round(ih*scale));
   const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const cx=canvas.getContext('2d',{willReadFrequently:true});cx.drawImage(bitmap,0,0,w,h);
   if(typeof BarcodeDetector!=='undefined'){
    try{const det=new BarcodeDetector({formats:['qr_code']});const results=await det.detect(canvas);for(const v of results){const found=parse(v.rawValue);if(found)return found;}}catch(_){/* fallback */}
   }
   // Heuristic frame scanner is intentionally conservative. Unknown photos remain unassigned.
   const found=findByFrame(canvas);if(found||!options.aggressive)return found;
   for(const deg of [4,-4,8,-8,12,-12]){
     const rad=deg*Math.PI/180,cs=Math.cos(rad),sn=Math.sin(rad);
     const rw=Math.ceil(Math.abs(w*cs)+Math.abs(h*sn));
     const rh=Math.ceil(Math.abs(h*cs)+Math.abs(w*sn));
     const rotated=document.createElement('canvas');rotated.width=rw;rotated.height=rh;
     const rc=rotated.getContext('2d',{willReadFrequently:true});rc.fillStyle='white';rc.fillRect(0,0,rw,rh);
     rc.translate(rw/2,rh/2);rc.rotate(rad);rc.drawImage(canvas,-w/2,-h/2);
     const hit=findByFrame(rotated);if(hit)return hit;
   }
   return null;
  }finally{bitmap.close();try{decoder?.close();}catch(_){}}
 }
 global.EOMarker={qrCanvas,fallbackCanvas,buildGrid,decodeGrid,decodeImage,parse};
})(window);
