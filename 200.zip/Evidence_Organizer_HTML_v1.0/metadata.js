/* Client-side EXIF inspection. Never modifies image bytes. */
(function(global){
  const decoder=new TextDecoder('latin1');
  const screenshot=/screenshot|screen[ ._-]?shot|スクリーンショット|スクショ/i;
  function asDate(s){const m=String(s||'').match(/(20\d\d)[:\/-](\d\d)[:\/-](\d\d)[ T](\d\d):(\d\d):(\d\d)/); if(!m)return null;const d=new Date(+m[1],+m[2]-1,+m[3],+m[4],+m[5],+m[6]);return Number.isNaN(d.getTime())?null:d.getTime();}
  function parseTiff(a,start){
    if(start+8>a.length)return null;
    const le=a[start]===73&&a[start+1]===73; const be=a[start]===77&&a[start+1]===77;if(!le&&!be)return null;
    const dv=new DataView(a.buffer,a.byteOffset,a.byteLength);const u16=i=>(i+2<=a.length?dv.getUint16(i,le):null),u32=i=>(i+4<=a.length?dv.getUint32(i,le):null);
    if(u16(start+2)!==42)return null;
    const tags=new Map(),visited=new Set();
    function walk(offset,depth){
      if(depth>3||!Number.isInteger(offset)||offset<8||visited.has(offset))return;
      visited.add(offset);const base=start+offset;const count=u16(base);if(count===null||count>512||base+2+count*12>a.length)return;
      for(let i=0;i<count;i++){
        const p=base+2+i*12,tag=u16(p),type=u16(p+2),n=u32(p+4),pos=u32(p+8);if(!n||n>100000)return;
        const bytes={1:1,2:1,3:2,4:4,5:8,7:1,9:4,10:8}[type]||1;
        const dataPos=n*bytes<=4?p+8:start+pos;
        if(dataPos<0||dataPos+n*bytes>a.length)continue;
        let val=null;
        if(type===2){const chunk=a.subarray(dataPos,dataPos+Math.min(n,256));val=decoder.decode(chunk).replace(/\0.*/,'').trim();}
        else if(type===3)val=u16(dataPos);
        else if(type===4)val=u32(dataPos);
        else if(type===5 && dataPos+8<=a.length)val=`${u32(dataPos)}/${u32(dataPos+4)}`;
        else if(type===1)val=a[dataPos];
        if(val!==null)tags.set(tag,val);
        if(tag===0x8769||tag===0x8825)walk(pos,depth+1);
      }
    }
    walk(u32(start+4),0);
    return tags.size?tags:null;
  }
  function findExif(a){
    // JPEG APP1 marker: FF E1 [size] Exif 00 00 TIFF
    if(a[0]===0xff&&a[1]===0xd8){
      let p=2;
      while(p+10<a.length){if(a[p]!==0xff){p++;continue;}const mark=a[p+1];if(mark===0xda||mark===0xd9)break;const len=(a[p+2]<<8)|a[p+3];if(len<2)break;
        if(mark===0xe1&&decoder.decode(a.subarray(p+4,p+8))==='Exif'){
          const t=parseTiff(a,p+10);if(t)return t;
        } p+=2+len;
      }
    }
    if(a[0]===0xff&&a[1]===0xd8)return null;
    if(a[0]===0x89&&a[1]===0x50&&a[2]===0x4e&&a[3]===0x47)return null;
    // HEIC/HEIF stores EXIF in a box/item. Look for the TIFF header within
    // a bounded header/body window and validate the TIFF fields before trusting.
    for(let i=0;i<a.length-8;i++){
      if((a[i]===73&&a[i+1]===73&&a[i+2]===42&&a[i+3]===0)||
         (a[i]===77&&a[i+1]===77&&a[i+2]===0&&a[i+3]===42)){
        const found=parseTiff(a,i);if(found && ([0x829a,0x8827,0x9003,0x010f,0x0110,0x8769,0x920a].some(t=>found.has(t))))return found;
      }
    }
    return null;
  }
  const photoTags=[0x829a,0x829d,0x8827,0x920a,0xa434,0x9209,0x9207];
  async function inspect(file){
    const ext=(file.name.match(/\.([^.]+)$/)||[])[1]?.toLowerCase()||'';
    const array=new Uint8Array(await file.slice(0,Math.min(file.size,2_000_000)).arrayBuffer());
    const tags=findExif(array);const used=(tags?photoTags.filter(t=>tags.has(t)):[]);
    const dt=tags ? asDate(tags.get(0x9003)||tags.get(0x9004)||tags.get(0x0132)):null;
    if(used.length)return{os:'And',reason:`撮影EXIF（${used.map(x=>'0x'+x.toString(16)).slice(0,3).join('・')}）`,captureTime:dt};
    // A camera's make alone does not prove what screen is photographed.
    if(tags && tags.has(0x010f) && tags.has(0x0110) && tags.has(0x9003))return{os:'And',reason:'カメラ機種と撮影日時のEXIF',captureTime:dt};
    const software=String(tags?.get(0x0131)||'')+' '+String(tags?.get(0x010e)||'');
    if(screenshot.test(software))return{os:'iOS',reason:'スクリーンショットのメタデータ',captureTime:dt};
    if(screenshot.test(file.name))return{os:'iOS',reason:'スクリーンショットのファイル名',captureTime:dt};
    if(ext==='png')return{os:'iOS',reason:'撮影EXIFのないPNG（推定）',captureTime:dt};
    return{os:'',reason:'撮影EXIFが見つからないため保留',captureTime:dt};
  }
  function seqNumber(name){const m=name.match(/^(?:IMG|DSC|PXL)[_-]?(\d{3,7})(?:\.|[_-])/i);return m?Number(m[1]):null;}
  global.EOMetadata={inspect,seqNumber,findExif,parseTiff};
})(window);
