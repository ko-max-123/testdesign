/* Read xlsx/xlsm workbooks completely locally using vendored JSZip. */
(function (global) {
  const CASE_RE = /^P\s*(\d+)\s*[-ー－−]\s*(\d+)$/i;
  const xml = t => new DOMParser().parseFromString(t, 'application/xml');
  function descendants(node, name) { return [...node.getElementsByTagName('*')].filter(x => x.localName === name); }
  const firstText = (node, name) => { const n=descendants(node,name)[0]; return n ? n.textContent : ''; };
  function colIndex(s) {let n=0; for(const c of s.toUpperCase())n=n*26+c.charCodeAt(0)-64;return n-1;}
  function normalizedCase(v){const m=String(v??'').trim().match(CASE_RE); return m?`P${+m[1]}-${+m[2]}`:'';}
  function rootZipPath(path) { const parts=[];for (const p of path.split('/')) {if (p==='..') parts.pop();else if (p && p!=='.')parts.push(p);} return parts.join('/'); }
  async function extractWorkbook(file){
    if(!/\.(xlsx|xlsm)$/i.test(file.name))throw Error(`${file.name}: .xlsx または .xlsm を指定してください（.xlsは非対応）。`);
    const zip=await JSZip.loadAsync(await file.arrayBuffer());
    const wbFile=zip.file('xl/workbook.xml');if(!wbFile)throw Error(`${file.name}: Excelの構成情報が見つかりません`);
    const wbd=xml(await wbFile.async('string'));
    const relFile=zip.file('xl/_rels/workbook.xml.rels');const relationships={};
    if(relFile){for(const r of descendants(xml(await relFile.async('string')),'Relationship'))relationships[r.getAttribute('Id')]=r.getAttribute('Target')}
    const ss=zip.file('xl/sharedStrings.xml');let strings=[];
    if(ss){const doc=xml(await ss.async('string'));strings=descendants(doc,'si').map(si=>descendants(si,'t').map(t=>t.textContent).join(''));}
    const sheets=[];
    for (const [i,s] of descendants(wbd,'sheet').entries()){
      const rel=s.getAttribute('r:id')||s.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
      const target=relationships[rel] || `worksheets/sheet${i+1}.xml`;
      const path=target.startsWith('/')?target.slice(1):rootZipPath('xl/'+target);
      const z=zip.file(path);if(!z)continue;
      const doc=xml(await z.async('string'));const values=[];
      for(const cell of descendants(doc,'c')){
        const ref=cell.getAttribute('r')||'';const match=ref.match(/^([A-Z]+)(\d+)$/i);if(!match)continue;
        const row=Number(match[2])-1, col=colIndex(match[1]);if(row>100000||col>200)continue;
        if(!values[row])values[row]=[];
        const type=cell.getAttribute('t');const v=firstText(cell,'v');
        const value=type==='s'? (strings[Number(v)]??'') : type==='inlineStr'?descendants(cell,'t').map(x=>x.textContent).join('') : v;
        values[row][col]=String(value??'').trim();
      }
      sheets.push({name:s.getAttribute('name')||`Sheet${i+1}`, rows:values});
    }
    return sheets;
  }
  function readCatalog(sheets){
    const caseIds=new Set(), expectedByCase=new Map();const expectationsAll=new Set();const notes=[];
    function push(caseId,value){ const id=String(value??'').trim();if(!id)return; expectationsAll.add(id);if(!caseId)return; if(!expectedByCase.has(caseId))expectedByCase.set(caseId,new Set());expectedByCase.get(caseId).add(id); }
    for(const sheet of sheets){
      const headCandidates=sheet.rows.slice(0,15).map((r,i)=>({r:r||[],i}));
      let best={score:-1,row:[],index:0};
      for(const {r,i} of headCandidates){ const score=r.reduce((n,v)=>n+(/^(シナリオ\s*ID|ケース(?:名)?|ID|SID|No|期待値\s*ID)$/i.test(String(v).replace(/\s/g,''))?1:0),0);if(score>best.score)best={score,row:r,index:i}; }
      const h=best.row.map(v=>String(v??'').replace(/\s/g,'').toLowerCase());
      const caseCol=h.findIndex(x=>/^(シナリオid|ケース名|ケースid|ケース|シナリオ)$/.test(x));
      let idCol=h.findIndex(x=>/^(id|期待値id|期待値項目id)$/.test(x));
      if(idCol<0) idCol=h.findIndex(x=>x==='sid');
      if(idCol<0)idCol=h.findIndex(x=>x==='no');
      const start=best.score>0?best.index+1:0;
      let currentCase='';
      for(const row of sheet.rows.slice(start)){
        if(!row)continue;
        const direct=caseCol>=0?normalizedCase(row[caseCol]):'';
        const fromAny=direct||row.map(normalizedCase).find(Boolean)||'';
        if(fromAny)currentCase=fromAny;
        if(fromAny)caseIds.add(fromAny);
        const id=idCol>=0? row[idCol]:'';
        if(id!==undefined && id!==null && String(id).trim()) push(currentCase,id);
      }
      if(caseCol<0)notes.push(`${sheet.name}：ケース列未検出（P1-1形式を検索）`);
    }
    const sorted=[...caseIds].sort((a,b)=>{const pa=a.match(/\d+/g).map(Number),pb=b.match(/\d+/g).map(Number);return pa[0]-pb[0]||pa[1]-pb[1];});
    return {cases:sorted,allExpectations:[...expectationsAll], expectedByCase:Object.fromEntries([...expectedByCase].map(([k,v])=>[k,[...v]])),notes};
  }
  global.EOExcel={extractWorkbook,readCatalog,normalizedCase};
})(window);
