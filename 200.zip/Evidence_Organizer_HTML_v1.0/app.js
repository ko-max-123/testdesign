'use strict';
(function(){
 const $=id=>document.getElementById(id);
 const STATE_KEY='eo_html_sessions_1';
 const st={specs:[],sessions:[],activeId:null,busy:false};
 const exts=/\.(jpe?g|png|heic|heif|webp|bmp|gif|tiff?)$/i;
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const fixedName=s=>String(s??'').trim().replace(/\.(xlsx|xlsm)$/i,'');
 const safeComponent=(s,label)=>{const v=String(s||'').trim();if(!v||v==='.'||v==='..'||/[<>:"/\\|?*\x00-\x1f]/.test(v)||/[ .]$/.test(v)||/^(CON|PRN|NUL|AUX|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(v))throw Error(`${label}がフォルダ名として使用できません: ${v}`);return v;};
 const caseName=s=>EOExcel.normalizedCase(s);
 function save(){try{localStorage.setItem(STATE_KEY,JSON.stringify({sessions:st.sessions,activeId:st.activeId}));}catch(_){/* The session remains in memory until close. */}}
 function restore(){try{const obj=JSON.parse(localStorage.getItem(STATE_KEY)||'{}');if(Array.isArray(obj.sessions))st.sessions=obj.sessions.filter(x=>x&&/^[a-f0-9]{12}$/.test(x.sid));st.activeId=obj.activeId||null;}catch(_){}}
 function setResult(text,type='info'){const box=$('result');box.classList.remove('hidden','error','info');box.classList.add(type);box.textContent=text;}
 function setBusy(b){st.busy=b;for(const id of ['chooseExcels','chooseExcelFolder','startMarker','endMarker','organize'])$(id).disabled=b||(id==='endMarker'?!st.activeId:false);}
 function addOption(select,v,label){const o=document.createElement('option');o.value=v;o.textContent=label;select.add(o);}
 function selectedSpec(){return st.specs.find(x=>x.key===$('spec').value)||null;}
 function getScenario(){return $('caseSelect').value==='__manual__'?$('caseManual').value.trim():$('caseSelect').value;}
 function currentData(){
   const x=selectedSpec();if(!x)throw Error('先にテスト仕様書を読み込んでください。');
   const project=safeComponent($('project').value,'案件名');
   const spec=safeComponent(x.name,'仕様書名');
   const scenario=caseName(getScenario());if(!scenario)throw Error('ケース名はP1-1などの形式で指定してください。');
   const expected=$('expected').value;
   const idFolder=$('makeID').checked && expected?safeComponent(/^ID/i.test(expected)?expected:`ID${expected}`,'ID'):'';
   return {project,spec,scenario,expected,idFolder};
 }
 function updatePreview(){
   const x=selectedSpec(),project=$('project').value||'案件名',spec=x?.name||'仕様書名',scenario=caseName(getScenario())||'P1-1';
   const id=$('makeID').checked && $('expected').value?` / ID${$('expected').value.replace(/^ID/i,'')}`:'';
   $('targetPreview').textContent=`格納先：${project} / ${spec} / ${scenario}${id} / And・iOS`;
 }
 function refreshSpecOptions(){const sel=$('spec');sel.innerHTML='';for(const x of st.specs)addOption(sel,x.key,x.name); if(st.specs.length)selectSpec();}
 function selectSpec(){const x=selectedSpec();$('caseSelect').innerHTML='';
   if(x){for(const c of x.catalog.cases)addOption($('caseSelect'),c,c);addOption($('caseSelect'),'__manual__','ケース名を入力する');$('caseSelect').value=x.catalog.cases[0]||'__manual__';}
   else addOption($('caseSelect'),'','仕様書を読み込んでください');
   updateCase();
 }
 function updateCase(){const manual=$('caseSelect').value==='__manual__';$('caseManualWrap').hidden=!manual;
   if(manual&&!$('caseManual').value)$('caseManual').placeholder='P1-1';
   const x=selectedSpec(),c=getScenario(),all=x?(x.catalog.expectedByCase[c]||x.catalog.allExpectations):[];
   $('expected').innerHTML='';addOption($('expected'),'','指定しない');for(const id of all)addOption($('expected'),id,id);
   updatePreview();
 }
 async function importFiles(files,fromFolderName=''){
   if(!files.length){setResult('Excel仕様書（.xlsxまたは.xlsm）が見つかりません。','error');return;}
   setBusy(true);let success=0;const fails=[];
   for(const file of files){try{
      const sheets=await EOExcel.extractWorkbook(file),catalog=EOExcel.readCatalog(sheets);
      const name=fixedName(file.name),key=`${name}#${st.specs.length+1}`;
      if(!st.specs.some(s=>s.name===name))st.specs.push({key,name,catalog,sheets});
      success++;
    }catch(e){fails.push(`${file.name}: ${e.message}`);}}
   if(fromFolderName&&!$('project').value.trim())$('project').value=fromFolderName;
   $('excelState').classList.remove('empty');$('excelState').textContent=`${success}件の仕様書を読み込みました。ケース名がExcelにない場合は手入力してください。`;
   if(fails.length)$('excelState').textContent+='\n'+fails.join('\n');
   refreshSpecOptions();setBusy(false);
 }
 $('chooseExcels').onclick=()=>$('excelFiles').click();
 $('excelFiles').onchange=()=>importFiles([...$('excelFiles').files]);
 $('chooseExcelFolder').onclick=async()=>{
   if(!window.showDirectoryPicker){setResult('このブラウザーではフォルダ読込に対応していません。Excelファイルを選択してください。','error');return;}
   try {const root=await showDirectoryPicker({mode:'read'});const files=[];
     for await(const [name,h] of root.entries()){if(h.kind==='file'&&/\.(xlsx|xlsm)$/i.test(name))files.push(await h.getFile());}
     await importFiles(files,root.name);
   }catch(e){if(e.name!=='AbortError')setResult(e.message,'error');}
 };
 $('spec').onchange=selectSpec;$('caseSelect').onchange=updateCase;
 $('caseManual').oninput=updatePreview;$('expected').onchange=updatePreview;$('project').oninput=updatePreview;$('makeID').onchange=updatePreview;
 function createSid(){const bytes=new Uint8Array(6);crypto.getRandomValues(bytes);return [...bytes].map(n=>n.toString(16).padStart(2,'0')).join('');}
 function openMarker(session,tag){
   $('bigTitle').textContent=tag==='START'?'撮影開始 / START':'撮影終了 / END';
   $('bigTitle').style.color=tag==='START'?'#174869':'#933a32';
   $('qrMount').replaceChildren(EOMarker.qrCanvas(session.sid,tag));
   $('gridMount').replaceChildren(EOMarker.fallbackCanvas(session.sid,tag));
   const meta=[['案件',session.project],['仕様書',session.spec],['ケース',session.scenario],['期待値ID',session.expected||'指定なし'],['IDフォルダ',session.idFolder||'なし'],['識別コード',session.sid]];
   $('bookmarkMeta').innerHTML=meta.map(([k,v])=>`<div><b>${esc(k)}</b>${esc(v)}</div>`).join('');
   $('overlay').classList.remove('hidden');document.body.classList.add('bookmark-open');
 }
 $('closeOverlay').onclick=()=>{$('overlay').classList.add('hidden');document.body.classList.remove('bookmark-open');};
 $('startMarker').onclick=()=>{
   try{const data=currentData();const session={...data,sid:createSid(),createdAt:new Date().toISOString()};
      st.sessions.push(session);st.activeId=session.sid;save();$('endMarker').disabled=false;$('markerState').textContent=`${session.scenario}：開始しおりを作成しました。テスト撮影後に終了しおりを表示してください。`;
      openMarker(session,'START');
   }catch(e){setResult(e.message,'error');}
 };
 $('endMarker').onclick=()=>{
   const session=st.sessions.find(x=>x.sid===st.activeId);if(!session)return;
   openMarker(session,'END');st.activeId=null;save();$('endMarker').disabled=true;
   $('markerState').textContent=`${session.scenario}：終了しおりを作成しました。次の撮影は新しい開始しおりから。`;
 };
 async function collectImages(root,excluded){
   const out=[];async function visit(dir,depth){if(depth>5)return;
     for await(const [name,handle] of dir.entries()){
       if(handle.kind==='directory'){
         if(depth===0 && (name===excluded || name==='管理データ' || name==='エビデンス'))continue;
         if(name==='And'||name==='iOS')continue;
         await visit(handle,depth+1);
       }else if(handle.kind==='file'&&exts.test(name)){
         try{const file=await handle.getFile();out.push({file,name,path:name,handle});}catch(_){}
       }
     }
   }await visit(root,0);return out;
 }
 function sortRows(rows){
   // All IMG_XXXX files from the same iPhone Camera Roll: use the gallery sequence
   // to avoid mixing camera EXIF times with screenshot file-transfer times.
   const count=rows.filter(r=>EOMetadata.seqNumber(r.name)!==null).length;
   if(count>=2&&count>=rows.length*.72){
     return rows.sort((a,b)=>{
       const an=EOMetadata.seqNumber(a.name),bn=EOMetadata.seqNumber(b.name);
       if(an!==null&&bn!==null)return an-bn||a.name.localeCompare(b.name);
       return (a.meta.captureTime||a.file.lastModified)-(b.meta.captureTime||b.file.lastModified)||a.name.localeCompare(b.name);
     });
   }
   return rows.sort((a,b)=>(a.meta.captureTime||a.file.lastModified)-(b.meta.captureTime||b.file.lastModified)||a.name.localeCompare(b.name));
 }
 async function analyze(files){
   const rows=[];const diag=[];
   for(let i=0;i<files.length;i++){
     const f=files[i];let meta,marker;
     try{meta=await EOMetadata.inspect(f.file);}catch(e){meta={os:'',reason:`メタデータ読取失敗: ${e.message}`,captureTime:null};}
     try{marker=await EOMarker.decodeImage(f.file);}catch(e){diag.push(`${f.name}：しおり画像解析失敗: ${e.message}`);}
     rows.push({...f,meta,marker:marker||null,assigned:null,reason:''});
     if(i%10===0||i===files.length-1){$('progress').value=Math.round(80*(i+1)/files.length);$('progressLabel').textContent=`画像を解析中 ${i+1} / ${files.length}`;await new Promise(r=>setTimeout(r,0));}
   }
   sortRows(rows);
   const nStart=rows.filter(r=>r.marker?.tag==='START').length;
   const nEnd=rows.filter(r=>r.marker?.tag==='END').length;
   if((!nStart||!nEnd||nStart!==nEnd) && rows.length){
     // A photo of a monitor may be slightly rotated. Run a more costly
     // second pass only when the normal scan did not find balanced markers.
     const candidates=rows.filter(r=>!r.marker && /\.(png|jpe?g|webp|heic|heif)$/i.test(r.name));
     for(let j=0;j<candidates.length;j++){
       const row=candidates[j];try{const marker=await EOMarker.decodeImage(row.file,{aggressive:true});if(marker)row.marker=marker;}catch(_){}
       if(j%10===0||j===candidates.length-1){$('progressLabel').textContent=`しおりを再確認中 ${j+1} / ${candidates.length}`;await new Promise(r=>setTimeout(r,0));}
     }
   }
   const known=new Map(st.sessions.map(x=>[x.sid,x]));const pending=[];let active=null;
   for(const row of rows){
     if(row.marker){
       if(!known.has(row.marker.sid)){row.reason='登録情報のないしおり';if(row.marker.tag==='START'){if(active){for(const x of pending)x.reason='対応する終了しおりがない';}pending.length=0;active=null;}continue;}
       if(row.marker.tag==='START'){
         if(active){for(const x of pending)x.reason='終了しおりの前に次の開始しおり';}
         pending.length=0;active=row.marker.sid;row.reason='開始しおり';
       }else{
         if(active===row.marker.sid){
           const session=known.get(active);
           for(const x of pending){x.assigned=session;x.reason=x.meta.os?'分類候補':'OS不明';}
         }else{for(const x of pending)x.reason='開始・終了しおりが一致しない';}
         pending.length=0;active=null;row.reason='終了しおり';
       }
       continue;
     }
     if(active)pending.push(row);else row.reason='しおりの外側';
   }
   if(active){for(const row of pending)row.reason='終了しおりが未検出';}
   return {rows,diag};
 }
 async function output(root,rows){let copied=0,held=0,markers=0,exists=0;const reasons=[];
   for(let i=0;i<rows.length;i++){
     const row=rows[i];if(row.marker){markers++;continue;}
     if(!row.assigned||!row.meta.os){held++;reasons.push(`${row.name}: ${row.reason||row.meta.reason}`);continue;}
     try{
       const s=row.assigned;let dir=root;
       for(const folder of [s.project,s.spec,s.scenario,...(s.idFolder?[s.idFolder]:[]),row.meta.os])dir=await dir.getDirectoryHandle(safeComponent(folder,'フォルダ名'),{create:true});
       try{await dir.getFileHandle(row.name,{create:false});exists++;reasons.push(`${row.name}: 同名ファイルが存在（コピーせず保留）`);continue;}
       catch(e){if(e.name!=='NotFoundError')throw e;}
       const target=await dir.getFileHandle(row.name,{create:true});const writer=await target.createWritable({keepExistingData:false});
       try{await writer.write(row.file);await writer.close();copied++;}
       catch(e){try{await writer.abort();}catch(_){}throw e;}
     }catch(e){held++;reasons.push(`${row.name}: 書込失敗（${e.message}）`);}
     if(i%10===0){$('progress').value=80+Math.round(20*(i+1)/rows.length);$('progressLabel').textContent=`コピー中 ${i+1}/${rows.length}`;await new Promise(r=>setTimeout(r,0));}
   }
   return {copied,held,exists,markers,reasons};
 }
 $('organize').onclick=async()=>{
   if(!window.showDirectoryPicker){setResult('このブラウザーはフォルダへの直接書き込みに対応していません。Windows版Chrome／Edgeでindex.htmlを開いてください。','error');return;}
   let root;try{root=await showDirectoryPicker({mode:'readwrite'});}catch(e){if(e.name!=='AbortError')setResult(e.message,'error');return;}
   setBusy(true);$('progressWrap').classList.remove('hidden');$('progress').value=0;$('progressLabel').textContent='画像を確認しています…';$('resultDetails').classList.add('hidden');
   try{
     const files=await collectImages(root,$('project').value.trim());
     if(!files.length){setResult('選択したフォルダに対象画像がありません。','error');return;}
     if(!st.sessions.length){setResult('先に開始・終了しおりを作ってください（このHTMLで作ったしおりの登録が必要です）。','error');return;}
     const {rows,diag}=await analyze(files);const valid=rows.filter(x=>x.assigned&&x.meta.os).length;
     const totalMarkers=rows.filter(x=>x.marker).length;
     if(!valid){setResult(`画像 ${files.length}枚を確認しましたが、対応する開始・終了しおりを認識できず、自動コピーはしませんでした。\nしおり検出 ${totalMarkers}枚。画像の撮影形式・順番をご確認ください。`,'error');$('detailsText').textContent=rows.map(x=>`${x.name}: ${x.reason||x.meta.reason}`).join('\n');$('resultDetails').classList.remove('hidden');return;}
     const result=await output(root,rows);$('progress').value=100;
     setResult(`整理しました。\nコピー: ${result.copied}枚 ／ しおり除外: ${result.markers}枚 ／ 保留: ${result.held+result.exists}枚\n保存先：選択した「${root.name}」フォルダ内`,'info');
     $('detailsText').textContent=[...diag,...result.reasons].join('\n')||'保留はありません。';$('resultDetails').classList.remove('hidden');
   }catch(e){setResult(`整理に失敗しました: ${e.message}`,'error');}
   finally{$('progressLabel').textContent='';$('progressWrap').classList.add('hidden');setBusy(false);}
 };
 if(!window.showDirectoryPicker){$('supportWarning').classList.remove('hidden');$('supportWarning').textContent='フォルダの自動作成・コピーに対応していないブラウザーです。WindowsのChrome／Edgeで開いてください。';}
 restore();if(st.activeId && st.sessions.some(x=>x.sid===st.activeId)){
   $('endMarker').disabled=false;$('markerState').textContent='前回の開始しおりが残っています。終了しおりを表示できます。';
 }else{st.activeId=null;}
 window.EOTest={sortRows,analyze,output,safeComponent};
})();
